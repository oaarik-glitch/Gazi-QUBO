"""Recreate the four revised manuscript figures from archived records."""
import argparse,csv,math
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import t

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def wilson(k,n):
    z=1.959963984540054;d=1+z*z/n;c=(k/n+z*z/(2*n))/d
    h=z*math.sqrt((k/n)*(1-k/n)/n+z*z/(4*n*n))/d
    return c-h,c+h
def main():
    a=argparse.ArgumentParser();a.add_argument('--results',type=Path,required=True);a.add_argument('--out',type=Path,required=True);args=a.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    rows=read(args.results/'qaoa-30seed/qaoa-runs.csv');groups=[[r for r in rows if int(r['reps'])==p] for p in range(1,6)]
    def save(fig,stem):
        fig.tight_layout();fig.savefig(args.out/(stem+'.png'),dpi=300,bbox_inches='tight');fig.savefig(args.out/(stem+'.svg'),bbox_inches='tight');plt.close(fig)
    comparison=read(args.results/'qubo-tiny/qubo-formulation-comparison.csv')
    labels=['Zaman\nindisli','Sıra\ntabanlı','Önce–sonra'];x=np.arange(3)
    fig,ax=plt.subplots(1,2,figsize=(7.1,3.0))
    ax[0].bar(x-.18,[int(r['variables']) for r in comparison],.36,label='İkili değişken',color='#2563A6')
    ax[0].bar(x+.18,[int(r['quadratic_terms']) for r in comparison],.36,label='Karesel bağ',color='#D4862F')
    ax[0].set_xticks(x,labels);ax[0].set_ylabel('Adet');ax[0].set_title('(a) Değişken ve bağ sayıları');ax[0].legend(frameon=False,fontsize=8)
    ax[1].bar(x,[100*float(r['coupling_density']) for r in comparison],color='#2563A6');ax[1].set_xticks(x,labels);ax[1].set_ylabel('Bağ yoğunluğu (%)');ax[1].set_ylim(0,60);ax[1].set_title('(b) Grafik yoğunluğu')
    for aa in ax:aa.grid(axis='y',alpha=.2);aa.set_axisbelow(True)
    save(fig,'sekil-1-qubo')
    fig,ax=plt.subplots(figsize=(6.6,2.9));x=np.arange(1,6)
    for delta,field,label,color in [(-.18,'bestFeasible','En düşük enerjili çözüm uygulanabilir','#2563A6'),(.18,'matchesReferenceOptimum','En düşük enerjili çözüm optimum','#D4862F')]:
        k=[sum(r[field].lower()=='true' for r in g) for g in groups];rates=np.array(k)/30;ci=np.array([wilson(v,30) for v in k])
        ax.bar(x+delta,100*rates,.36,yerr=np.vstack((100*(rates-ci[:,0]),100*(ci[:,1]-rates))),capsize=3,label=label,color=color)
    ax.set_xticks(x);ax.set_xlabel('QAOA katman sayısı p');ax.set_ylabel('Koşum oranı (%)');ax.set_ylim(0,100);ax.legend(frameon=False,fontsize=8,loc='upper left');ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    save(fig,'sekil-2-basari')
    fig,ax=plt.subplots(figsize=(6.6,2.6));ax.boxplot([[float(r['bestEnergy']) for r in g] for g in groups],tick_labels=list(map(str,x)),showmeans=True,whis=1.5,medianprops={'color':'#2563A6','linewidth':1.6},meanprops={'marker':'^','markeredgecolor':'#23854B','markerfacecolor':'white'})
    ax.set_xlabel('QAOA katman sayısı p');ax.set_ylabel('En düşük QUBO enerjisi\n(ölçeklenmiş maliyet birimi)');ax.grid(axis='y',alpha=.2)
    save(fig,'sekil-3-enerji')
    fig,ax=plt.subplots(figsize=(6.6,2.6));times=[np.array([float(r['runtimeSeconds']) for r in g]) for g in groups]
    means=[v.mean() for v in times];half=[t.ppf(.975,29)*v.std(ddof=1)/math.sqrt(30) for v in times]
    ax.errorbar(x,means,yerr=half,marker='o',capsize=4,color='#2563A6');ax.set_xticks(x);ax.set_xlabel('QAOA katman sayısı p');ax.set_ylabel('Ortalama koşum süresi (s)');ax.set_ylim(bottom=0);ax.grid(alpha=.2)
    save(fig,'sekil-4-sure')
if __name__=='__main__':main()
