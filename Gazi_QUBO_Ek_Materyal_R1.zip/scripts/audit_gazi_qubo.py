#!/usr/bin/env python3
"""Independent audit of supplied QUBO coefficients and archived QAOA results.

No Gurobi, .NET or Qiskit calls. NumPy and SciPy are required.
Run: python audit_gazi_qubo.py --source SmWetSolver --results results --out audit
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from scipy.stats import t as student_t


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def csvout(path, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def cost(job, start):
    delta = start + job["processingTime"] - job["dueDate"]
    return job["earlinessWeight"] * max(0, -delta) + job["tardinessWeight"] * max(0, delta)


def energy(q, values):
    return q["constant"] + sum(t["value"] * values[t["index"]] for t in q["linear"]) + sum(
        t["value"] * values[t["i"]] * values[t["j"]] for t in q["quadratic"])


def polynomial(q, inst):
    """Rebuild all coefficients from mathematical constraints, using variable map."""
    h, jobs, lam = inst["horizon"], inst["jobs"], q["metadata"]["penalty"]
    variables = q["variables"]
    out = defaultdict(float)

    def linear(index, value):
        out[(index,)] += value

    def square(constant, terms):
        out[()] += lam * constant * constant
        combined = defaultdict(float)
        for i, c in terms:
            combined[i] += c
        terms = sorted(combined.items())
        for i, c in terms:
            linear(i, lam * (c * c + 2 * constant * c))
        for (i, c), (j, d) in itertools.combinations(terms, 2):
            out[(i, j)] += 2 * lam * c * d

    def select(kind, **criteria):
        return [v for v in variables if v["kind"] == kind and all(v.get(k) == x for k, x in criteria.items())]

    def terms(kind, multiplier=1, **criteria):
        return [(v["index"], multiplier * (v.get("weight") or 1)) for v in select(kind, **criteria)]

    def one(kind, **criteria):
        values = select(kind, **criteria)
        assert len(values) == 1
        return values[0]["index"]

    if q["formulation"] == "time-indexed":
        for job in jobs:
            vv = select("start", jobId=job["id"])
            square(-1, [(v["index"], 1) for v in vv])
            for v in vv:
                linear(v["index"], cost(job, v["startTime"]))
        byid = {j["id"]: j for j in jobs}
        for a, b in itertools.combinations(variables, 2):
            if a["jobId"] == b["jobId"]:
                continue
            if a["startTime"] < b["startTime"] + byid[b["jobId"]]["processingTime"] and b["startTime"] < a["startTime"] + byid[a["jobId"]]["processingTime"]:
                out[tuple(sorted((a["index"], b["index"])))] += lam
    else:
        for job in jobs:
            for kind, weight in [("earliness-bit", job["earlinessWeight"]), ("tardiness-bit", job["tardinessWeight"])]:
                for i, c in terms(kind, jobId=job["id"]):
                    linear(i, weight * c)
        if q["formulation"] == "position":
            for job in jobs:
                square(-1, terms("assignment", jobId=job["id"]))
            for pos in range(1, len(jobs) + 1):
                square(-1, terms("assignment", position=pos))
                t = terms("completion-bit", position=pos) + terms("idle-bit", -1, position=pos)
                if pos > 1:
                    t += terms("completion-bit", -1, position=pos - 1)
                t += [(one("assignment", jobId=j["id"], position=pos), -j["processingTime"]) for j in jobs]
                square(0, t)
            for v in select("product"):
                a = one("assignment", jobId=v["jobId"], position=v["position"])
                b = one("completion-bit", position=v["position"], bit=v["bit"])
                z = v["index"]
                for x, y, c in [(a, b, 1), (a, z, -2), (b, z, -2)]:
                    out[tuple(sorted((x, y)))] += lam * c
                linear(z, 3 * lam)
            for job in jobs:
                square(job["dueDate"], terms("product", -1, jobId=job["id"]) + terms("earliness-bit", -1, jobId=job["id"]) + terms("tardiness-bit", jobId=job["id"]))
        else:
            for job in jobs:
                square(job["dueDate"] - job["processingTime"], terms("start-bit", -1, jobId=job["id"]) + terms("earliness-bit", -1, jobId=job["id"]) + terms("tardiness-bit", jobId=job["id"]))
            for a, b in itertools.combinations(jobs, 2):
                i, j = a["id"], b["id"]
                y = one("precedence", jobId=i, otherJobId=j)
                square(h - a["processingTime"], terms("start-bit", jobId=j) + terms("start-bit", -1, jobId=i) + [(y, -h)] + terms("slack-bit", -1, jobId=i, otherJobId=j, direction="first-before-second"))
                square(-b["processingTime"], terms("start-bit", jobId=i) + terms("start-bit", -1, jobId=j) + [(y, h)] + terms("slack-bit", -1, jobId=i, otherJobId=j, direction="second-before-first"))
    actual = {(): q["constant"]}
    actual.update({(t["index"],): t["value"] for t in q["linear"]})
    actual.update({(t["i"], t["j"]): t["value"] for t in q["quadratic"]})
    error = max(abs(out.get(k, 0) - actual.get(k, 0)) for k in set(out) | set(actual))
    assert error < 1e-9, (q["name"], "coefficient mismatch", error)
    return error


def schedule_scan(inst):
    jobs, h = inst["jobs"], inst["horizon"]
    feasible = []
    for starts in itertools.product(*(range(h - j["processingTime"] + 1) for j in jobs)):
        order = sorted(range(len(jobs)), key=lambda i: starts[i])
        if any(starts[a] + jobs[a]["processingTime"] > starts[b] for a, b in zip(order, order[1:])):
            continue
        feasible.append((sum(cost(j, s) for j, s in zip(jobs, starts)), starts))
    return feasible


def heuristic(inst):
    jobs, h = inst["jobs"], inst["horizon"]
    candidates = []
    for label, order in [("input", jobs), ("EDD", sorted(jobs, key=lambda j: (j["dueDate"], j["id"]))), ("SPT", sorted(jobs, key=lambda j: (j["processingTime"], j["id"])) )]:
        for shift in range(h - sum(j["processingTime"] for j in jobs) + 1):
            start, z, schedule = shift, 0, []
            for job in order:
                z += cost(job, start)
                schedule.append({"jobId": job["id"], "start": start, "completion": start + job["processingTime"]})
                start += job["processingTime"]
            candidates.append({"method": label, "shift": shift, "cost": z, "schedule": schedule})
    u = min(c["cost"] for c in candidates)
    return {"upperBound": u, "bestCandidates": [c for c in candidates if c["cost"] == u], "candidateCount": len(candidates)}


def all_energies(q):
    masks = np.arange(1 << q["numVariables"], dtype=np.int64)
    e = np.full(len(masks), q["constant"], dtype=float)
    for t in q["linear"]:
        e += t["value"] * ((masks >> t["index"]) & 1)
    for t in q["quadratic"]:
        e += t["value"] * ((masks >> t["i"]) & 1) * ((masks >> t["j"]) & 1)
    return e


def check_vector(q, inst, values):
    selected = [v for v in q['variables'] if values[v['index']]]
    jobs = {j['id']:j for j in inst['jobs']}
    def weighted(kind, **kw):
        return sum((v.get('weight') or 1) for v in selected if v['kind']==kind and all(v.get(k)==x for k,x in kw.items()))
    starts = {}
    if q['formulation']=='time-indexed':
        for job in jobs:
            vv=[v for v in selected if v['jobId']==job]
            assert len(vv)==1
            starts[job]=vv[0]['startTime']
    elif q['formulation']=='position':
        seen=set();previous=0
        for pos in range(1,len(jobs)+1):
            vv=[v for v in selected if v['kind']=='assignment' and v['position']==pos]
            assert len(vv)==1
            job=vv[0]['jobId'];assert job not in seen;seen.add(job)
            completion=weighted('completion-bit',position=pos)
            assert completion==previous+weighted('idle-bit',position=pos)+jobs[job]['processingTime']
            starts[job]=completion-jobs[job]['processingTime'];previous=completion
        lookup={(v['kind'],v['jobId'],v['position'],v['bit']):values[v['index']] for v in q['variables']}
        for v in q['variables']:
            if v['kind']=='product':
                a=lookup['assignment',v['jobId'],v['position'],None]
                b=lookup['completion-bit',None,v['position'],v['bit']]
                assert values[v['index']]==a*b
    else:
        starts={job:weighted('start-bit',jobId=job) for job in jobs}
        for a,b in itertools.combinations(jobs,2):
            y=weighted('precedence',jobId=a,otherJobId=b)
            assert starts[b]-starts[a]-jobs[a]['processingTime']+inst['horizon']*(1-y)==weighted('slack-bit',jobId=a,otherJobId=b,direction='first-before-second')
            assert starts[a]-starts[b]-jobs[b]['processingTime']+inst['horizon']*y==weighted('slack-bit',jobId=a,otherJobId=b,direction='second-before-first')
    order=sorted(starts,key=starts.get)
    assert len(order)==len(jobs)
    assert all(0<=starts[i]<=inst['horizon']-jobs[i]['processingTime'] for i in order)
    assert all(starts[i]+jobs[i]['processingTime']<=starts[j] for i,j in zip(order,order[1:]))
    if q['formulation']!='time-indexed':
        for i,job in jobs.items():
            delta=starts[i]+job['processingTime']-job['dueDate']
            assert weighted('earliness-bit',jobId=i)==max(0,-delta)
            assert weighted('tardiness-bit',jobId=i)==max(0,delta)
    return sum(cost(jobs[i],s) for i,s in starts.items())


def statevector(energies, theta, p):
    n = int(math.log2(len(energies)))
    state = np.full(len(energies), 1 / math.sqrt(len(energies)), dtype=complex)
    for beta, gamma in zip(theta[:p], theta[p:]):
        state *= np.exp(-1j * gamma * energies)
        for bit in range(n):
            v = state.reshape(-1, 2, 1 << bit)
            a, b = v[:, 0, :].copy(), v[:, 1, :].copy()
            v[:, 0, :] = math.cos(beta) * a - 1j * math.sin(beta) * b
            v[:, 1, :] = math.cos(beta) * b - 1j * math.sin(beta) * a
    return np.abs(state) ** 2


def wilson(k, n):
    z = 1.959963984540054
    center = (k / n + z*z / (2*n)) / (1+z*z/n)
    half = z * math.sqrt(k/n*(1-k/n)/n + z*z/(4*n*n)) / (1+z*z/n)
    return center-half, center+half


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    cases = [("qubo-tiny", "qubo-tiny-three-job.json"), ("qubo-paper", "three-job.json")]
    audit = {"scope": "Independent coefficient reconstruction, integer start enumeration, archived statistics, NumPy QAOA statevectors; no new optimization runs", "instances": {}, "qubo": [], "limitations": ["Original .NET/Gurobi binaries were not executed in this environment.", "Historical full shot histograms and complete dependency freeze are absent.", "Noisy Aer execution was not rerun; its archived metrics are checked algebraically."]}
    input_rows, qubo_rows, maps, coefficients = [], [], [], []
    for folder, fname in cases:
        inst = read(args.source / "instances" / fname)
        schedules = schedule_scan(inst)
        optimum = min(c[0] for c in schedules)
        upper = heuristic(inst)
        audit["instances"][folder] = {"data": inst, "feasibleScheduleCount": len(schedules), "classicalOptimum": optimum, "optimalScheduleCount": sum(z == optimum for z, _ in schedules), "heuristic": upper}
        for job in inst["jobs"]:
            input_rows.append({"instance": folder, "horizon": inst["horizon"], "U": upper["upperBound"], "lambda": upper["upperBound"] + 1, **job})
        for form in ["time-indexed", "position", "precedence"]:
            q = read(args.results / folder / (form + "-qubo.json"))
            v = read(args.results / folder / (form + "-validation.json"))
            err = polynomial(q, inst)
            x = v["quboSolve"]["values"]
            e = energy(q, x)
            assert e == v["quboSolve"]["energy"] == v["decoded"]["schedulingObjective"] == optimum
            assert check_vector(q,inst,x)==optimum
            assert q["metadata"]["feasibleUpperBound"] == upper["upperBound"]
            groups = defaultdict(list)
            for variable in q["variables"]:
                if variable["kind"].endswith("-bit"):
                    key = tuple(variable.get(k) for k in ["kind", "jobId", "otherJobId", "position", "direction"])
                    groups[key].append(variable["weight"])
                maps.append({"instance": folder, "formulation": form, **variable})
            for key, weights in groups.items():
                represented = {sum(w for i,w in enumerate(weights) if mask>>i&1) for mask in range(1<<len(weights))}
                assert represented == set(range(sum(weights)+1))
            for k, terms in [("constant", [{"value": q["constant"]}]), ("linear", q["linear"]), ("quadratic", q["quadratic"])]:
                for t in terms:
                    coefficients.append({"instance": folder, "formulation": form, "term": k, "i": t.get("index",t.get("i", "")), "j": t.get("j", ""), "value": t["value"]})
            row = {"instance": folder, "formulation": form, "variables": q["numVariables"], "linear_terms": len(q["linear"]), "couplings": len(q["quadratic"]), "density_percent": 100*len(q["quadratic"])/math.comb(q["numVariables"],2), "U": upper["upperBound"], "lambda": q["metadata"]["penalty"], "energy": e, "objective": optimum, "coefficient_max_error": err, "archived_solver_status": v["quboSolve"]["status"]}
            qubo_rows.append(row)
            audit["qubo"].append(row)
    csvout(args.out/"instance-data.csv", input_rows)
    csvout(args.out/"qubo-checks.csv", qubo_rows)
    csvout(args.out/"variable-map.csv", maps)
    csvout(args.out/"qubo-coefficients.csv", coefficients)

    q = read(args.results/"qubo-tiny/time-indexed-qubo.json")
    e = all_energies(q)
    inst = audit["instances"]["qubo-tiny"]["data"]
    feasible_masks = []
    for _, starts in schedule_scan(inst):
        selected = {(j["id"],s) for j,s in zip(inst["jobs"],starts)}
        feasible_masks.append(sum(1<<v["index"] for v in q["variables"] if (v["jobId"], v["startTime"]) in selected))
    assert float(e.min()) == 0
    opt_count = int(np.count_nonzero(e == 0))
    assert all(m in feasible_masks for m in np.flatnonzero(e==0))
    audit["tiny_full_enumeration"] = {"states": len(e), "minimumEnergy": float(e.min()), "optimalStates": opt_count, "feasibleStates": len(feasible_masks), "uniformOptimalShotProbability": opt_count/len(e), "uniformAtLeastOneOptimum4096": -math.expm1(4096*math.log1p(-opt_count/len(e)))}
    experiment = read(args.results/"qaoa-30seed/qaoa-experiment.json")
    with (args.results/'qaoa-30seed/qaoa-summary-statistics.csv').open(encoding='utf-8-sig',newline='') as stream:
        archived_summary_csv=list(csv.DictReader(stream))
    for saved,original in zip(archived_summary_csv,experiment['summary']):
        for field,value in original.items():
            assert abs(float(saved[field])-value)<1e-9,(field,value)
    with (args.results/"qaoa-30seed/qaoa-runs.csv").open(encoding="utf-8-sig",newline="") as f:
        csvrows = {(int(r["reps"]),int(r["seed"])):r for r in csv.DictReader(f)}
    assert len(csvrows) == 150
    assert set(csvrows) == set(itertools.product(range(1,6),range(1,31)))
    checks, params = [], []
    for r in experiment["runs"]:
        p, seed, s = r["reps"], r["seed"], r["solve"]
        row = csvrows[p,seed]
        assert energy(q,s["values"]) == s["energy"] == float(row["bestEnergy"])
        assert all(s["bestSampleBitstring"][-1-i]==str(x) for i,x in enumerate(s["values"]))
        assert len(s["optimalParameters"]) == 2*p
        assert len(s["convergence"]) == s["optimizerEvaluations"] <= 200
        assert r["matchesReferenceOptimum"] == (s["energy"] == 0)
        assert (row["matchesReferenceOptimum"].lower()=="true") == r["matchesReferenceOptimum"]
        assert (row["bestFeasible"].lower()=="true") == r["decoded"]["feasible"]
        for field in ["feasibleSampleRate","optimalSampleRate","expectationEnergy","optimizerEvaluations","bestSampleCount","modalEnergy","modalCount","uniqueBitstrings"]:
            assert abs(float(row[field])-s[field]) < 1e-9
        assert abs(float(row["runtimeSeconds"])-r["runtimeSeconds"]) < 1e-9
        for field in ["feasibleSampleRate","optimalSampleRate"]:
            assert abs(s[field]*4096-round(s[field]*4096)) < 1e-9
        initial = np.random.default_rng(seed).uniform(0,math.pi,2*p)
        pr = statevector(e, s["optimalParameters"], p)
        initial_pr = statevector(e, initial, p)
        expected = float(pr@e)
        initial_expected = float(initial_pr@e)
        error = abs(expected-s["expectationEnergy"])
        initial_error = abs(initial_expected-s["convergence"][0])
        assert error < 1e-8 and initial_error < 1e-8, (p,seed,error,initial_error)
        assert abs(pr.sum()-1) < 1e-10
        modal_values = [int(b) for b in s["modalBitstring"][::-1]]
        assert energy(q,modal_values) == s["modalEnergy"]
        checks.append({"p":p,"seed":seed,"initial_expectation_error":initial_error,"final_expectation_error":error,"archived_expectation":s["expectationEnergy"],"recomputed_expectation":expected,"ideal_optimal_shot_probability":float(pr[e==0].sum()),"ideal_feasible_shot_probability":float(pr[feasible_masks].sum()),"archived_optimal_shots":round(4096*s["optimalSampleRate"]),"archived_feasible_shots":round(4096*s["feasibleSampleRate"])})
        for k in range(2*p):
            params.append({"p":p,"seed":seed,"parameter_index":k,"name":f"beta[{k}]" if k<p else f"gamma[{k-p}]","initial_reconstructed_radians":float(initial[k]),"optimized_archived_radians":s["optimalParameters"][k],"initial_provenance":"reconstructed default_rng(seed).uniform(0,pi,2p); verified against first archived objective"})
    summary = []
    for p in range(1,6):
        runs = [r for r in experiment["runs"] if r["reps"]==p]
        vals = np.array([r["solve"]["energy"] for r in runs])
        runtime = np.array([r["runtimeSeconds"] for r in runs])
        feasible = sum(r["decoded"]["feasible"] for r in runs)
        optimal = sum(r["matchesReferenceOptimum"] for r in runs)
        ci = wilson(optimal,30)
        row = {"p":p,"runs":30,"feasible_best_count":feasible,"optimal_best_count":optimal,"optimal_rate_percent":100*optimal/30,"wilson_low_percent":100*ci[0],"wilson_high_percent":100*ci[1],"energy_mean":float(vals.mean()),"energy_std":float(vals.std(ddof=1)),"energy_median":float(np.median(vals)),"q1":float(np.quantile(vals,.25)),"q3":float(np.quantile(vals,.75)),"runtime_mean_seconds":float(runtime.mean()),"optimizer_success_count":sum(r["solve"]["optimizerSuccess"] for r in runs),"budget_limit_count":sum(r["solve"]["optimizerEvaluations"]==200 for r in runs)}
        original = next(s for s in experiment["summary"] if s["reps"]==p)
        for field,value in [("bestEnergyMean",row["energy_mean"]),("bestEnergyStd",row["energy_std"]),("bestEnergyQ1",row["q1"]),("bestEnergyQ3",row["q3"]),("runtimeSecondsMean",row["runtime_mean_seconds"]),("optimalBestCount",optimal),("feasibleBestCount",feasible),("optimalBestCi95Low",ci[0]),("optimalBestCi95High",ci[1])]:
            assert abs(original[field]-value)<1e-9,(p,field)
        half=float(student_t.ppf(.975,29))*float(runtime.std(ddof=1))/math.sqrt(30)
        assert abs(original["runtimeSecondsCi95Low"]-(runtime.mean()-half))<1e-9
        assert abs(original["runtimeSecondsCi95High"]-(runtime.mean()+half))<1e-9
        summary.append(row)
    csvout(args.out/"qaoa-independent-checks.csv",checks)
    csvout(args.out/"qaoa-parameters.csv",params)
    csvout(args.out/"qaoa-summary-recomputed.csv",summary)
    audit["qaoa"] = {"runs":len(checks),"parameterCount":len(params),"maxInitialExpectationError":max(c["initial_expectation_error"] for c in checks),"maxFinalExpectationError":max(c["final_expectation_error"] for c in checks),"summary":summary,"config":experiment["config"]}
    noisy=read(args.results/"qaoa-noisy/p1-seed1-noisy.json")
    assert energy(q,noisy["analysis"]["bestValues"]) == noisy["analysis"]["bestEnergy"] == 0
    for field in ["feasibleSampleRate","optimalSampleRate"]:
        assert abs(noisy["analysis"][field]*4096-round(noisy["analysis"][field]*4096))<1e-9
    audit["noisy"] = {"training_reps":1,"training_seed":1,"sampling_seed":noisy["seed"],"shots":noisy["shots"],"feasibleShots":round(4096*noisy["analysis"]["feasibleSampleRate"]),"optimalShots":round(4096*noisy["analysis"]["optimalSampleRate"]),"metrics":noisy["backendMetadata"],"optimalParameters":experiment["runs"][0]["solve"]["optimalParameters"],"fullHistogramPresent":False,"exactAerVersionRecorded":False,"optimizationLevelRecordedInResult":False}
    paper=audit['instances']['qubo-paper']['data']
    sensitivity=[]
    for lam in [0.5,1,2,3,4,10,20]:
        best=math.inf;feasible_min=math.inf;infeasible_min=math.inf
        for starts in itertools.product(*([None]+list(range(paper['horizon']-j['processingTime']+1)) for j in paper['jobs'])):
            c=sum(cost(j,s) for j,s in zip(paper['jobs'],starts) if s is not None)
            violations=sum(s is None for s in starts)
            for i,j in itertools.combinations(range(3),2):
                a,b=starts[i],starts[j]
                if a is not None and b is not None and a<b+paper['jobs'][j]['processingTime'] and b<a+paper['jobs'][i]['processingTime']:
                    violations+=1
            value=c+lam*violations
            best=min(best,value)
            if violations:infeasible_min=min(infeasible_min,value)
            else:feasible_min=min(feasible_min,value)
        sensitivity.append({'lambda':lam,'global_min_energy':best,'feasible_min':feasible_min,'infeasible_min':infeasible_min,'ground_states_all_feasible':infeasible_min>best})
    audit['penalty_sensitivity']=sensitivity
    csvout(args.out/'penalty-sensitivity-independent.csv',sensitivity)
    audit["status"]="PASS for the explicit audit scope; historical environment and full histograms remain incomplete"
    dump(args.out/"audit.json",audit)
    print(json.dumps({"quboCoefficientChecks":len(qubo_rows),"qaoaRunsChecked":len(checks),"maxStatevectorExpectationError":audit["qaoa"]["maxFinalExpectationError"],"tinyEnumeration":audit["tiny_full_enumeration"],"summary":summary},ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
