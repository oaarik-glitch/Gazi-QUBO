param(
    [string]$PythonExecutable = ".\.venv\Scripts\python.exe",
    [string]$OutputPath = ".\revision-environment-current.json"
)

$ErrorActionPreference = "Stop"
if (-not (Test-Path -LiteralPath $PythonExecutable -PathType Leaf)) {
    throw "Python bulunamadı. -PythonExecutable ile deney sanal ortamının python.exe yolunu verin."
}
$PythonProbe = @'
import sys, platform, json, importlib.metadata, datetime
packages = {d.metadata.get('Name', 'unknown'): d.version for d in importlib.metadata.distributions()}
print(json.dumps({'recordKind':'current-environment-inspection',
 'historicalEnvironmentUnchanged':None,
 'collectedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'pythonExecutable':sys.executable, 'pythonVersion':sys.version,
 'platform':platform.platform(), 'installedPackages':dict(sorted(packages.items()))}, ensure_ascii=True))
'@
$ProbeJson = & $PythonExecutable -c $PythonProbe
if ($LASTEXITCODE -ne 0) { throw "Python ortam bilgileri alınamadı." }
$Record = $ProbeJson | ConvertFrom-Json
$DotnetInfo = if (Get-Command dotnet -ErrorAction SilentlyContinue) { (& dotnet --info 2>&1 | Out-String) } else { "not found" }
$GurobiVersion = if (Get-Command gurobi_cl -ErrorAction SilentlyContinue) { (& gurobi_cl --version 2>&1 | Out-String) } else { "not found on PATH" }
$Record | Add-Member -NotePropertyName dotnetInfo -NotePropertyValue $DotnetInfo
$Record | Add-Member -NotePropertyName gurobiCliVersion -NotePropertyValue $GurobiVersion
$Record | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host "Ortam kaydı oluşturuldu: $OutputPath"
Write-Host "Bu güncel ortam kaydıdır; tarihsel deney ortamının değişmediği ayrıca doğrulanmalıdır."
