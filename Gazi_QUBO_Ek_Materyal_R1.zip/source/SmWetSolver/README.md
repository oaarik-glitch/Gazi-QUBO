# Tek makine ağırlıklı erkenlik-geçlik: C# + Gurobi

Bu Visual Studio solution, aynı `1||sum(alpha_i E_i + beta_i T_i)` problemini üç eşdeğer MILP formülasyonuyla çözer:

1. **Position-Based:** İş-pozisyon ataması, pozisyonlar arasında açık `G_k` idle-time değişkenleri ve iş tamamlanma zamanları.
2. **Time-Indexed:** Her iş için olası başlangıç zamanları ve her zaman biriminde tek makine kapasitesi.
3. **Precedence-Based:** Her iş çifti için tek ikili önce-sonra değişkeni ve ayrıştırıcı çakışmazlık kısıtları.

Üç solver da ortak JSON örneğini okur ve ortak sonuç biçimini üretir. Sonuçlar model değişkenlerinden çıkarıldıktan sonra `ScheduleValidator` tarafından modelden bağımsız olarak yeniden denetlenir.

Formül-kod ayrıntıları için `docs/MODEL_NOTES_TR.md` dosyasına bakın.

## Gereksinimler

- .NET 8 SDK
- Gurobi Optimizer lisansı
- NuGet erişimi

Solution, resmî `Gurobi.Optimizer` 13.0.3 NuGet paketini kullanır. Paket ikili dosyaları sağlar; model çözmek için geçerli bir Gurobi lisansı yine gereklidir.

## Hızlı doğrulama

Gurobi gerektirmeyen exact permutation-DP doğrulayıcı:

```bash
dotnet run --project src/SmWetSolver.VerifyCli -- instances/three-job.json
```

Python 3 ile bağımsız doğrulama:

```bash
python3 tools/verify_sample.py
```

Beklenen amaç değeri `2`'dir. Bir optimal sıra `J1 -> J3 -> J2` olup idle time içeren bir optimal zamanlama `J1:[1,3]`, `J3:[3,4]`, `J2:[4,7]` biçimindedir. Aynı sıra için başka optimal idle-time dağılımları da bulunabilir.

## Üç Gurobi modelini birlikte çalıştırma

```bash
dotnet restore SmWetSolver.sln
dotnet run --project src/SmWetSolver.Cli -- instances/three-job.json \
  --time-limit 300 \
  --mip-gap 0 \
  --output results
```

Program küçük örneklerde önce exact sonucu üretir, ardından üç Gurobi modelini çözer. Dört amaç değeri eşit değilse veya herhangi bir çizelge bağımsız doğrulamayı geçmezse program hata koduyla durur.

## n=4,5,6 batch doğrulaması

Önce sabit seed ile her boyut için beş, toplam 15 örnek üretin:

```powershell
dotnet run --project .\src\SmWetSolver.InstanceGeneratorCli\SmWetSolver.InstanceGeneratorCli.csproj -- --output .\instances\generated --seed 20260902 --sizes 4,5,6 --per-size 5
```

Ardından her örneği exact DP ve üç Gurobi modeliyle çözün:

```powershell
dotnet run --project .\src\SmWetSolver.BatchCli\SmWetSolver.BatchCli.csproj -- .\instances\generated --output .\batch-results --time-limit 300 --mip-gap 0 --threads 1
```

Batch koşusunda Gurobi günlükleri varsayılan olarak kapalıdır. Ayrıntılı solver günlüğü için komuta `--show-log` eklenebilir. Herhangi bir model exact optimumdan ayrılır veya bağımsız fizibilite kontrolünü geçemezse program hata koduyla durur.

`batch-results/batch-comparison.csv`, makaledeki klasik model karşılaştırması için gerekli amaç, çözüm süresi, değişken ve kısıt sayılarını tek satır/örnek biçiminde içerir.

## Üretilen dosyalar

- `results/results.json`: Tüm çözüm ve çizelge ayrıntıları.
- `results/results-summary.csv`: Amaç, süre, MIPGap, düğüm, değişken ve kısıt sayıları.
- `results/schedules.csv`: Her model için iş bazında başlangıç, tamamlanma, erkenlik, geçlik ve maliyet.
- `batch-results/batch-comparison.csv`: Her örnek için üç modelin karşılaştırmalı özeti.

## Örnek veri biçimi

```json
{
  "name": "my-instance",
  "horizon": 30,
  "jobs": [
    {
      "id": 1,
      "processingTime": 4,
      "dueDate": 10,
      "earlinessWeight": 2,
      "tardinessWeight": 5
    }
  ]
}
```

`horizon` çıkarılırsa yazılım `max(d_i) + sum(p_i)` değerini kullanır. Tüm zaman verileri ve ağırlıklar tamsayıdır. Ağırlıklar sıfır olabilir; işlem süreleri pozitif olmalıdır.

## Deneylerde önerilen kullanım

- Küçük örnekler (`n <= 9`): exact + üç Gurobi modeli; matematiksel eşdeğerlik kontrolü.
- Orta/büyük örnekler: `--skip-exact` ile yalnızca üç Gurobi modeli.
- Karşılaştırılabilir süreler için aynı makine, aynı Gurobi sürümü, aynı thread sayısı ve aynı süre sınırı kullanılmalıdır.
- Her koşuda `results-summary.csv` ve `schedules.csv` saklanmalıdır; bu alanlar makaledeki deney tablolarına doğrudan aktarılabilir.

## Üç QUBO formülasyonunu üretme ve doğrulama

Üç QUBO'yu aynı küçük örnek üzerinde Gurobi ile küresel olarak çözmek ve klasik
optimumla karşılaştırmak için PowerShell'de tek satır halinde çalıştırın:

```powershell
dotnet run --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\qubo-tiny-three-job.json --formulation all --solver gurobi --output .\qubo-results\all-formulations --time-limit 300 --threads 1
```

Komut; `time-indexed`, `position` ve `precedence` QUBO JSON dosyalarını, her
formülasyonun doğrulama raporunu ve ortak
`qubo-formulation-comparison.csv/json` dosyalarını üretir. Ortak raporda ikili
değişken sayısı, karesel bağ sayısı/yoğunluğu, en büyük mutlak katsayı, enerji,
özgün çizelgeleme amacı, ceza enerjisi, süre ve klasik optimum eşleşmesi bulunur.

Tek bir QUBO için `--formulation time-indexed`, `--formulation position` veya
`--formulation precedence` kullanılabilir. Sıra ve önce-sonra QUBO'ları 26
değişken sınırını genellikle aştığından `--solver gurobi` önerilir.

### Zaman indisli QUBO için küçük ve makale örnekleri

14 değişkenli küçük QUBO'yu bütün bit dizilerini tarayarak çözün:

```powershell
dotnet run --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\qubo-tiny-three-job.json --solver exhaustive --output .\qubo-results\tiny
```

Makaledeki 33 değişkenli QUBO'yu Gurobi ile exact çözün:

```powershell
dotnet run --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\three-job.json --solver gurobi --output .\qubo-results\paper --time-limit 300 --threads 1
```

`--solver auto` seçilirse değişken sayısı `--exact-limit` değerini aşmıyorsa exhaustive, aksi durumda Gurobi kullanılır. Ceza katsayısı verilmezse uygulanabilir üst sınır `U` hesaplanır ve güvenli `A=U+1` seçilir.

Üretilen dosyalar:

- `time-indexed-qubo.json`: Qiskit'e aktarılacak üst üçgensel QUBO katsayıları ve değişken eşlemesi.
- `time-indexed-validation.json`: exact çözüm, decoded çizelge, ceza enerjisi ve klasik optimum karşılaştırması.

Matematiksel katsayı konvansiyonu ve ceza ispatı `docs/TIME_INDEXED_QUBO.md` dosyasındadır.

## Ceza katsayısı duyarlılığı

Makaledeki örneği varsayılan ceza ızgarasıyla çözmek için:

```powershell
dotnet run --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\three-job.json --solver gurobi --penalty-sweep --output .\qubo-results\penalty --time-limit 300 --threads 1
```

`U>0` olduğunda varsayılan değerler `0,25U`, `0,5U`, `U`, `U+1`, `2U`,
`5U` ve `10U`'dur. Özel bir ızgara `--penalties 0.5,1,2,3,4,10,20`
ile verilebilir. Düşük cezalarda uygulanamaz çözüm çıkması deneyin beklenen bir
parçasıdır; program güvenli `A>U` satırlarının tamamının klasik optimumla
eşleşmesini başarı koşulu olarak kullanır.

Üretilen dosyalar:

- `penalty-sensitivity.csv`: Makale tablosuna uygun satır bazlı rapor.
- `penalty-sensitivity.json`: Çözüm ve seçilen değişken ayrıntıları.

## Qiskit exact ve noiseless QAOA

Python sanal ortamını bir kez kurun:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\qiskit_run\requirements.txt
```

14 değişkenli tiny QUBO için Qiskit eşleme denetimi ve exact çözüm:

```powershell
python .\qiskit_run\solve_qubo.py .\qubo-results\tiny\time-indexed-qubo.json --mode exact --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\tiny\time-indexed-validation.json --output .\qiskit-results\tiny-exact.json
```

Noiseless statevector QAOA:

```powershell
python .\qiskit_run\solve_qubo.py .\qubo-results\tiny\time-indexed-qubo.json --mode qaoa --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\tiny\time-indexed-validation.json --reps 1 --shots 2048 --maxiter 100 --seed 42 --output .\qiskit-results\tiny-qaoa-p1.json
```

Qiskit sonucu `qiskit-result.json` şemasında QUBO enerjisini, seçilen bitleri,
decoded çizelgeyi, fizibiliteyi, ceza enerjisini ve klasik optimum eşleşmesini
saklar. Ayrıntılar `qiskit_run/README.md` dosyasındadır.

## 30 seed, güven aralığı ve grafikler

Hakem değerlendirmesine uygun istatistiksel özet için her p düzeyinde varsayılan
30 bağımsız seed çalıştırılır:

```powershell
python .\qiskit_run\run_qaoa_grid.py .\qubo-results\all-formulations\time-indexed-qubo.json --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\all-formulations\time-indexed-validation.json --reps 1:5 --seeds 1:30 --shots 4096 --maxiter 200 --output-dir .\qiskit-results\qaoa-30seed
```

`qaoa-summary-statistics.csv`; ortalama, örnek standart sapması, medyan, Q1-Q3,
Student-t %95 ortalama güven aralığı ve başarı oranları için Wilson %95 güven
aralığını içerir. 300 dpi PNG ve ölçeklenebilir SVG şekilleri üretmek için:

```powershell
python .\qiskit_run\make_figures.py .\qiskit-results\qaoa-30seed\qaoa-runs.csv --qubo-comparison .\qubo-results\all-formulations\qubo-formulation-comparison.csv --output-dir .\qiskit-results\figures
```

## Gürültülü benzetim ve IBM Quantum örneklemesi

Önce ideal QAOA ile eğitilmiş parametreleri kaydedin. Ardından aynı parametreleri
özel depolarizasyon ve okuma hatası modeli altında örnekleyin:

```powershell
python .\qiskit_run\sample_qaoa_backend.py .\qubo-results\all-formulations\time-indexed-qubo.json .\qiskit-results\tiny-qaoa-p1.json --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\all-formulations\time-indexed-validation.json --mode noisy --shots 4096 --output .\qiskit-results\tiny-noisy-p1.json
```

IBM hesabı `QiskitRuntimeService.save_account(...)` ile yerel olarak
yapılandırıldıktan sonra gerçek cihaz örneklemesi için aynı komutta `--mode ibm`
ve istenirse `--backend <backend-adı>` kullanılır. API anahtarını komut satırına,
çıktı dosyasına veya paylaşılacak ZIP'e eklemeyin. Bu protokol, ideal parametre
eğitimi ile gürültülü/gerçek cihaz örnekleme etkisini birbirinden ayırır.

## Makaleye aktarılacak minimum deney seti

- Üç QUBO için aynı örnekte Gurobi-QUBO küresel optimum ve klasik optimum eşleşmesi.
- Zaman indisli küçük QUBO için p=1..5 ve her p düzeyinde en az 30 seed.
- Aynı seçilmiş parametreler için ideal, gürültülü Aer ve erişim varsa IBM backend.
- Enerji kutu grafiği, başarı oranı + %95 güven aralığı, süre + %95 güven aralığı,
  QUBO değişken/bağ karşılaştırması.
- Sentetik ölçek tablosu ayrı biçimde “teorik/temsili” olarak etiketlenmeli;
  gerçekleşen QUBO boyutları `qubo-formulation-comparison.csv` ile ayrıca verilmelidir.

Tüm yerel revizyon deneylerini tek komutla yürütmek için, sanal ortam etkinken:

```powershell
.\run_revision_experiments.ps1 -SeedCount 30 -Shots 4096 -MaxIter 200 -RunNoisy
```

Yoğun pozisyon QUBO'su 300 saniyede kapanmazsa doğrulama aşamasını daha uzun
süre, Gurobi'nun otomatik çekirdek seçimi ve görünür ilerleme günlüğüyle yürütün:

```powershell
.\run_revision_experiments.ps1 -SkipQaoa -TimeLimit 1800 -Threads 0 -ShowSolverLog
```

Pozisyon QUBO doğrulayıcısı, klasik exact çizelgeyi eksiksiz biçimde QUBO bit
vektörüne kodlar ve enerjisinin klasik amaçla aynı olduğunu çözümden önce sınar.
`A>U` güvenli ceza koşulu sağlandığında bu değer sertifikalı hedef olarak
Gurobi'ya verilir. Böylece hedef bit vektörü bulunduğunda gereksiz dal-sınır
araması sonlandırılır; raporda bu durum `CERTIFIED_TARGET_REACHED` olarak
gösterilir.

Üç QUBO doğrulaması tamamlandıktan sonra bunları yeniden çözmeden QAOA ve grafik
aşamasına devam etmek için:

```powershell
.\run_revision_experiments.ps1 -SkipQubo -SeedCount 30 -Shots 4096 -MaxIter 200 -RunNoisy
```

PowerShell betiği yarıda kesilirse aynı komut yeniden verilebilir; QAOA sürücüsü
tamamlanan p-seed çiftlerini çıktı dizininden okuyup kaldığı yerden devam eder.
Sonuçlar `revision-results\revision-results.zip` içinde toplanır.
