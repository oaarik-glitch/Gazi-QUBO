param(
    [int]$SeedCount = 30,
    [int]$Shots = 4096,
    [int]$MaxIter = 200,
    [int]$TimeLimit = 300,
    [int]$Threads = 1,
    [switch]$SkipQaoa,
    [switch]$SkipQubo,
    [switch]$ShowSolverLog,
    [switch]$RunNoisy
)

$ErrorActionPreference = "Stop"
$env:PYTHONUTF8 = "1"
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Assert-NativeSuccess {
    param([Parameter(Mandatory = $true)][string]$Step)

    if ($LASTEXITCODE -ne 0) {
        throw "$Step failed (exit code: $LASTEXITCODE). Copy the first error block shown above; later file-not-found messages are only secondary errors."
    }
}

function Assert-ExpectedFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Step
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "$Step did not create the expected file: $Path"
    }
}

if ($SeedCount -lt 2) {
    throw "SeedCount must be at least 2. Use 30 or more for the article experiments."
}
if ($Threads -lt 0) {
    throw "Threads cannot be negative. Use 0 for Gurobi automatic thread selection."
}
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET SDK was not found. Install .NET 8 SDK and open a new PowerShell window."
}
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python was not found. Activate the project's .venv first."
}

New-Item -ItemType Directory -Force -Path .\revision-results | Out-Null

Write-Host "[1/6] Restoring and building the .NET solution..."
dotnet restore .\SmWetSolver.sln
Assert-NativeSuccess ".NET restore"
dotnet build .\SmWetSolver.sln -c Release --no-restore
Assert-NativeSuccess ".NET build"

$SolverLogArguments = if ($ShowSolverLog) { @("--show-log") } else { @() }

if (-not $SkipQubo) {
    Write-Host "[2/6] Validating all three QUBO formulations on the tiny instance..."
    dotnet run -c Release --no-build --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\qubo-tiny-three-job.json --formulation all --solver gurobi --output .\revision-results\qubo-tiny --time-limit $TimeLimit --threads $Threads @SolverLogArguments
    Assert-NativeSuccess "Tiny-instance QUBO generation and Gurobi validation"
    Assert-ExpectedFile ".\revision-results\qubo-tiny\time-indexed-qubo.json" "Tiny-instance QUBO generation"
    Assert-ExpectedFile ".\revision-results\qubo-tiny\position-qubo.json" "Tiny-instance QUBO generation"
    Assert-ExpectedFile ".\revision-results\qubo-tiny\precedence-qubo.json" "Tiny-instance QUBO generation"
    python .\tools\verify_all_qubo_outputs.py .\revision-results\qubo-tiny
    Assert-NativeSuccess "Tiny-instance output verification"

    Write-Host "[3/6] Validating all three QUBO formulations on the article instance..."
    dotnet run -c Release --no-build --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\three-job.json --formulation all --solver gurobi --output .\revision-results\qubo-paper --time-limit $TimeLimit --threads $Threads @SolverLogArguments
    Assert-NativeSuccess "Article-instance QUBO generation and Gurobi validation"
    Assert-ExpectedFile ".\revision-results\qubo-paper\time-indexed-qubo.json" "Article-instance QUBO generation"
    Assert-ExpectedFile ".\revision-results\qubo-paper\position-qubo.json" "Article-instance QUBO generation"
    Assert-ExpectedFile ".\revision-results\qubo-paper\precedence-qubo.json" "Article-instance QUBO generation"
    python .\tools\verify_all_qubo_outputs.py .\revision-results\qubo-paper
    Assert-NativeSuccess "Article-instance output verification"
} else {
    Write-Host "[2-3/6] Reusing and verifying existing QUBO outputs because -SkipQubo was used..."
    foreach ($Directory in @(".\revision-results\qubo-tiny", ".\revision-results\qubo-paper")) {
        Assert-ExpectedFile "$Directory\time-indexed-qubo.json" "Existing QUBO verification"
        Assert-ExpectedFile "$Directory\position-qubo.json" "Existing QUBO verification"
        Assert-ExpectedFile "$Directory\precedence-qubo.json" "Existing QUBO verification"
        python .\tools\verify_all_qubo_outputs.py $Directory
        Assert-NativeSuccess "Existing QUBO verification for $Directory"
    }
}

if (-not $SkipQaoa) {
    python -c "import matplotlib, qiskit, qiskit_aer, scipy"
    Assert-NativeSuccess "Python/Qiskit dependency check"

    $SeedRange = "1:$SeedCount"
    Write-Host "[4/6] Running QAOA for p=1..5 and seeds $SeedRange..."
    python .\qiskit_run\run_qaoa_grid.py .\revision-results\qubo-tiny\time-indexed-qubo.json --instance .\instances\qubo-tiny-three-job.json --validation .\revision-results\qubo-tiny\time-indexed-validation.json --reps 1:5 --seeds $SeedRange --shots $Shots --maxiter $MaxIter --output-dir .\revision-results\qaoa-30seed
    Assert-NativeSuccess "QAOA grid"
    Assert-ExpectedFile ".\revision-results\qaoa-30seed\qaoa-runs.csv" "QAOA grid"
    Assert-ExpectedFile ".\revision-results\qaoa-30seed\qaoa-summary-statistics.csv" "QAOA grid"

    if ($RunNoisy) {
        Write-Host "[5/6] Sampling the first pre-registered QAOA run with Aer noise..."
        python .\qiskit_run\sample_qaoa_backend.py .\revision-results\qubo-tiny\time-indexed-qubo.json .\revision-results\qaoa-30seed\qaoa-experiment.json --run-index 0 --instance .\instances\qubo-tiny-three-job.json --validation .\revision-results\qubo-tiny\time-indexed-validation.json --mode noisy --shots $Shots --output .\revision-results\qaoa-noisy\p1-seed1-noisy.json
        Assert-NativeSuccess "Noisy Aer sampling"
        Assert-ExpectedFile ".\revision-results\qaoa-noisy\p1-seed1-noisy.json" "Noisy Aer sampling"
    } else {
        Write-Host "[5/6] Noisy Aer sampling was not requested."
    }

    Write-Host "[6/6] Creating article figures..."
    python .\qiskit_run\make_figures.py .\revision-results\qaoa-30seed\qaoa-runs.csv --qubo-comparison .\revision-results\qubo-tiny\qubo-formulation-comparison.csv --output-dir .\revision-results\figures
    Assert-NativeSuccess "Article figure generation"
    Assert-ExpectedFile ".\revision-results\figures\sekil-enerji-kutu-grafigi.png" "Article figure generation"
} else {
    Write-Host "[4-6/6] QAOA and figure steps were skipped because -SkipQaoa was used."
}

$Archive = ".\revision-results\revision-results.zip"
if (Test-Path $Archive) {
    Remove-Item $Archive -Force
}
$ItemsToArchive = Get-ChildItem .\revision-results | Where-Object { $_.Name -ne "revision-results.zip" }
Compress-Archive -Path $ItemsToArchive.FullName -DestinationPath $Archive -CompressionLevel Optimal
Write-Host "Completed successfully. Upload this file for the Word update: $Archive"
