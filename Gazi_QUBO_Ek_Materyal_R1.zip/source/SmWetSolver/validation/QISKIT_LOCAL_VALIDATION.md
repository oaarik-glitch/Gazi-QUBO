# Qiskit yerel doğrulama kaydı

Doğrulama ortamı:

- Qiskit: `2.5.2`
- NumPy: `2.5.2`
- SciPy: `1.18.1`

## API smoke testi

İki değişkenli yapay QUBO üzerinde exact ve `p=1` statevector QAOA çalıştırıldı.
Her iki yöntemin gözlediği en iyi enerji `-1` oldu. QUBO→Ising eşleme denetiminin
en büyük mutlak hatası `0` bulundu.

## 14 qubit çizelgeleme örneği

Exact modda:

- QUBO enerjisi: `0`
- Çizelgeleme amacı: `0`
- Fizibilite: başarılı
- Klasik optimumla eşleşme: başarılı
- QUBO→Ising en büyük mutlak hata: `0`

Tek bir `p=1`, `seed=42`, `shots=2048`, `maxiter=100` QAOA koşusunda gözlenen
en iyi enerji `2` oldu. Çözüm uygulanabilirdi, fakat exact optimum `0` bulunamadı.
Bu sonuç QAOA'nın yaklaşık ve stokastik niteliğiyle uyumludur; makalede tek koşu
yerine çoklu `p` ve seed deneyi yapılmasının gerekliliğini gösterir.

## 33 qubit makale QUBO'su

Kullanıcının gönderdiği QUBO JSON'u Qiskit `SparsePauliOp` biçimine çevrildi:

- Qubit sayısı: `33`
- Pauli terimi: `289`
- Sabit Ising ofseti: `393,5`
- 256 rastgele bit dizisinde en büyük eşleme hatası: `0`

33 qubit statevector belleği sıradan bilgisayar için uygun olmadığından bu model
üzerinde yerel QAOA çalıştırılmamıştır. Exact referans, kullanıcı ortamındaki
Gurobi-QUBO çözümü olan `2` değeridir.
