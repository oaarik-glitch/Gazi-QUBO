# Kullanıcı ortamında üç işli Gurobi doğrulaması

Üç işli makale örneği kullanıcı bilgisayarında Gurobi ile başarıyla çalıştırılmıştır. Tüm modeller `OPTIMAL`, `MIPGap=0` ve `validation_passed=true` sonucunu vermiştir.

| Model | Amaç | Süre (s) | Düğüm | Değişken | Kısıt |
|---|---:|---:|---:|---:|---:|
| Exact-Permutation-DP | 2 | 0.0011385 | — | — | — |
| Position-Based | 2 | 0.0160000 | 1 | 24 | 33 |
| Time-Indexed | 2 | 0.0009999 | 1 | 33 | 15 |
| Precedence-Based | 2 | 0.0000000 | 1 | 12 | 12 |

Position-Based, exact çözümle aynı `J1:[1,3]`, `J3:[3,4]`, `J2:[4,7]` çizelgesini bulmuştur. Time-Indexed ve Precedence-Based ise aynı amaç değerine sahip alternatif optimum `J1:[1,3]`, `J3:[4,5]`, `J2:[5,8]` çizelgesini bulmuştur. Bu durum birden fazla optimum bulunduğunu ve idle time'ın üç modelde de korunduğunu doğrular.

Bu örnek çok küçük olduğu için süreler model performansı sıralaması amacıyla kullanılmamalıdır.
