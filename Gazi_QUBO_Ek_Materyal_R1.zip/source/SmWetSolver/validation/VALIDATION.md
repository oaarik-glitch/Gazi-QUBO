# Doğrulama kaydı

## Kapsam

- Üç Gurobi solver kaynak dosyasının varlığı ve temel model bileşenleri statik olarak denetlenir.
- `three-job.json` örneği, Gurobi'dan bağımsız permutation + dinamik programlama algoritmasıyla çözülür.
- Exact algoritma, sabit sıra altında pozisyonlar arasında ve ilk iş öncesinde idle time'a izin verir.

## Beklenen sonuç

- Amaç değeri: `2`
- Bir optimal sıra: `J1 -> J3 -> J2`
- Tüm işler bir kez çizelgelenir, çakışma yoktur ve tamamlanmalar zaman ufku içindedir.

## Gerçekleştirilen bağımsız kontroller

- Position/permutation-DP, time-indexed başlangıç kombinasyonları ve pairwise precedence başlangıç kombinasyonları ayrı ayrı tarandı; üçünde de amaç değeri `2` bulundu.
- Precedence modelindeki iki Big-M eşitsizliği, `2 <= H <= 14` aralığında bütün uygun `p_i`, `p_j`, `S_i`, `S_j` ve `y_ij` değerleri üzerinde exhaustive olarak denetlendi; temsil edilen küme çakışmazlık koşuluyla tam eşleşti.
- Position modelindeki çift yönlü Big-M tamamlanma-zamanı bağlantısı, `1 <= H <= 14` aralığında bütün tamamlanma zamanı ve ikili atama değerleri üzerinde denetlendi; `x_ik=1` iken eşitliği zorladı, `x_ik=0` iken bağlantıyı gevşetti.
- Proje XML dosyaları ve örnek JSON dosyası ayrıştırıldı; C# kaynaklarında ayraç dengesi denetlendi.
- ZIP bütünlük testi hatasız tamamlandı.

## n=4,5,6 benchmark kontrolü

- Sabit `20260902` seed'i ve platformdan bağımsız SplitMix64 üreteciyle her iş sayısı için beş, toplam 15 örnek tanımlandı.
- Beş `(T,R)` çifti sırasıyla `(0.2,0.4)`, `(0.4,0.6)`, `(0.6,0.8)`, `(0.8,1.0)` ve `(0.5,0.2)` olarak kullanıldı.
- On beş örneğin tümü bağımsız Python permutation-DP uygulamasıyla exact çözüldü.
- Exact amaç değerleri `validation/benchmark-exact-results.csv` dosyasına kaydedildi.
- C# batch runner, her örnekte bu exact çözümü üç Gurobi modeliyle karşılaştıracak şekilde yapılandırıldı.

## Ortam sınırı

Bu paketin üretildiği çalışma ortamında .NET SDK ve Gurobi lisansı bulunmadığından gerçek Gurobi optimizasyon koşusu burada yapılamamıştır. `tools/verify_sample.py` bağımsız exact sonucu ve kaynak yapısını doğrular. Kullanıcı ortamındaki ilk Gurobi koşusu için README'deki komut kullanılmalıdır; CLI üç modelin amaç eşdeğerliğini ve çizelge fizibilitesini otomatik olarak denetler.
