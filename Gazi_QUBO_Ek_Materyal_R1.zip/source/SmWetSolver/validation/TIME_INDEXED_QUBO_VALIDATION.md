# Time-indexed QUBO doğrulama kaydı

## Küçük QUBO örneği

- İş sayısı: 3
- Zaman ufku: 5
- QUBO değişkeni: 14
- Doğrusal terim: 13
- İkinci derece terim: 47
- Uygulanabilir üst sınır: `U=0`
- Güvenli ceza: `A=1`
- Taranan bit dizisi: `2^14=16.384`
- Exact QUBO minimum enerjisi: `0`
- Çizelge: `J1:[1,2]`, `J2:[2,4]`, `J3:[4,5]`
- Fizibilite: başarılı

## Makaledeki üç işli örnek

- QUBO değişkeni: 33
- Heuristik uygulanabilir üst sınır: `U=2`
- Varsayılan güvenli ceza: `A=3`
- Bilinen optimal çizelgenin QUBO enerjisi: `2`
- Klasik exact optimum: `2`

`A=3>U=2` olduğundan bütün uygulanamaz bit dizilerinin enerjisi en az 3'tür. Enerjisi 2 olan uygulanabilir çözüm bilindiği ve klasik optimum da 2 olduğu için QUBO optimumunun 2 olduğu exhaustive `2^33` tarama yapılmadan kanıtlanır.

## Kullanıcı ortamındaki Gurobi-QUBO koşusu

- Durum: `OPTIMAL`
- Enerji: `2`
- Ceza enerjisi: `0`
- MIP gap: `0`
- Düğüm sayısı: `1`
- Çözüm süresi: yaklaşık `0,004 s`
- Seçilen değişkenler: `x_1_1`, `x_3_4`, `x_2_5`
- Çizelge: `J1:[1,3]`, `J3:[4,5]`, `J2:[5,8]`
- Çizelgeleme amacı: `2`
- Klasik optimumla eşleşme: başarılı

Bu çizelge klasik exact çözücünün bildirdiği `J1:[1,3]`, `J3:[3,4]`,
`J2:[4,7]` çizelgesinden farklıdır; ancak iki çizelgenin amaç değeri de 2'dir.
Dolayısıyla bunlar aynı örneğin alternatif optimal çözümleridir.

## Cebirsel denetim

Küçük ve makale örneklerinde 2.000'er rastgele bit dizisi için:

```text
genişletilmiş QUBO enerjisi = doğrusal amaç + doğrudan hesaplanan ceza
```

eşitliği doğrulanmıştır. Küçük örnek ayrıca bütün 16.384 bit dizisi üzerinde exhaustive çözülmüştür.
