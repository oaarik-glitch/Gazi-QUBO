#!/usr/bin/env python3
"""Independent sample verifier; requires only Python's standard library."""

from __future__ import annotations

import itertools
import json
import math
import sys
from pathlib import Path


def cost(job: dict[str, int], completion: int) -> int:
    early = max(0, job["dueDate"] - completion)
    tardy = max(0, completion - job["dueDate"])
    return job["earlinessWeight"] * early + job["tardinessWeight"] * tardy


def best_timing(order: tuple[dict[str, int], ...], horizon: int) -> tuple[int, list[int]]:
    states: dict[int, tuple[int, list[int]]] = {}
    first = order[0]
    for completion in range(first["processingTime"], horizon + 1):
        states[completion] = (cost(first, completion), [completion])

    for job in order[1:]:
        next_states: dict[int, tuple[int, list[int]]] = {}
        for completion in range(job["processingTime"], horizon + 1):
            candidates = [
                (value, path)
                for previous_completion, (value, path) in states.items()
                if previous_completion <= completion - job["processingTime"]
            ]
            if candidates:
                value, path = min(candidates, key=lambda item: item[0])
                next_states[completion] = (value + cost(job, completion), path + [completion])
        states = next_states

    return min(states.values(), key=lambda item: item[0])


def solve(instance_path: Path) -> tuple[int, tuple[dict[str, int], ...], list[int]]:
    data = json.loads(instance_path.read_text(encoding="utf-8"))
    jobs = data["jobs"]
    horizon = data.get("horizon") or max(job["dueDate"] for job in jobs) + sum(
        job["processingTime"] for job in jobs
    )

    best_value = math.inf
    best_order: tuple[dict[str, int], ...] | None = None
    best_completions: list[int] | None = None
    for order in itertools.permutations(jobs):
        value, completions = best_timing(order, horizon)
        if value < best_value:
            best_value = value
            best_order = order
            best_completions = completions

    assert best_order is not None and best_completions is not None
    return int(best_value), best_order, best_completions


def brute_force_start_models(instance_path: Path) -> tuple[int, int]:
    """Validate time-indexed and pairwise non-overlap feasible sets independently."""
    data = json.loads(instance_path.read_text(encoding="utf-8"))
    jobs = data["jobs"]
    horizon = data.get("horizon") or max(job["dueDate"] for job in jobs) + sum(
        job["processingTime"] for job in jobs
    )
    domains = [range(horizon - job["processingTime"] + 1) for job in jobs]
    time_indexed_best = math.inf
    precedence_best = math.inf

    for starts in itertools.product(*domains):
        occupied = [0] * horizon
        capacity_ok = True
        for job, start in zip(jobs, starts, strict=True):
            for tau in range(start, start + job["processingTime"]):
                occupied[tau] += 1
                if occupied[tau] > 1:
                    capacity_ok = False
                    break
            if not capacity_ok:
                break

        pairwise_ok = all(
            starts[i] + jobs[i]["processingTime"] <= starts[j]
            or starts[j] + jobs[j]["processingTime"] <= starts[i]
            for i in range(len(jobs))
            for j in range(i + 1, len(jobs))
        )
        value = sum(
            cost(job, start + job["processingTime"])
            for job, start in zip(jobs, starts, strict=True)
        )
        if capacity_ok:
            time_indexed_best = min(time_indexed_best, value)
        if pairwise_ok:
            precedence_best = min(precedence_best, value)

    return int(time_indexed_best), int(precedence_best)


def audit_sources(project_root: Path) -> None:
    required = [
        "src/SmWetSolver.Gurobi/Solvers/PositionBasedGurobiSolver.cs",
        "src/SmWetSolver.Gurobi/Solvers/TimeIndexedGurobiSolver.cs",
        "src/SmWetSolver.Gurobi/Solvers/PrecedenceBasedGurobiSolver.cs",
        "src/SmWetSolver.Core/Services/ScheduleValidator.cs",
        "src/SmWetSolver.Core/Services/ExactSmallInstanceSolver.cs",
    ]
    missing = [relative for relative in required if not (project_root / relative).is_file()]
    if missing:
        raise SystemExit("Eksik kaynaklar: " + ", ".join(missing))

    position = (project_root / required[0]).read_text(encoding="utf-8")
    time_indexed = (project_root / required[1]).read_text(encoding="utf-8")
    precedence = (project_root / required[2]).read_text(encoding="utf-8")
    checks = {
        "pozisyon modelinde idle değişkeni": "idleBeforePosition" in position,
        "zaman indisli modelde kapasite": "capacity_" in time_indexed,
        "önce-sonra modelinde ikili sıra": "GRB.BINARY" in precedence and "nonoverlap_" in precedence,
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise SystemExit("Kaynak denetimi başarısız: " + ", ".join(failed))


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    instance_path = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else project_root / "instances/three-job.json"
    audit_sources(project_root)
    value, order, completions = solve(instance_path)
    time_indexed_value, precedence_value = brute_force_start_models(instance_path)

    print(f"instance={instance_path.name}")
    print(f"position_objective={value}")
    print(f"time_indexed_objective={time_indexed_value}")
    print(f"precedence_objective={precedence_value}")
    print("order=" + "->".join(f"J{job['id']}" for job in order))
    for job, completion in zip(order, completions, strict=True):
        start = completion - job["processingTime"]
        print(f"J{job['id']}: start={start}, completion={completion}, cost={cost(job, completion)}")
    print("source_audit=PASS")

    if len({value, time_indexed_value, precedence_value}) != 1:
        raise SystemExit("Üç formülasyonun bağımsız amaç değerleri eşleşmedi.")
    if instance_path.name == "three-job.json" and value != 2:
        raise SystemExit(f"Beklenen örnek amaç değeri 2, bulunan {value}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
