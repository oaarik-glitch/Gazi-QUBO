#!/usr/bin/env python3
"""Reproduce the C# SplitMix64 benchmark plan and solve all cases exactly."""

from __future__ import annotations

import itertools
import math

MASK = (1 << 64) - 1
BASE_SEED = 20_260_902
T_FACTORS = [0.2, 0.4, 0.6, 0.8, 0.5]
R_RANGES = [0.4, 0.6, 0.8, 1.0, 0.2]


class SplitMix64:
    def __init__(self, seed: int) -> None:
        self.state = seed & MASK

    def next_uint64(self) -> int:
        self.state = (self.state + 0x9E3779B97F4A7C15) & MASK
        value = self.state
        value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & MASK
        value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & MASK
        return (value ^ (value >> 31)) & MASK

    def next_int(self, minimum: int, maximum: int) -> int:
        return minimum + self.next_uint64() % (maximum - minimum + 1)


def generate(job_count: int, replicate: int) -> tuple[str, list[dict[str, int]], int, float, float]:
    seed = BASE_SEED + job_count * 1_000 + replicate
    random = SplitMix64(seed)
    processing = [random.next_int(1, 10) for _ in range(job_count)]
    total_processing = sum(processing)
    tardiness_factor = T_FACTORS[(replicate - 1) % len(T_FACTORS)]
    due_date_range = R_RANGES[(replicate - 1) % len(R_RANGES)]
    lower = max(0, math.floor(total_processing * (1 - tardiness_factor - due_date_range / 2)))
    upper = max(lower, math.ceil(total_processing * (1 - tardiness_factor + due_date_range / 2)))
    jobs = [
        {
            "id": index + 1,
            "p": processing[index],
            "d": random.next_int(lower, upper),
            "we": random.next_int(1, 5),
            "wt": random.next_int(1, 5),
        }
        for index in range(job_count)
    ]
    horizon = max(job["d"] for job in jobs) + total_processing
    return f"n{job_count:02d}_r{replicate:02d}_s{seed}", jobs, horizon, tardiness_factor, due_date_range


def job_cost(job: dict[str, int], completion: int) -> int:
    return job["we"] * max(0, job["d"] - completion) + job["wt"] * max(0, completion - job["d"])


def fixed_order_objective(order: tuple[dict[str, int], ...], horizon: int) -> int:
    first = order[0]
    previous = [math.inf] * (horizon + 1)
    for completion in range(first["p"], horizon + 1):
        previous[completion] = job_cost(first, completion)

    for job in order[1:]:
        prefix = [math.inf] * (horizon + 1)
        running = math.inf
        for completion in range(horizon + 1):
            running = min(running, previous[completion])
            prefix[completion] = running
        current = [math.inf] * (horizon + 1)
        for completion in range(job["p"], horizon + 1):
            earlier = prefix[completion - job["p"]]
            if earlier < math.inf:
                current[completion] = earlier + job_cost(job, completion)
        previous = current
    return int(min(previous))


def exact_objective(jobs: list[dict[str, int]], horizon: int) -> int:
    return min(fixed_order_objective(order, horizon) for order in itertools.permutations(jobs))


def main() -> int:
    print("instance,job_count,replicate,seed,T,R,horizon,exact_objective")
    objectives: list[int] = []
    names: set[str] = set()
    for job_count in (4, 5, 6):
        for replicate in range(1, 6):
            name, jobs, horizon, tardiness_factor, due_date_range = generate(job_count, replicate)
            if name in names:
                raise SystemExit(f"Yinelenen örnek adı: {name}")
            names.add(name)
            objective = exact_objective(jobs, horizon)
            objectives.append(objective)
            seed = BASE_SEED + job_count * 1_000 + replicate
            print(
                f"{name},{job_count},{replicate},{seed},{tardiness_factor:g},"
                f"{due_date_range:g},{horizon},{objective}"
            )

    if len(names) != 15 or any(value < 0 for value in objectives):
        raise SystemExit("Benchmark doğrulaması başarısız.")
    print("benchmark_exact_audit=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
