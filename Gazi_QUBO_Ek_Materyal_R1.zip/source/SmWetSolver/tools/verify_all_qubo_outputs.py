#!/usr/bin/env python3
"""Fail unless all three C# QUBO validation reports match the classical optimum."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", help="QUBO output directory")
    args = parser.parse_args()
    root = Path(args.directory)
    failures: list[str] = []
    for formulation in ("time-indexed", "position", "precedence"):
        path = root / f"{formulation}-validation.json"
        if not path.exists():
            failures.append(f"eksik: {path}")
            continue
        report = json.loads(path.read_text(encoding="utf-8-sig"))
        decoded = report["decoded"]
        ok = (
            bool(report["matchesClassicalOptimum"])
            and bool(decoded["feasible"])
            and abs(float(decoded["penaltyEnergy"])) <= 1e-6
            and abs(float(decoded["schedulingObjective"]) - float(report["classicalOptimum"])) <= 1e-6
        )
        print(
            f"{formulation}: {'PASS' if ok else 'FAIL'}; "
            f"m={report['numVariables']}; Q={report['quadraticTermCount']}; "
            f"Z={decoded['schedulingObjective']}"
        )
        if not ok:
            failures.append(formulation)
    if failures:
        raise SystemExit("Üçlü QUBO doğrulaması başarısız: " + ", ".join(failures))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
