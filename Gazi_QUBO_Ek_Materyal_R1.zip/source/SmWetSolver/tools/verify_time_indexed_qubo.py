#!/usr/bin/env python3
"""Independent algebra and exhaustive checks for TimeIndexedQuboBuilder."""

from __future__ import annotations

import itertools
import json
import math
import random
from pathlib import Path


def cost(job: dict[str, int], completion: int) -> int:
    early = max(0, job["dueDate"] - completion)
    tardy = max(0, completion - job["dueDate"])
    return job["earlinessWeight"] * early + job["tardinessWeight"] * tardy


def upper_bound(data: dict) -> int:
    jobs = data["jobs"]
    horizon = data["horizon"]
    total = sum(job["processingTime"] for job in jobs)
    orders = [
        jobs,
        sorted(jobs, key=lambda job: (job["dueDate"], job["id"])),
        sorted(jobs, key=lambda job: (job["processingTime"], job["id"])),
    ]
    best = math.inf
    for order in orders:
        for block_start in range(horizon - total + 1):
            completion = block_start
            value = 0
            for job in order:
                completion += job["processingTime"]
                value += cost(job, completion)
            best = min(best, value)
    return int(best)


def build(data: dict) -> dict:
    jobs = data["jobs"]
    horizon = data["horizon"]
    bound = upper_bound(data)
    penalty = bound + 1
    variables: list[dict[str, int]] = []
    index: dict[tuple[int, int], int] = {}
    for i, job in enumerate(jobs):
        for start in range(horizon - job["processingTime"] + 1):
            index[(i, start)] = len(variables)
            variables.append({"job": i, "start": start})

    linear: dict[int, float] = {}
    quadratic: dict[tuple[int, int], float] = {}
    constant = penalty * len(jobs)

    def add_linear(i: int, value: float) -> None:
        linear[i] = linear.get(i, 0.0) + value

    def add_quadratic(i: int, j: int, value: float) -> None:
        if i > j:
            i, j = j, i
        quadratic[(i, j)] = quadratic.get((i, j), 0.0) + value

    for i, job in enumerate(jobs):
        indices = [index[(i, start)] for start in range(horizon - job["processingTime"] + 1)]
        for variable in indices:
            add_linear(variable, -penalty)
        for first, second in itertools.combinations(indices, 2):
            add_quadratic(first, second, 2 * penalty)

    for i, job in enumerate(jobs):
        for start in range(horizon - job["processingTime"] + 1):
            add_linear(index[(i, start)], cost(job, start + job["processingTime"]))

    overlap_pairs = []
    for i, first_job in enumerate(jobs):
        for j in range(i + 1, len(jobs)):
            second_job = jobs[j]
            for first_start in range(horizon - first_job["processingTime"] + 1):
                for second_start in range(horizon - second_job["processingTime"] + 1):
                    overlap = (
                        first_start < second_start + second_job["processingTime"]
                        and second_start < first_start + first_job["processingTime"]
                    )
                    if overlap:
                        pair = (index[(i, first_start)], index[(j, second_start)])
                        add_quadratic(*pair, penalty)
                        overlap_pairs.append(pair)

    linear = {i: value for i, value in linear.items() if abs(value) > 1e-12}
    quadratic = {pair: value for pair, value in quadratic.items() if abs(value) > 1e-12}
    return {
        "constant": constant,
        "linear": linear,
        "quadratic": quadratic,
        "variables": variables,
        "index": index,
        "penalty": penalty,
        "upper_bound": bound,
        "overlap_pairs": overlap_pairs,
    }


def expanded_energy(model: dict, bits: list[int]) -> float:
    value = model["constant"]
    value += sum(coefficient * bits[i] for i, coefficient in model["linear"].items())
    value += sum(coefficient * bits[i] * bits[j] for (i, j), coefficient in model["quadratic"].items())
    return value


def direct_energy(data: dict, model: dict, bits: list[int]) -> float:
    jobs = data["jobs"]
    objective = 0
    assignment_penalty = 0
    for i, job in enumerate(jobs):
        selected = []
        for start in range(data["horizon"] - job["processingTime"] + 1):
            bit = bits[model["index"][(i, start)]]
            objective += bit * cost(job, start + job["processingTime"])
            selected.append(bit)
        assignment_penalty += (1 - sum(selected)) ** 2
    overlap_penalty = sum(bits[i] * bits[j] for i, j in model["overlap_pairs"])
    return objective + model["penalty"] * (assignment_penalty + overlap_penalty)


def verify_instance(path: Path, exhaustive: bool) -> tuple[dict, float | None, list[int] | None]:
    data = json.loads(path.read_text(encoding="utf-8"))
    model = build(data)
    rng = random.Random(20260902)
    for _ in range(2_000):
        bits = [rng.randrange(2) for _ in model["variables"]]
        assert abs(expanded_energy(model, bits) - direct_energy(data, model, bits)) < 1e-9

    best_energy = None
    best_bits = None
    if exhaustive:
        best_energy = math.inf
        for mask in range(1 << len(model["variables"])):
            bits = [(mask >> index) & 1 for index in range(len(model["variables"]))]
            value = expanded_energy(model, bits)
            if value < best_energy:
                best_energy = value
                best_bits = bits
    return model, best_energy, best_bits


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    tiny_path = root / "instances/qubo-tiny-three-job.json"
    paper_path = root / "instances/three-job.json"
    tiny, tiny_energy, tiny_bits = verify_instance(tiny_path, exhaustive=True)
    paper, _, _ = verify_instance(paper_path, exhaustive=False)

    assert len(tiny["variables"]) == 14
    assert tiny["upper_bound"] == 0 and tiny["penalty"] == 1
    assert tiny_energy == 0 and tiny_bits is not None
    selected = [
        variable
        for variable, bit in zip(tiny["variables"], tiny_bits, strict=True)
        if bit
    ]
    assert selected == [
        {"job": 0, "start": 1},
        {"job": 1, "start": 2},
        {"job": 2, "start": 4},
    ]

    # Known optimal paper schedule: J1 [1,3], J3 [3,4], J2 [4,7].
    paper_bits = [0] * len(paper["variables"])
    paper_bits[paper["index"][(0, 1)]] = 1
    paper_bits[paper["index"][(1, 4)]] = 1
    paper_bits[paper["index"][(2, 3)]] = 1
    assert direct_energy(json.loads(paper_path.read_text()), paper, paper_bits) == 2
    assert expanded_energy(paper, paper_bits) == 2

    print("tiny_variables=14")
    print(f"tiny_linear_terms={len(tiny['linear'])}")
    print(f"tiny_quadratic_terms={len(tiny['quadratic'])}")
    print("tiny_upper_bound=0")
    print("tiny_penalty=1")
    print("tiny_qubo_optimum=0")
    print("tiny_schedule=J1[1,2],J2[2,4],J3[4,5]")
    print(f"paper_variables={len(paper['variables'])}")
    print(f"paper_upper_bound={paper['upper_bound']}")
    print(f"paper_penalty={paper['penalty']}")
    print("paper_known_optimal_energy=2")
    print("qubo_algebra_random_audit=PASS")
    print("qubo_exhaustive_audit=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
