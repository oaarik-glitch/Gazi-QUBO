#!/usr/bin/env python3
"""Create 300-dpi publication figures from QAOA and QUBO comparison CSV files."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
from pathlib import Path

import matplotlib.pyplot as plt
from scipy.stats import t as student_t


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Makale için deney grafikleri üret.")
    parser.add_argument("qaoa_runs", help="qaoa-runs.csv veya eski qaoa-grid.csv")
    parser.add_argument("--qubo-comparison", help="qubo-formulation-comparison.csv")
    parser.add_argument("--output-dir", default="qiskit-results/figures")
    return parser.parse_args()


def read_csv(path: str | Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def truth(value: str) -> bool:
    return value.strip().lower() in {"true", "1", "yes"}


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2 * total)) / denominator
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def mean_ci(values: list[float]) -> tuple[float, float, float]:
    mean = statistics.fmean(values)
    if len(values) < 2:
        return mean, mean, mean
    half = float(student_t.ppf(0.975, len(values) - 1)) * statistics.stdev(values) / math.sqrt(len(values))
    return mean, mean - half, mean + half


def save(fig, output_dir: Path, stem: str) -> None:
    fig.tight_layout()
    fig.savefig(output_dir / f"{stem}.png", dpi=300, bbox_inches="tight")
    fig.savefig(output_dir / f"{stem}.svg", bbox_inches="tight")
    plt.close(fig)


def qaoa_figures(rows: list[dict[str, str]], output_dir: Path) -> None:
    groups = {
        reps: [row for row in rows if int(row["reps"]) == reps]
        for reps in sorted({int(row["reps"]) for row in rows})
    }
    labels = [str(reps) for reps in groups]

    fig, axis = plt.subplots(figsize=(6.7, 3.7))
    axis.boxplot(
        [[float(row["bestEnergy"]) for row in group] for group in groups.values()],
        tick_labels=labels,
        showmeans=True,
    )
    axis.set_xlabel("QAOA katman sayısı, p")
    axis.set_ylabel("En iyi QUBO enerjisi")
    axis.set_title("QAOA koşumlarında enerji dağılımı")
    axis.grid(axis="y", alpha=0.25)
    save(fig, output_dir, "sekil-enerji-kutu-grafigi")

    feasible_rates: list[float] = []
    optimal_rates: list[float] = []
    feasible_errors = [[], []]
    optimal_errors = [[], []]
    for group in groups.values():
        n = len(group)
        feasible = sum(truth(row.get("bestFeasible", "")) for row in group)
        optimal = sum(truth(row.get("matchesReferenceOptimum", "")) for row in group)
        for count, rates, errors in (
            (feasible, feasible_rates, feasible_errors),
            (optimal, optimal_rates, optimal_errors),
        ):
            rate = count / n
            low, high = wilson(count, n)
            rates.append(100 * rate)
            errors[0].append(100 * (rate - low))
            errors[1].append(100 * (high - rate))
    x = list(range(len(labels)))
    width = 0.36
    fig, axis = plt.subplots(figsize=(6.7, 3.8))
    axis.bar([value - width / 2 for value in x], feasible_rates, width, yerr=feasible_errors,
             capsize=3, label="Uygulanabilir en iyi çözüm")
    axis.bar([value + width / 2 for value in x], optimal_rates, width, yerr=optimal_errors,
             capsize=3, label="Optimum en iyi çözüm")
    axis.set_xticks(x, labels)
    axis.set_xlabel("QAOA katman sayısı, p")
    axis.set_ylabel("Koşum oranı (%)")
    axis.set_ylim(0, 105)
    axis.set_title("Başarı oranları ve %95 Wilson güven aralıkları")
    axis.legend(frameon=False)
    axis.grid(axis="y", alpha=0.25)
    save(fig, output_dir, "sekil-basari-guven-araligi")

    runtime_stats = [mean_ci([float(row["runtimeSeconds"]) for row in group]) for group in groups.values()]
    means = [item[0] for item in runtime_stats]
    errors = [
        [item[0] - item[1] for item in runtime_stats],
        [item[2] - item[0] for item in runtime_stats],
    ]
    fig, axis = plt.subplots(figsize=(6.7, 3.7))
    axis.errorbar(list(groups), means, yerr=errors, marker="o", capsize=4)
    axis.set_xlabel("QAOA katman sayısı, p")
    axis.set_ylabel("Çözüm süresi (s)")
    axis.set_title("Ortalama çözüm süresi ve %95 güven aralığı")
    axis.grid(alpha=0.25)
    save(fig, output_dir, "sekil-sure-guven-araligi")


def qubo_figure(rows: list[dict[str, str]], output_dir: Path) -> None:
    labels = [row["formulation"] for row in rows]
    variables = [int(row["variables"]) for row in rows]
    couplings = [int(row["quadratic_terms"]) for row in rows]
    density = [100 * float(row["coupling_density"]) for row in rows]
    x = list(range(len(labels)))
    width = 0.36
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.6))
    axes[0].bar([value - width / 2 for value in x], variables, width, label="İkili değişken")
    axes[0].bar([value + width / 2 for value in x], couplings, width, label="Karesel bağ")
    axes[0].set_xticks(x, labels, rotation=15)
    axes[0].set_ylabel("Adet")
    axes[0].set_title("QUBO boyutu")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.25)
    axes[1].bar(x, density)
    axes[1].set_xticks(x, labels, rotation=15)
    axes[1].set_ylabel("Bağ yoğunluğu (%)")
    axes[1].set_title("QUBO grafik yoğunluğu")
    axes[1].grid(axis="y", alpha=0.25)
    save(fig, output_dir, "sekil-qubo-formulasyon-karsilastirma")


def main() -> int:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    qaoa_figures(read_csv(args.qaoa_runs), output_dir)
    if args.qubo_comparison:
        qubo_figure(read_csv(args.qubo_comparison), output_dir)
    print(f"Grafikler: {output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
