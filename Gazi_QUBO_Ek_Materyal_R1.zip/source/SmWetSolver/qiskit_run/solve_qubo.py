#!/usr/bin/env python3
"""Solve SmWetSolver's upper-triangular QUBO JSON with Qiskit.

The exact mode is ground truth for small models. The qaoa mode uses Qiskit's
StatevectorEstimator/StatevectorSampler and SciPy COBYLA. Both modes audit the
QUBO-to-Ising mapping before solving.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


def load_json(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def validate_qubo(qubo: dict[str, Any]) -> None:
    required = {"schemaVersion", "name", "numVariables", "constant", "variables", "linear", "quadratic"}
    missing = sorted(required.difference(qubo))
    if missing:
        raise ValueError(f"QUBO JSON alanları eksik: {', '.join(missing)}")
    n = int(qubo["numVariables"])
    indices = sorted(int(variable["index"]) for variable in qubo["variables"])
    if indices != list(range(n)):
        raise ValueError("Değişken indeksleri 0..numVariables-1 olmalıdır.")
    for term in qubo["linear"]:
        if not 0 <= int(term["index"]) < n:
            raise ValueError("Geçersiz doğrusal terim indeksi.")
    pairs: set[tuple[int, int]] = set()
    for term in qubo["quadratic"]:
        i, j = int(term["i"]), int(term["j"])
        if not (0 <= i < j < n):
            raise ValueError("İkinci derece terimler üst üçgensel i<j biçiminde olmalıdır.")
        if (i, j) in pairs:
            raise ValueError(f"Yinelenen ikinci derece terim: ({i},{j}).")
        pairs.add((i, j))


def evaluate_qubo(qubo: dict[str, Any], values: list[int]) -> float:
    n = int(qubo["numVariables"])
    if len(values) != n or any(value not in (0, 1) for value in values):
        raise ValueError("Çözüm vektörü QUBO boyutunda ve ikili olmalıdır.")
    energy = float(qubo["constant"])
    energy += sum(float(term["value"]) * values[int(term["index"])] for term in qubo["linear"])
    energy += sum(
        float(term["value"]) * values[int(term["i"])] * values[int(term["j"])]
        for term in qubo["quadratic"]
    )
    return energy


def qubo_to_ising(qubo: dict[str, Any]):
    """Return (SparsePauliOp without scalar offset, offset) for x=(1-Z)/2."""
    try:
        from qiskit.quantum_info import SparsePauliOp
    except ImportError as exc:
        raise RuntimeError(
            "Qiskit kurulu değil. Önce: python -m pip install -r qiskit_run/requirements.txt"
        ) from exc

    n = int(qubo["numVariables"])
    offset = float(qubo["constant"])
    z = np.zeros(n, dtype=float)
    zz: dict[tuple[int, int], float] = {}
    for term in qubo["linear"]:
        i, coefficient = int(term["index"]), float(term["value"])
        offset += coefficient / 2.0
        z[i] -= coefficient / 2.0
    for term in qubo["quadratic"]:
        i, j, coefficient = int(term["i"]), int(term["j"]), float(term["value"])
        offset += coefficient / 4.0
        z[i] -= coefficient / 4.0
        z[j] -= coefficient / 4.0
        zz[(i, j)] = zz.get((i, j), 0.0) + coefficient / 4.0

    paulis: list[tuple[str, complex]] = []
    for i, coefficient in enumerate(z):
        if abs(coefficient) > 1e-12:
            label = ["I"] * n
            label[n - 1 - i] = "Z"
            paulis.append(("".join(label), complex(coefficient)))
    for (i, j), coefficient in zz.items():
        if abs(coefficient) > 1e-12:
            label = ["I"] * n
            label[n - 1 - i] = "Z"
            label[n - 1 - j] = "Z"
            paulis.append(("".join(label), complex(coefficient)))
    if not paulis:
        paulis.append(("I" * n, 0.0j))
    return SparsePauliOp.from_list(paulis).simplify(), offset


def audit_ising_mapping(qubo: dict[str, Any], operator, offset: float, samples: int, seed: int) -> float:
    n = int(qubo["numVariables"])
    rng = np.random.default_rng(seed)
    bit_vectors: list[list[int]]
    if n <= 12:
        bit_vectors = [[(mask >> i) & 1 for i in range(n)] for mask in range(1 << n)]
    else:
        bit_vectors = [rng.integers(0, 2, size=n).tolist() for _ in range(samples)]
    max_error = 0.0
    for values in bit_vectors:
        ising_energy = offset
        for label, coefficient in operator.to_list():
            eigenvalue = 1
            for index, value in enumerate(values):
                if label[n - 1 - index] == "Z":
                    eigenvalue *= 1 - 2 * value
            ising_energy += float(np.real(coefficient)) * eigenvalue
        max_error = max(max_error, abs(evaluate_qubo(qubo, values) - ising_energy))
    if max_error > 1e-8:
        raise RuntimeError(f"QUBO→Ising eşleme denetimi başarısız; en büyük hata={max_error}.")
    return max_error


def exact_solve(qubo: dict[str, Any], max_variables: int) -> dict[str, Any]:
    n = int(qubo["numVariables"])
    if n > max_variables:
        raise ValueError(
            f"Exact tarama için {n} değişken çok büyük; sınır {max_variables}. "
            "Küçük örneği kullanın veya --max-exact değerini bilinçli olarak artırın."
        )
    best_energy = math.inf
    best_values: list[int] = []
    for mask in range(1 << n):
        values = [(mask >> i) & 1 for i in range(n)]
        energy = evaluate_qubo(qubo, values)
        if energy < best_energy - 1e-10:
            best_energy, best_values = energy, values
    return {
        "method": "exact-enumeration",
        "status": "OPTIMAL",
        "energy": best_energy,
        "values": best_values,
        "evaluatedStates": 1 << n,
    }


def bitstring_to_values(bitstring: str, n: int) -> list[int]:
    compact = bitstring.replace(" ", "")
    if len(compact) != n:
        raise ValueError(f"Bit dizisi uzunluğu {len(compact)}, beklenen {n}.")
    return [int(compact[-1 - index]) for index in range(n)]


def qaoa_solve(
    qubo: dict[str, Any],
    operator,
    offset: float,
    reps: int,
    shots: int,
    maxiter: int,
    seed: int,
    max_statevector_qubits: int,
    instance: dict[str, Any] | None,
    reference_energy: float | None,
) -> dict[str, Any]:
    from qiskit.circuit.library import qaoa_ansatz
    from qiskit.primitives import StatevectorEstimator, StatevectorSampler
    from scipy.optimize import minimize

    n = int(qubo["numVariables"])
    if n > max_statevector_qubits:
        raise ValueError(
            f"Statevector QAOA için {n} qubit bellek açısından riskli; varsayılan sınır "
            f"{max_statevector_qubits}. 14 değişkenli tiny QUBO ile başlayın."
        )
    if reps <= 0 or shots <= 0 or maxiter <= 0:
        raise ValueError("reps, shots ve maxiter pozitif olmalıdır.")

    ansatz = qaoa_ansatz(operator, reps=reps)
    parameters = list(ansatz.parameters)
    estimator = StatevectorEstimator(seed=seed)
    history: list[float] = []

    def objective(theta: np.ndarray) -> float:
        pub = (ansatz, operator, np.asarray(theta, dtype=float))
        value = float(np.real(estimator.run([pub]).result()[0].data.evs)) + offset
        history.append(value)
        return value

    rng = np.random.default_rng(seed)
    initial = rng.uniform(0.0, math.pi, len(parameters))
    optimization = minimize(
        objective,
        initial,
        method="COBYLA",
        options={"maxiter": maxiter, "rhobeg": 0.5},
    )
    bound = ansatz.assign_parameters(dict(zip(parameters, optimization.x)))
    measured = bound.copy()
    measured.measure_all()
    counts = StatevectorSampler(seed=seed).run([measured], shots=shots).result()[0].data.meas.get_counts()

    candidates: list[tuple[float, int, str, list[int]]] = []
    feasible_count = 0
    optimal_count = 0
    for bitstring, count in counts.items():
        values = bitstring_to_values(bitstring, n)
        energy = evaluate_qubo(qubo, values)
        integer_count = int(count)
        candidates.append((energy, integer_count, bitstring, values))
        if instance is not None and decode_schedule(qubo, values, instance, energy).get("feasible"):
            feasible_count += integer_count
        if reference_energy is not None and abs(energy - reference_energy) <= 1e-8:
            optimal_count += integer_count
    best_energy, best_count, best_bitstring, best_values = min(candidates, key=lambda item: (item[0], -item[1]))
    modal_energy, modal_count, modal_bitstring, _ = max(candidates, key=lambda item: item[1])
    top_counts = sorted(counts.items(), key=lambda item: item[1], reverse=True)[:20]
    return {
        "method": "statevector-qaoa",
        "status": "COMPLETED" if optimization.success else "OPTIMIZER_STOPPED",
        "energy": best_energy,
        "values": best_values,
        "expectationEnergy": float(optimization.fun),
        "bestSampleBitstring": best_bitstring,
        "bestSampleCount": best_count,
        "modalBitstring": modal_bitstring,
        "modalCount": modal_count,
        "modalEnergy": modal_energy,
        "shots": shots,
        "reps": reps,
        "seed": seed,
        "optimizer": "COBYLA",
        "optimizerSuccess": bool(optimization.success),
        "optimizerMessage": str(optimization.message),
        "optimizerEvaluations": int(optimization.nfev),
        "optimalParameters": [float(value) for value in optimization.x],
        "convergence": history,
        "uniqueBitstrings": len(counts),
        "feasibleSampleRate": feasible_count / shots if instance is not None else None,
        "optimalSampleRate": optimal_count / shots if reference_energy is not None else None,
        "topCounts": [{"bitstring": key, "count": int(value)} for key, value in top_counts],
    }


def decode_schedule(qubo: dict[str, Any], values: list[int], instance: dict[str, Any] | None, energy: float):
    selected = [variable for variable in qubo["variables"] if values[int(variable["index"])] == 1]
    result: dict[str, Any] = {"selectedVariables": [variable["name"] for variable in selected]}
    if instance is None:
        return result

    jobs = {int(job["id"]): job for job in instance["jobs"]}
    errors: list[str] = []
    schedule: list[dict[str, Any]] = []
    formulation = qubo.get("formulation", "time-indexed")

    def weighted_value(kind: str, *, job_id: int | None = None, position: int | None = None) -> int:
        return sum(
            int(variable.get("weight", 1))
            for variable in selected
            if variable.get("kind") == kind
            and (job_id is None or int(variable.get("jobId", -1)) == job_id)
            and (position is None or int(variable.get("position", -1)) == position)
        )

    starts: dict[int, int] = {}
    if formulation == "time-indexed":
        for job_id in jobs:
            choices = [
                variable for variable in selected
                if variable.get("kind", "start") == "start"
                and int(variable.get("jobId", -1)) == job_id
            ]
            if len(choices) != 1:
                errors.append(f"İş {job_id} için {len(choices)} başlangıç seçildi; beklenen 1.")
                continue
            starts[job_id] = int(choices[0]["startTime"])
    elif formulation == "precedence":
        starts = {job_id: weighted_value("start-bit", job_id=job_id) for job_id in jobs}
    elif formulation == "position":
        seen: set[int] = set()
        for position in range(1, len(jobs) + 1):
            choices = [
                variable for variable in selected
                if variable.get("kind") == "assignment"
                and int(variable.get("position", -1)) == position
            ]
            if len(choices) != 1:
                errors.append(
                    f"Pozisyon {position} için {len(choices)} iş seçildi; beklenen 1."
                )
                continue
            job_id = int(choices[0]["jobId"])
            if job_id in seen:
                errors.append(f"İş {job_id} birden fazla pozisyona atandı.")
            seen.add(job_id)
            completion = weighted_value("completion-bit", position=position)
            starts[job_id] = completion - int(jobs[job_id]["processingTime"])
        missing = sorted(set(jobs).difference(seen))
        if missing:
            errors.append(f"Atanmayan işler: {missing}.")
    else:
        raise ValueError(f"Desteklenmeyen QUBO formülasyonu: {formulation}")

    for job_id, start in starts.items():
        job = jobs[job_id]
        completion = start + int(job["processingTime"])
        earliness = max(0, int(job["dueDate"]) - completion)
        tardiness = max(0, completion - int(job["dueDate"]))
        cost = float(job["earlinessWeight"]) * earliness + float(job["tardinessWeight"]) * tardiness
        schedule.append({
            "jobId": job_id,
            "start": start,
            "completion": completion,
            "earliness": earliness,
            "tardiness": tardiness,
            "cost": cost,
        })
    schedule.sort(key=lambda item: (item["start"], item["jobId"]))
    if any(item["start"] < 0 for item in schedule):
        errors.append("Negatif başlangıç zamanı üretildi.")
    horizon = int(instance.get("horizon") or (
        max(int(job["dueDate"]) for job in jobs.values())
        + sum(int(job["processingTime"]) for job in jobs.values())
    ))
    if any(item["completion"] > horizon for item in schedule):
        errors.append("Zaman ufku aşıldı.")
    for left, right in zip(schedule, schedule[1:]):
        if left["completion"] > right["start"]:
            errors.append(f"İş {left['jobId']} ve {right['jobId']} çakışıyor.")
    objective = sum(item["cost"] for item in schedule) if len(schedule) == len(jobs) else None
    result.update({
        "feasible": not errors,
        "schedulingObjective": objective,
        "penaltyEnergy": energy - objective if objective is not None else None,
        "schedule": schedule,
        "errors": errors,
    })
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="SmWetSolver QUBO JSON dosyasını Qiskit ile çöz.")
    parser.add_argument("qubo", help="time-indexed-qubo.json yolu")
    parser.add_argument("--mode", choices=("exact", "qaoa"), default="exact")
    parser.add_argument("--instance", help="Çizelgeyi doğrulamak için kaynak instance JSON")
    parser.add_argument("--validation", help="Klasik optimumu karşılaştırmak için validation JSON")
    parser.add_argument("--output", default="qiskit-result.json")
    parser.add_argument("--max-exact", type=int, default=24)
    parser.add_argument("--mapping-audit-samples", type=int, default=64)
    parser.add_argument("--reps", type=int, default=1)
    parser.add_argument("--shots", type=int, default=2048)
    parser.add_argument("--maxiter", type=int, default=100)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-statevector-qubits", type=int, default=20)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    qubo = load_json(args.qubo)
    validate_qubo(qubo)
    instance = load_json(args.instance) if args.instance else None
    reference = load_json(args.validation) if args.validation else None
    reference_optimum = float(reference["classicalOptimum"]) if reference else None
    operator, offset = qubo_to_ising(qubo)
    mapping_error = audit_ising_mapping(
        qubo, operator, offset, args.mapping_audit_samples, args.seed
    )
    solve = (
        exact_solve(qubo, args.max_exact)
        if args.mode == "exact"
        else qaoa_solve(
            qubo,
            operator,
            offset,
            args.reps,
            args.shots,
            args.maxiter,
            args.seed,
            args.max_statevector_qubits,
            instance,
            reference_optimum,
        )
    )
    decoded = decode_schedule(qubo, solve["values"], instance, float(solve["energy"]))
    matches_reference = (
        bool(decoded.get("feasible"))
        and reference_optimum is not None
        and decoded.get("schedulingObjective") is not None
        and abs(float(decoded["schedulingObjective"]) - reference_optimum) <= 1e-8
        and abs(float(decoded["penaltyEnergy"])) <= 1e-8
    )
    report = {
        "schemaVersion": "1.0",
        "quboName": qubo["name"],
        "numVariables": int(qubo["numVariables"]),
        "qiskitVersion": importlib.metadata.version("qiskit"),
        "isingOffset": offset,
        "mappingAuditMaxError": mapping_error,
        "solve": solve,
        "decoded": decoded,
        "referenceClassicalOptimum": reference_optimum,
        "matchesReferenceOptimum": matches_reference if reference is not None else None,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"QUBO: {qubo['name']} ({qubo['numVariables']} değişken)")
    print(f"QUBO→Ising denetimi: PASS; en büyük hata={mapping_error:.3g}")
    print(f"Yöntem: {solve['method']}; enerji={solve['energy']:.10g}")
    if "feasible" in decoded:
        print(f"Fizibilite={decoded['feasible']}; çizelgeleme amacı={decoded['schedulingObjective']}")
    if reference is not None:
        print(f"Klasik optimum={reference_optimum:g}; eşleşme={matches_reference}")
    print(f"Çıktı: {output.resolve()}")
    return 0 if args.mode == "qaoa" or reference is None or matches_reference else 3


if __name__ == "__main__":
    raise SystemExit(main())
