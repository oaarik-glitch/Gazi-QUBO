# Qiskit yerel çözüm katmanı

Bu klasör, C# tarafından üretilen üç QUBO JSON biçimini doğrudan okur. QUBO
katsayılarını `x_i=(1-Z_i)/2` dönüşümüyle Ising Hamiltonyenine çevirir
ve dönüşümü hesaplama baz durumlarında sayısal olarak denetler.

## Kurulum (PowerShell)

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r .\qiskit_run\requirements.txt
```

Kurulum; ideal çözüm için Qiskit'i, gürültülü benzetim için Qiskit Aer'i, gerçek
cihaz örneklemesi için IBM Runtime istemcisini ve grafikler için Matplotlib'i içerir.

## Exact doğrulama

Önce 14 değişkenli küçük QUBO'yu C# ile üretin. Sonra:

```powershell
python .\qiskit_run\solve_qubo.py .\qubo-results\tiny\time-indexed-qubo.json --mode exact --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\tiny\time-indexed-validation.json --output .\qiskit-results\tiny-exact.json
```

## Noiseless QAOA

```powershell
python .\qiskit_run\solve_qubo.py .\qubo-results\tiny\time-indexed-qubo.json --mode qaoa --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\tiny\time-indexed-validation.json --reps 1 --shots 2048 --maxiter 100 --seed 42 --output .\qiskit-results\tiny-qaoa-p1.json
```

Statevector belleği `2^n` ile büyüdüğü için 33 değişkenli makale QUBO'su bu
yerel QAOA betiğinde varsayılan olarak engellenir. İlk kuantum deneyleri 14
değişkenli küçük örnekle yapılmalıdır. Makale örneği Gurobi-QUBO exact referansı
olarak korunur.

## İstatistiksel deney ızgarası

```powershell
python .\qiskit_run\run_qaoa_grid.py .\qubo-results\all-formulations\time-indexed-qubo.json --instance .\instances\qubo-tiny-three-job.json --validation .\qubo-results\all-formulations\time-indexed-validation.json --reps 1:5 --seeds 1:30 --shots 4096 --maxiter 200 --output-dir .\qiskit-results\qaoa-30seed
```

Varsayılan seed aralığı 1:30'dur. Çıktıda ham koşum tablosu, ayrıntılı JSON ve
ortalama/standart sapma/medyan/IQR/%95 güven aralıklarını içeren özet CSV bulunur.

## Gürültülü ve gerçek cihaz örneklemesi

`sample_qaoa_backend.py`, ideal statevector ile eğitilmiş parametreleri yeniden
eğitmeden aynı devreyi Aer gürültü modeli veya IBM backend üzerinde örnekler.
Bu nedenle raporda protokol “ideal parameter training followed by backend
sampling” olarak açıkça kaydedilir; tam donanım-içi QAOA optimizasyonuyla
karıştırılmamalıdır. IBM anahtarı hiçbir dosyaya yazılmaz.
