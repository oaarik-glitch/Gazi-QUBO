#!/usr/bin/env python3
"""Sample trained QAOA parameters on Aer noise or an IBM Quantum backend.

Classical parameter training remains ideal/statevector. This script isolates the
sampling degradation caused by an explicit noise model or real hardware.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path
from typing import Any

from qiskit.circuit.library import qaoa_ansatz

from solve_qubo import (
    bitstring_to_values,
    decode_schedule,
    evaluate_qubo,
    load_json,
    qubo_to_ising,
    validate_qubo,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Eğitilmiş QAOA devresini gürültülü veya gerçek backend'de örnekle.")
    parser.add_argument("qubo", help="QUBO JSON yolu")
    parser.add_argument("trained_result", help="optimalParameters içeren ideal QAOA sonuç JSON'u")
    parser.add_argument("--instance", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--mode", choices=("noisy", "ibm"), default="noisy")
    parser.add_argument("--run-index", type=int, default=0, help="Grid JSON kullanılıyorsa koşum indeksi")
    parser.add_argument("--backend", help="IBM backend adı; verilmezse en az yoğun uygun backend")
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--optimization-level", type=int, choices=(0, 1, 2, 3), default=3)
    parser.add_argument("--one-qubit-error", type=float, default=0.001)
    parser.add_argument("--two-qubit-error", type=float, default=0.01)
    parser.add_argument("--readout-error", type=float, default=0.02)
    parser.add_argument("--output", default="qiskit-results/backend-sample.json")
    return parser.parse_args()


def extract_solve(payload: dict[str, Any], run_index: int) -> dict[str, Any]:
    if "solve" in payload:
        return payload["solve"]
    runs = payload.get("runs")
    if isinstance(runs, list) and runs:
        if not 0 <= run_index < len(runs):
            raise IndexError(f"--run-index 0..{len(runs)-1} aralığında olmalıdır.")
        return runs[run_index]["solve"]
    raise ValueError("Sonuç JSON'unda solve veya runs[].solve bulunamadı.")


def prepare_measured_circuit(qubo: dict[str, Any], trained: dict[str, Any]):
    operator, _ = qubo_to_ising(qubo)
    reps = int(trained["reps"])
    parameters = [float(value) for value in trained["optimalParameters"]]
    ansatz = qaoa_ansatz(operator, reps=reps)
    if len(parameters) != len(ansatz.parameters):
        raise ValueError("Kaydedilmiş parametre sayısı QAOA devresiyle uyuşmuyor.")
    bound = ansatz.assign_parameters(dict(zip(list(ansatz.parameters), parameters)))
    bound.measure_all()
    return bound, reps


def noisy_counts(circuit, args: argparse.Namespace) -> tuple[dict[str, int], dict[str, Any]]:
    from qiskit import transpile
    from qiskit_aer import AerSimulator
    from qiskit_aer.noise import NoiseModel, ReadoutError, depolarizing_error

    for name, value in (
        ("one-qubit-error", args.one_qubit_error),
        ("two-qubit-error", args.two_qubit_error),
        ("readout-error", args.readout_error),
    ):
        if not 0.0 <= value < 1.0:
            raise ValueError(f"--{name} [0,1) aralığında olmalıdır.")
    noise = NoiseModel()
    if args.one_qubit_error > 0:
        error = depolarizing_error(args.one_qubit_error, 1)
        noise.add_all_qubit_quantum_error(error, ["x", "sx"])
    if args.two_qubit_error > 0:
        noise.add_all_qubit_quantum_error(
            depolarizing_error(args.two_qubit_error, 2), ["cx"]
        )
    if args.readout_error > 0:
        readout = ReadoutError([
            [1.0 - args.readout_error, args.readout_error],
            [args.readout_error, 1.0 - args.readout_error],
        ])
        noise.add_all_qubit_readout_error(readout)
    simulator = AerSimulator(noise_model=noise, seed_simulator=args.seed)
    compiled = transpile(
        circuit,
        simulator,
        optimization_level=args.optimization_level,
        seed_transpiler=args.seed,
    )
    counts = simulator.run(compiled, shots=args.shots, seed_simulator=args.seed).result().get_counts()
    return {str(key): int(value) for key, value in counts.items()}, {
        "backend": "AerSimulator-custom-depolarizing-noise",
        "noise": {
            "oneQubitDepolarizing": args.one_qubit_error,
            "twoQubitDepolarizing": args.two_qubit_error,
            "symmetricReadout": args.readout_error,
        },
        "transpiledDepth": compiled.depth(),
        "transpiledSize": compiled.size(),
        "operationCounts": {str(key): int(value) for key, value in compiled.count_ops().items()},
    }


def ibm_counts(circuit, args: argparse.Namespace) -> tuple[dict[str, int], dict[str, Any]]:
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
    from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler

    service = QiskitRuntimeService()
    backend = service.backend(args.backend) if args.backend else service.least_busy(
        min_num_qubits=circuit.num_qubits,
        operational=True,
        simulator=False,
    )
    manager = generate_preset_pass_manager(
        backend=backend,
        optimization_level=args.optimization_level,
        seed_transpiler=args.seed,
    )
    isa_circuit = manager.run(circuit)
    sampler = Sampler(mode=backend)
    job = sampler.run([isa_circuit], shots=args.shots)
    counts = job.result()[0].data.meas.get_counts()
    return {str(key): int(value) for key, value in counts.items()}, {
        "backend": backend.name,
        "jobId": job.job_id(),
        "transpiledDepth": isa_circuit.depth(),
        "transpiledSize": isa_circuit.size(),
        "operationCounts": {str(key): int(value) for key, value in isa_circuit.count_ops().items()},
    }


def analyze_counts(
    qubo: dict[str, Any],
    counts: dict[str, int],
    instance: dict[str, Any],
    reference: float,
) -> dict[str, Any]:
    n = int(qubo["numVariables"])
    shots = sum(counts.values())
    candidates: list[tuple[float, int, str, list[int], dict[str, Any]]] = []
    feasible_shots = 0
    optimal_shots = 0
    for bitstring, count in counts.items():
        values = bitstring_to_values(bitstring, n)
        energy = evaluate_qubo(qubo, values)
        decoded = decode_schedule(qubo, values, instance, energy)
        candidates.append((energy, count, bitstring, values, decoded))
        if decoded.get("feasible"):
            feasible_shots += count
        if (
            decoded.get("feasible")
            and decoded.get("schedulingObjective") is not None
            and abs(float(decoded["schedulingObjective"]) - reference) <= 1e-8
            and abs(float(decoded["penaltyEnergy"])) <= 1e-8
        ):
            optimal_shots += count
    best = min(candidates, key=lambda item: (item[0], -item[1]))
    return {
        "bestEnergy": best[0],
        "bestCount": best[1],
        "bestBitstring": best[2],
        "bestValues": best[3],
        "bestDecoded": best[4],
        "feasibleSampleRate": feasible_shots / shots,
        "optimalSampleRate": optimal_shots / shots,
        "uniqueBitstrings": len(counts),
        "topCounts": [
            {"bitstring": bitstring, "count": count}
            for bitstring, count in sorted(counts.items(), key=lambda item: item[1], reverse=True)[:20]
        ],
    }


def main() -> int:
    args = parse_args()
    if args.shots <= 0:
        raise ValueError("--shots pozitif olmalıdır.")
    qubo = load_json(args.qubo)
    validate_qubo(qubo)
    instance = load_json(args.instance)
    validation = load_json(args.validation)
    reference = float(validation["classicalOptimum"])
    trained_payload = load_json(args.trained_result)
    trained = extract_solve(trained_payload, args.run_index)
    circuit, reps = prepare_measured_circuit(qubo, trained)
    counts, backend_metadata = (
        noisy_counts(circuit, args) if args.mode == "noisy" else ibm_counts(circuit, args)
    )
    analysis = analyze_counts(qubo, counts, instance, reference)
    report = {
        "schemaVersion": "1.0",
        "protocol": "ideal-parameter-training-followed-by-backend-sampling",
        "mode": args.mode,
        "quboName": qubo["name"],
        "formulation": qubo.get("formulation"),
        "numVariables": int(qubo["numVariables"]),
        "reps": reps,
        "shots": args.shots,
        "seed": args.seed,
        "qiskitVersion": importlib.metadata.version("qiskit"),
        "backendMetadata": backend_metadata,
        "referenceClassicalOptimum": reference,
        "analysis": analysis,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Backend={backend_metadata['backend']}; p={reps}; shots={args.shots}")
    print(
        f"Fizibil örnek oranı={analysis['feasibleSampleRate']:.4%}; "
        f"optimum örnek oranı={analysis['optimalSampleRate']:.4%}"
    )
    if backend_metadata.get("jobId"):
        print(f"IBM job ID={backend_metadata['jobId']}")
    print(f"Çıktı: {output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
