#!/usr/bin/env python3
"""Run a reproducible QAOA reps×seed grid with publication-grade statistics."""

from __future__ import annotations

import argparse
import csv
import importlib.metadata
import json
import math
import statistics
import time
from pathlib import Path
from typing import Any, Callable

from scipy.stats import t as student_t

from solve_qubo import (
    audit_ising_mapping,
    decode_schedule,
    load_json,
    qaoa_solve,
    qubo_to_ising,
    validate_qubo,
)


def integer_list(text: str, name: str, allow_zero: bool = False) -> list[int]:
    """Parse comma values and inclusive ranges such as 1:30."""
    values: set[int] = set()
    try:
        for token in (item.strip() for item in text.split(",") if item.strip()):
            if ":" in token:
                first, last = (int(item) for item in token.split(":", 1))
                step = 1 if last >= first else -1
                values.update(range(first, last + step, step))
            else:
                values.add(int(token))
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"{name} tamsayı listesi veya aralık olmalıdır.") from exc
    lower_bound = 0 if allow_zero else 1
    if not values or any(value < lower_bound for value in values):
        qualifier = "negatif olmayan" if allow_zero else "pozitif"
        raise argparse.ArgumentTypeError(f"{name} {qualifier} tamsayılardan oluşmalıdır.")
    return sorted(values)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="İdeal QAOA p–seed deney ızgarası.")
    parser.add_argument("qubo", help="QUBO JSON yolu")
    parser.add_argument("--instance", required=True, help="Kaynak çizelgeleme instance JSON")
    parser.add_argument("--validation", required=True, help="Klasik optimum içeren validation JSON")
    parser.add_argument("--reps", default="1,2,3,4,5", help="QAOA p değerleri; örn. 1:5")
    parser.add_argument("--seeds", default="1:30", help="Seed listesi/aralığı; varsayılan 30 koşum")
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--maxiter", type=int, default=200)
    parser.add_argument(
        "--scale-maxiter-with-reps",
        action="store_true",
        help="Her p için maxiter=p×--maxiter kullan",
    )
    parser.add_argument("--max-statevector-qubits", type=int, default=20)
    parser.add_argument("--mapping-audit-samples", type=int, default=64)
    parser.add_argument("--output-dir", default="qiskit-results/qaoa-grid-30seed")
    parser.add_argument(
        "--resume",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Var olan aynı çıktı dizinindeki tamamlanmış p-seed çiftlerini atla",
    )
    return parser.parse_args()


def mean_ci(values: list[float]) -> dict[str, float | None]:
    if not values:
        return {key: None for key in ("mean", "std", "median", "q1", "q3", "ci95Low", "ci95High")}
    ordered = sorted(values)
    n = len(values)
    mean = statistics.fmean(values)
    std = statistics.stdev(values) if n > 1 else 0.0
    if n > 1:
        half = float(student_t.ppf(0.975, n - 1)) * std / math.sqrt(n)
    else:
        half = 0.0
    q1, _, q3 = statistics.quantiles(ordered, n=4, method="inclusive") if n > 1 else (ordered[0], ordered[0], ordered[0])
    return {
        "mean": mean,
        "std": std,
        "median": statistics.median(ordered),
        "q1": q1,
        "q3": q3,
        "ci95Low": mean - half,
        "ci95High": mean + half,
    }


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total <= 0:
        return (math.nan, math.nan)
    p = successes / total
    denominator = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / denominator
    half = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / denominator
    return max(0.0, center - half), min(1.0, center + half)


def add_continuous_stats(
    target: dict[str, Any],
    rows: list[dict[str, Any]],
    source: str,
    prefix: str,
) -> None:
    values = [float(row[source]) for row in rows if row.get(source) is not None]
    for suffix, value in mean_ci(values).items():
        target[prefix + suffix[0].upper() + suffix[1:]] = value


def add_rate_stats(
    target: dict[str, Any],
    rows: list[dict[str, Any]],
    predicate: Callable[[dict[str, Any]], bool],
    prefix: str,
) -> None:
    count = sum(predicate(row) for row in rows)
    low, high = wilson_interval(count, len(rows))
    target[prefix + "Count"] = count
    target[prefix + "Rate"] = count / len(rows)
    target[prefix + "Ci95Low"] = low
    target[prefix + "Ci95High"] = high


def summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for reps in sorted({int(row["reps"]) for row in rows}):
        group = [row for row in rows if int(row["reps"]) == reps]
        summary: dict[str, Any] = {"reps": reps, "runCount": len(group)}
        add_rate_stats(summary, group, lambda row: bool(row["optimizerSuccess"]), "optimizerSuccess")
        add_rate_stats(summary, group, lambda row: bool(row["bestFeasible"]), "feasibleBest")
        add_rate_stats(summary, group, lambda row: bool(row["matchesReferenceOptimum"]), "optimalBest")
        add_continuous_stats(summary, group, "bestEnergy", "bestEnergy")
        add_continuous_stats(summary, group, "expectationEnergy", "expectationEnergy")
        add_continuous_stats(summary, group, "feasibleSampleRate", "feasibleSampleRate")
        add_continuous_stats(summary, group, "optimalSampleRate", "optimalSampleRate")
        add_continuous_stats(summary, group, "runtimeSeconds", "runtimeSeconds")
        add_continuous_stats(summary, group, "optimizerEvaluations", "optimizerEvaluations")
        result.append(summary)
    return result


def write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if columns is None:
        columns = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_outputs(
    output_dir: Path,
    qubo: dict[str, Any],
    config: dict[str, Any],
    offset: float,
    mapping_error: float,
    rows: list[dict[str, Any]],
    details: list[dict[str, Any]],
) -> None:
    summary = summarize(rows)
    write_csv(output_dir / "qaoa-runs.csv", rows)
    write_csv(output_dir / "qaoa-summary-statistics.csv", summary)
    report = {
        "schemaVersion": "1.1",
        "quboName": qubo["name"],
        "formulation": qubo.get("formulation"),
        "numVariables": int(qubo["numVariables"]),
        "qiskitVersion": importlib.metadata.version("qiskit"),
        "isingOffset": offset,
        "mappingAuditMaxError": mapping_error,
        "config": config,
        "runs": details,
        "summary": summary,
    }
    (output_dir / "qaoa-experiment.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def main() -> int:
    args = parse_args()
    reps_values = integer_list(args.reps, "reps")
    seed_values = integer_list(args.seeds, "seeds", allow_zero=True)
    if args.shots <= 0 or args.maxiter <= 0:
        raise ValueError("shots ve maxiter pozitif olmalıdır.")

    qubo = load_json(args.qubo)
    validate_qubo(qubo)
    instance = load_json(args.instance)
    validation = load_json(args.validation)
    reference_optimum = float(validation["classicalOptimum"])
    operator, offset = qubo_to_ising(qubo)
    mapping_error = audit_ising_mapping(
        qubo, operator, offset, args.mapping_audit_samples, seed_values[0]
    )
    output_dir = Path(args.output_dir)
    config = {
        "reps": reps_values,
        "seeds": seed_values,
        "shots": args.shots,
        "baseMaxiter": args.maxiter,
        "scaleMaxiterWithReps": args.scale_maxiter_with_reps,
        "maxStatevectorQubits": args.max_statevector_qubits,
        "referenceClassicalOptimum": reference_optimum,
    }
    rows: list[dict[str, Any]] = []
    details: list[dict[str, Any]] = []
    if args.resume and (output_dir / "qaoa-runs.csv").exists() and (output_dir / "qaoa-experiment.json").exists():
        with (output_dir / "qaoa-runs.csv").open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        for row in rows:
            for key in ("optimizerSuccess", "bestFeasible", "matchesReferenceOptimum"):
                row[key] = str(row[key]).strip().lower() == "true"
        previous = load_json(output_dir / "qaoa-experiment.json")
        if previous.get("quboName") != qubo["name"]:
            raise ValueError("--resume çıktı dizini farklı bir QUBO'ya aittir.")
        previous_config = previous.get("config", {})
        for key in ("shots", "baseMaxiter", "scaleMaxiterWithReps"):
            if previous_config.get(key) != config.get(key):
                raise ValueError(
                    f"--resume yapılandırması uyuşmuyor ({key}); yeni bir --output-dir kullanın."
                )
        details = list(previous.get("runs", []))
    completed_keys = {(int(row["reps"]), int(row["seed"])) for row in rows}
    total = len(reps_values) * len(seed_values)
    completed = len(completed_keys.intersection(
        {(reps, seed) for reps in reps_values for seed in seed_values}
    ))
    for reps, seed in ((reps, seed) for reps in reps_values for seed in seed_values):
        if (reps, seed) in completed_keys:
            continue
        maxiter = args.maxiter * reps if args.scale_maxiter_with_reps else args.maxiter
        started = time.perf_counter()
        solve = qaoa_solve(
            qubo, operator, offset, reps, args.shots, maxiter, seed,
            args.max_statevector_qubits, instance, reference_optimum,
        )
        runtime = time.perf_counter() - started
        decoded = decode_schedule(qubo, solve["values"], instance, float(solve["energy"]))
        matches = (
            bool(decoded.get("feasible"))
            and decoded.get("schedulingObjective") is not None
            and abs(float(decoded["schedulingObjective"]) - reference_optimum) <= 1e-8
            and abs(float(decoded["penaltyEnergy"])) <= 1e-8
        )
        row = {
            "reps": reps,
            "seed": seed,
            "maxiter": maxiter,
            "status": solve["status"],
            "optimizerSuccess": solve["optimizerSuccess"],
            "bestEnergy": solve["energy"],
            "expectationEnergy": solve["expectationEnergy"],
            "bestFeasible": bool(decoded.get("feasible")),
            "schedulingObjective": decoded.get("schedulingObjective"),
            "penaltyEnergy": decoded.get("penaltyEnergy"),
            "matchesReferenceOptimum": matches,
            "feasibleSampleRate": solve.get("feasibleSampleRate"),
            "optimalSampleRate": solve.get("optimalSampleRate"),
            "bestSampleCount": solve.get("bestSampleCount"),
            "modalEnergy": solve.get("modalEnergy"),
            "modalCount": solve.get("modalCount"),
            "uniqueBitstrings": solve.get("uniqueBitstrings"),
            "optimizerEvaluations": solve.get("optimizerEvaluations"),
            "runtimeSeconds": runtime,
            "selectedVariables": "|".join(decoded.get("selectedVariables", [])),
        }
        rows.append(row)
        details.append({
            "reps": reps,
            "seed": seed,
            "maxiter": maxiter,
            "runtimeSeconds": runtime,
            "solve": solve,
            "decoded": decoded,
            "matchesReferenceOptimum": matches,
        })
        completed += 1
        completed_keys.add((reps, seed))
        write_outputs(output_dir, qubo, config, offset, mapping_error, rows, details)
        print(
            f"[{completed}/{total}] p={reps}, seed={seed}, enerji={solve['energy']:.10g}, "
            f"fizibilite={decoded.get('feasible')}, optimum={matches}, süre={runtime:.2f}s",
            flush=True,
        )
    print(f"QAOA grid tamamlandı: {output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
