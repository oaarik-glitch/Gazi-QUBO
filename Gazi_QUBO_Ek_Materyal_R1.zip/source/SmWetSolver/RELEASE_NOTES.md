# Sürüm notları

## v5 — Üç QUBO ve hakem revizyonu deney paketi

- Sıra tabanlı QUBO üreticisi ve Rosenberg ürün indirgemesi eklendi.
- Önce-sonra QUBO üreticisi, ikili başlangıç/erkenlik/gecikme ve iki yönlü slack
  eşitlikleriyle eklendi.
- Tamsayı alanları, H iki kuvveti olmadığında aralık dışı değer üretmeyen sınırlı
  ikili ağırlıklarla kodlandı.
- `--formulation all` ile üç QUBO aynı örnekte çözülüp ortak CSV/JSON raporuna alınır.
- Qiskit decoder üç formülasyonu da destekler.
- QAOA grid varsayılanı 30 seed olacak şekilde genişletildi; standart sapma,
  medyan, IQR, Student-t ve Wilson %95 güven aralıkları eklendi.
- 300 dpi PNG/SVG grafik üreticisi eklendi.
- Özel Aer gürültü modeli ve IBM backend için ideal-parametre-sonrası örnekleme
  betiği eklendi.

## v4 — Ceza duyarlılığı ve Qiskit yerel çözümü

- `--penalty-sweep` ile otomatik ceza katsayısı taraması eklendi.
- Deney sonuçları `penalty-sensitivity.csv` ve `penalty-sensitivity.json` olarak raporlanır.
- C# QUBO JSON'unu okuyan bağımsız Python/Qiskit katmanı eklendi.
- `x=(1-Z)/2` QUBO→Ising dönüşümü ve sayısal eşleme denetimi eklendi.
- Küçük QUBO'lar için exact enumerasyon ve noiseless statevector QAOA eklendi.
- Qiskit bit sırası, çizelge decoding, fizibilite ve klasik optimum karşılaştırması eklendi.
- Kullanıcı ortamındaki 33 değişkenli Gurobi-QUBO optimum koşusu doğrulama kaydına işlendi.

## v3 — Time-indexed QUBO

- Üst üçgensel, Qiskit uyumlu QUBO JSON veri modeli eklendi.
- `TimeIndexedQuboBuilder` ve slack biti gerektirmeyen çakışma cezası eklendi.
- Heuristik uygulanabilir üst sınır `U` ve otomatik güvenli `A=U+1` seçimi eklendi.
- Küçük modeller için exhaustive QUBO çözücü eklendi.
- Büyük modeller için binary quadratic `GurobiQuboSolver` eklendi.
- QUBO decoder, bağımsız fizibilite kontrolü ve klasik exact optimum karşılaştırması eklendi.
- 14 değişkenli idle-time örneği exhaustive olarak doğrulandı.

## v2 — Batch klasik model doğrulaması

- `n=4,5,6` için tekrarlanabilir benchmark üreteci eklendi.
- Platformdan bağımsız SplitMix64 seed üretimi eklendi.
- On beş örneği exact DP ve üç Gurobi modeliyle çalıştıran batch CLI eklendi.
- Amaç, durum, süre, MIPGap, düğüm, değişken ve kısıt sayılarını birleştiren `batch-comparison.csv` eklendi.
- On beş örneğin bağımsız exact optimumları doğrulanıp kaydedildi.
- Kullanıcı ortamındaki başarılı üç işli Gurobi koşusu doğrulama kaydına eklendi.

## v1 — Üç klasik formülasyon

- Idle time destekli Position-Based, Time-Indexed ve Precedence-Based Gurobi modelleri.
- Ortak JSON veri yapısı, exact küçük örnek çözücü ve bağımsız çizelge doğrulaması.
- CSV/JSON sonuç dışa aktarımı ve üç işli doğrulama örneği.
