# Model-kod eşlemesi

## Ortak tanımlar

Her iş için işlem süresi `p_i`, teslim tarihi `d_i`, erkenlik ağırlığı `alpha_i` ve geçlik ağırlığı `beta_i` kullanılır.

```text
C_i = S_i + p_i
E_i = max(0, d_i - C_i)
T_i = max(0, C_i - d_i)
min sum_i(alpha_i E_i + beta_i T_i)
```

Varsayılan zaman ufku `H = max_i(d_i) + sum_i(p_i)` olarak alınır. Başlangıç ve tamamlanma zamanları tamsayıdır. Üç model de ilk işten önce ve ardışık işler arasında boş süreye izin verir.

## Position-Based

- `assignment[i,k]` değişkeni `x_ik`'ye karşılık gelir.
- `idleBeforePosition[k]` değişkeni `G_k`'dır; `G_1` ilk işten önceki boşluğu da temsil eder.
- `positionCompletion[k]` değişkeni pozisyon tamamlanma zamanı `C^pos_k`'dır.
- Her iş bir pozisyona, her pozisyon bir işe atanır.
- `completion_chain_k` eşitlikleri `C^pos_k` zincirini işlem süreleri ve boş sürelerle kurar.
- `link_upper` ve `link_lower` kısıtları, `x_ik=1` olduğunda `C_i=C^pos_k` eşitliğini etkinleştirir.

## Time-Indexed

- `starts[(i,t)]` değişkeni, iş `i` zaman `t`'de başlıyorsa 1 olan `x_it` değişkenidir.
- `assign_i` her işin tam bir kez başlamasını sağlar.
- `capacity_tau`, `t <= tau < t+p_i` koşulunu sağlayan tüm başlangıçları toplar ve toplamı 1 ile sınırlar.
- Amaç katsayısı her `(i,t)` için önceden `alpha_i max(0,d_i-t-p_i) + beta_i max(0,t+p_i-d_i)` olarak hesaplanır.

## Precedence-Based

Yalnızca `i<j` için bir `y_ij` değişkeni tutulur:

- `y_ij=1`: iş `i`, iş `j`'den önce;
- `y_ij=0`: iş `j`, iş `i`'den önce.

Kodda kullanılan iki Big-M kısıtı şunlara eşdeğerdir:

```text
S_i + p_i <= S_j + H(1-y_ij)
S_j + p_j <= S_i + H y_ij
```

`0 <= S_i <= H-p_i` olduğundan `M=H`, etkin olmayan dalı gevşetmek için yeterlidir. Başlangıç değişkenleri sıralama kısıtlarından bağımsız seçilebildiği için idle time korunur.

## Bağımsız doğrulama

Gurobi çözümündeki yardımcı `E_i` ve `T_i` değerlerine güvenilmez. Her solver yalnızca iş başlangıç/tamamlanmalarını çıkarır; `CostCalculator` erkenlik, geçlik ve maliyeti baştan hesaplar. `ScheduleValidator` daha sonra:

1. Her işin tam bir kez bulunduğunu,
2. `C_i=S_i+p_i` eşitliğini,
3. İşlerin çakışmadığını,
4. Zaman ufkunun aşılmadığını,
5. Yeniden hesaplanan amaç değerinin Gurobi amacıyla eşleştiğini

kontrol eder. Bu denetim, üç matematiksel modelde ortak bir uygulama hatasının sonuçları yapay olarak eşit göstermesi riskini azaltır.
