# Time-indexed QUBO

## Değişkenler

`x_it=1`, iş `i` zaman `t`'de başlıyorsa 1'dir. Her iş için geçerli başlangıçlar `0 <= t <= H-p_i` aralığındadır.

Başlangıç maliyeti önceden hesaplanır:

```text
c_it = alpha_i max(0, d_i-t-p_i) + beta_i max(0, t+p_i-d_i)
```

## QUBO enerjisi

```text
Q(x) = sum_(i,t) c_it x_it
     + A sum_i (1-sum_t x_it)^2
     + A sum_((i,t),(j,u) in O) x_it x_ju
```

`O`, farklı işlere ait ve işleme aralıkları çakışan başlangıç çiftleri kümesidir:

```text
t < u+p_j  ve  u < t+p_i
```

Kapasite kısıtı için slack biti kullanılmaz. Her çakışan farklı-iş başlangıç çifti doğrudan ikinci derece terimle cezalandırılır.

## Genişletilmiş katsayılar

Atama cezası, `x^2=x` özdeşliğiyle:

```text
A(1-sum_t x_it)^2
= A - A sum_t x_it + 2A sum_(t<u) x_it x_iu
```

Böylece:

- sabit terim: her iş için `+A`;
- doğrusal terim: `c_it-A`;
- aynı işin iki farklı başlangıcı: `+2A`;
- çakışan iki farklı iş başlangıcı: `+A`.

JSON dosyası üst üçgensel konvansiyon kullanır:

```text
Q(x) = constant
     + sum_i linear[i] x_i
     + sum_(i<j) quadratic[i,j] x_i x_j
```

Katsayılar simetrik matris elemanları olarak ikiye bölünmemiştir. Qiskit aktarımında her `quadratic[i,j]` değeri yalnızca bir kez eklenmelidir.

## Güvenli ceza katsayısı

Kod, input/EDD/SPT sıralarını bütün mümkün blok başlangıçlarında deneyerek uygulanabilir bir çizelge üst sınırı `U` üretir. Amaç değerleri tamsayı ve negatif olmadığı için:

```text
A > U
```

yeterlidir. Varsayılan seçim `A=U+1`'dir. Her uygulanamaz çözümün toplam cezası en az `A`, bilinen uygulanabilir çözümün enerjisi ise en fazla `U` olduğundan QUBO global minimumu uygulanabilir olmak zorundadır.

`--penalty` seçeneğiyle daha küçük değerler özellikle duyarlılık deneyi için verilebilir; bu durumda `penaltyGuaranteeSatisfied=false` raporlanabilir.

## Doğrulama katmanları

1. `ExhaustiveQuboSolver`: küçük QUBO'larda bütün bit dizilerini tarar.
2. `GurobiQuboSolver`: daha büyük QUBO'yu doğrudan binary quadratic model olarak exact çözer.
3. `TimeIndexedQuboDecoder`: seçilen `x_it` değişkenlerini çizelgeye dönüştürür.
4. `ScheduleValidator`: atama, çakışmazlık, zaman ufku ve amaç değerini QUBO'dan bağımsız yeniden hesaplar.
5. QUBO sonucu `ExactSmallInstanceSolver` optimumuyla karşılaştırılır.
