# Üç QUBO formülasyonunun kod karşılığı

Bu not, makaledeki Eş. 25–38 ile C# üreticileri arasındaki birebir eşlemeyi ve
sayısal doğrulama protokolünü açıklar.

## Ortak ikili kodlama

Bir tamsayı değişkenin üst sınırı `M`, ikinin kuvveti eksi bir değilse saf
`1,2,4,...` ağırlıkları `M` üzerinde değerler üretebilir. Kod bu nedenle son
ağırlığı kalan aralığa ayarlar. Örneğin `0..5` alanı `1,2,2`, `0..12` alanı
`1,2,4,5` ağırlıklarıyla kodlanır. Bu gösterim bazı değerleri birden çok bit
dizisiyle temsil edebilir, fakat hiçbir bit dizisi izin verilen üst sınırı aşmaz.
QUBO eşdeğerliği için gerekli olan değer kapsama ve aralık güvenliği korunur.

Tüm doğrusal eşitlikler

```text
a0 + sum_r a_r q_r = 0
```

biçimine getirilip `A(a0+sum a_r q_r)^2` olarak açılır. Varsayılan ortak ceza
`A=U+1` olup `U`, hızlı uygulanabilir çizelgelerin en iyi amaç değeridir.

## Sıra tabanlı QUBO

`PositionBasedQuboBuilder` şu değişken ailelerini üretir:

- `assignment`: makaledeki `x_ik`;
- `completion-bit`: `U_k` bitleri;
- `idle-bit`: `G_k` bitleri;
- `earliness-bit`, `tardiness-bit`: `E_i`, `T_i` bitleri;
- `product`: `q_ikb=x_ik u_kb` yardımcıları.

İş ve pozisyon one-hot eşitlikleri, tamamlanma zinciri ve erkenlik/gecikme
eşitliği karesel eşitlik cezalarıdır. Ürün bağı

```text
R(x,u,q) = x*u - 2*x*q - 2*u*q + 3*q
```

ile uygulanır. `R` yalnızca `q=x*u` olduğunda sıfırdır.

## Zaman indisli QUBO

`TimeIndexedQuboBuilder`, her iş için tek başlangıç one-hot cezasını ve çakışan
başlangıç çiftleri için doğrudan `A*x_it*x_js` cezasını kullanır. Ayrı zaman,
erkenlik, gecikme veya slack bitleri yoktur.

## Önce-sonra QUBO

`PrecedenceQuboBuilder`; `start-bit`, `earliness-bit`, `tardiness-bit`,
`precedence` ve iki yönlü `slack-bit` ailelerini üretir. Her `i<j` için:

```text
S_j-S_i-p_i+H(1-y_ij)-R_ij = 0
S_i-S_j-p_j+H*y_ij-V_ij = 0
```

eşitlikleri karesel cezalara çevrilir. `0<=S_i<=H-p_i` ve `M=H` olduğundan
etkin olmayan dal için negatif olmayan bir slack her zaman vardır.

## Aynı örnekte sayısal doğrulama

```powershell
dotnet run --project .\src\SmWetSolver.QuboCli\SmWetSolver.QuboCli.csproj -- .\instances\qubo-tiny-three-job.json --formulation all --solver gurobi --output .\qubo-results\all-formulations --time-limit 300 --threads 1
```

Başarı ölçütü her üç satır için aynıdır:

1. decoded çizelge bağımsız `ScheduleValidator` kontrolünden geçer;
2. QUBO enerjisi ile özgün çizelgeleme amacı arasındaki ceza farkı sıfırdır;
3. özgün amaç exact permutation-DP optimumuna eşittir;
4. Gurobi durumu ve süre bilgisi ortak karşılaştırma dosyasına yazılır.

QAOA statevector maliyeti `2^m` ile büyüdüğünden üç formülasyonun aynı anda
QAOA ile denenmesi kaynak açısından eşdeğer değildir. Makalede üç QUBO'nun
matematiksel/küresel optimum doğrulaması birlikte; ideal, gürültülü ve gerçek
cihaz QAOA deneyi ise en küçük mantıksal qubit sayısını veren zaman indisli
temsil üzerinde ayrı kapsam olarak raporlanmalıdır.
