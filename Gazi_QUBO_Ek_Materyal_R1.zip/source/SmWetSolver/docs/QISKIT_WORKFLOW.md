# Time-indexed QUBO için Qiskit iş akışı

## Dönüşüm

C# çıktısındaki amaç

```text
E(x) = c + sum_i a_i x_i + sum_{i<j} b_ij x_i x_j
```

biçimindedir. `x_i=(1-Z_i)/2` dönüşümü kullanıldığında:

```text
offset = c + sum_i a_i/2 + sum_{i<j} b_ij/4
h_i    = -a_i/2 - sum_{j != i} b_ij/4
J_ij   = b_ij/4
H      = sum_i h_i Z_i + sum_{i<j} J_ij Z_i Z_j
```

ve her hesaplama baz durumu için `E(x)=<x|H|x>+offset` eşitliği elde edilir.
`solve_qubo.py` çözümden önce bu eşitliği rastgele bit dizileri üzerinde denetler.

## Çözüm sırası

1. C# exhaustive veya Gurobi-QUBO sonucu ground truth olarak üretilir.
2. Qiskit exact modu küçük QUBO'yu bütün bit dizileri üzerinde yeniden çözer.
3. QAOA aynı Hamiltonyeni `StatevectorEstimator` ile optimize eder.
4. Optimize devre `StatevectorSampler` ile örneklenir.
5. Gözlenen bit dizileri arasında enerjisi en düşük olan çözüm decode edilir.
6. Çizelge fizibilitesi ve klasik optimum eşleşmesi bağımsız hesaplanır.

QAOA yaklaşık bir yöntem olduğundan tek koşuda klasik optimumu bulması garanti
değildir. Bu nedenle makale deneylerinde her `(reps, seed)` bileşimi birden fazla
kez çalıştırılmalı; en iyi enerji yanında uygulanabilir çözüm oranı ve optimumu
örnekleme oranı da raporlanmalıdır.

## Boyut sınırı

Statevector belleği QUBO değişken sayısında üstel büyür. 14 qubitlik tiny örnek
yerel simülasyon için uygundur. 33 qubitlik makale örneği ise sıradan bir
bilgisayarda statevector QAOA için uygun değildir; bu örneğin Gurobi-QUBO sonucu
exact referans olarak kullanılmalıdır.

Uygulama, IBM'in güncel Qiskit SDK yerel primitive yaklaşımını izler:

- https://quantum.cloud.ibm.com/docs/guides/simulate-with-qiskit-sdk-primitives
- https://quantum.cloud.ibm.com/docs/en/tutorials/warm-start-qaoa
