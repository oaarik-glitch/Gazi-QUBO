using System.Globalization;
using System.Text;
using System.Text.Json;
using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.IO;

public static class BenchmarkInstanceWriter
{
    public static void Write(
        string outputDirectory,
        BenchmarkGenerationOptions options,
        IReadOnlyList<GeneratedBenchmark> benchmarks)
    {
        Directory.CreateDirectory(outputDirectory);
        File.WriteAllText(
            Path.Combine(outputDirectory, "benchmark-plan.json"),
            JsonSerializer.Serialize(options, JsonDefaults.Options));

        var manifest = new StringBuilder();
        manifest.AppendLine("instance,file,job_count,replicate,seed,tardiness_factor,due_date_range,horizon,total_processing_time");
        foreach (var benchmark in benchmarks)
        {
            var fileName = benchmark.Instance.Name + ".instance.json";
            File.WriteAllText(
                Path.Combine(outputDirectory, fileName),
                JsonSerializer.Serialize(benchmark.Instance, JsonDefaults.Options));
            manifest.AppendJoin(',',
                benchmark.Instance.Name,
                fileName,
                benchmark.Instance.Jobs.Count.ToString(CultureInfo.InvariantCulture),
                benchmark.Replicate.ToString(CultureInfo.InvariantCulture),
                benchmark.Seed.ToString(CultureInfo.InvariantCulture),
                benchmark.TardinessFactor.ToString("G17", CultureInfo.InvariantCulture),
                benchmark.DueDateRange.ToString("G17", CultureInfo.InvariantCulture),
                benchmark.Instance.EffectiveHorizon.ToString(CultureInfo.InvariantCulture),
                benchmark.Instance.Jobs.Sum(job => job.ProcessingTime).ToString(CultureInfo.InvariantCulture));
            manifest.AppendLine();
        }
        File.WriteAllText(Path.Combine(outputDirectory, "manifest.csv"), manifest.ToString(), new UTF8Encoding(true));
    }
}
