using System.Globalization;
using System.Text;
using System.Text.Json;
using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.IO;

public static class ResultExporter
{
    public static void WriteAll(string outputDirectory, IReadOnlyList<SolveResult> results)
    {
        Directory.CreateDirectory(outputDirectory);
        File.WriteAllText(
            Path.Combine(outputDirectory, "results.json"),
            JsonSerializer.Serialize(results, JsonDefaults.Options));
        WriteSummaryCsv(Path.Combine(outputDirectory, "results-summary.csv"), results);
        WriteScheduleCsv(Path.Combine(outputDirectory, "schedules.csv"), results);
    }

    private static void WriteSummaryCsv(string path, IEnumerable<SolveResult> results)
    {
        var builder = new StringBuilder();
        builder.AppendLine("instance,model,status,objective,runtime_seconds,mip_gap,node_count,variables,constraints,validation_passed");
        foreach (var result in results)
        {
            builder.AppendJoin(',',
                Csv(result.InstanceName),
                Csv(result.ModelName),
                Csv(result.Status),
                Number(result.ObjectiveValue),
                Number(result.RuntimeSeconds),
                NullableNumber(result.MipGap),
                NullableNumber(result.NodeCount),
                result.VariableCount?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                result.ConstraintCount?.ToString(CultureInfo.InvariantCulture) ?? string.Empty,
                result.IndependentValidationPassed ? "true" : "false");
            builder.AppendLine();
        }
        File.WriteAllText(path, builder.ToString(), new UTF8Encoding(true));
    }

    private static void WriteScheduleCsv(string path, IEnumerable<SolveResult> results)
    {
        var builder = new StringBuilder();
        builder.AppendLine("instance,model,job_id,start,completion,earliness,tardiness,cost");
        foreach (var result in results)
        {
            foreach (var item in result.Schedule.OrderBy(item => item.Start).ThenBy(item => item.JobId))
            {
                builder.AppendJoin(',',
                    Csv(result.InstanceName),
                    Csv(result.ModelName),
                    item.JobId.ToString(CultureInfo.InvariantCulture),
                    item.Start.ToString(CultureInfo.InvariantCulture),
                    item.Completion.ToString(CultureInfo.InvariantCulture),
                    item.Earliness.ToString(CultureInfo.InvariantCulture),
                    item.Tardiness.ToString(CultureInfo.InvariantCulture),
                    Number(item.Cost));
                builder.AppendLine();
            }
        }
        File.WriteAllText(path, builder.ToString(), new UTF8Encoding(true));
    }

    private static string Number(double value) => value.ToString("G17", CultureInfo.InvariantCulture);
    private static string NullableNumber(double? value) => value.HasValue ? Number(value.Value) : string.Empty;

    private static string Csv(string value)
    {
        if (!value.Contains(',') && !value.Contains('"') && !value.Contains('\n') && !value.Contains('\r'))
            return value;
        return "\"" + value.Replace("\"", "\"\"") + "\"";
    }
}
