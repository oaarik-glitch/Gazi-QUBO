using System.Globalization;
using System.Text;
using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.IO;

public static class BatchSummaryExporter
{
    public static void Write(
        string path,
        IReadOnlyDictionary<string, SchedulingInstance> instances,
        IReadOnlyList<SolveResult> results,
        double tolerance = 1e-6)
    {
        var builder = new StringBuilder();
        builder.AppendLine(
            "instance,job_count,horizon,exact_objective,objectives_equal,all_validation_passed,all_gurobi_optimal," +
            "position_objective,time_indexed_objective,precedence_objective," +
            "position_status,time_indexed_status,precedence_status," +
            "position_runtime,time_indexed_runtime,precedence_runtime," +
            "position_mip_gap,time_indexed_mip_gap,precedence_mip_gap," +
            "position_nodes,time_indexed_nodes,precedence_nodes," +
            "position_variables,time_indexed_variables,precedence_variables," +
            "position_constraints,time_indexed_constraints,precedence_constraints");

        foreach (var instanceName in instances.Keys.OrderBy(name => name, StringComparer.Ordinal))
        {
            var instance = instances[instanceName];
            var group = results.Where(result => result.InstanceName == instanceName)
                .ToDictionary(result => result.ModelName, StringComparer.Ordinal);
            var exact = Require(group, "Exact-Permutation-DP");
            var position = Require(group, "Position-Based");
            var timeIndexed = Require(group, "Time-Indexed");
            var precedence = Require(group, "Precedence-Based");
            var objectivesEqual = group.Values.All(
                result => Math.Abs(result.ObjectiveValue - exact.ObjectiveValue) <= tolerance);
            var allValid = group.Values.All(result => result.IndependentValidationPassed);
            var allGurobiOptimal = new[] { position, timeIndexed, precedence }
                .All(result => result.Status == "OPTIMAL");

            builder.AppendJoin(',',
                instanceName,
                instance.Jobs.Count.ToString(CultureInfo.InvariantCulture),
                instance.EffectiveHorizon.ToString(CultureInfo.InvariantCulture),
                Number(exact.ObjectiveValue),
                Bool(objectivesEqual),
                Bool(allValid),
                Bool(allGurobiOptimal),
                Number(position.ObjectiveValue),
                Number(timeIndexed.ObjectiveValue),
                Number(precedence.ObjectiveValue),
                position.Status,
                timeIndexed.Status,
                precedence.Status,
                Number(position.RuntimeSeconds),
                Number(timeIndexed.RuntimeSeconds),
                Number(precedence.RuntimeSeconds),
                NullableNumber(position.MipGap),
                NullableNumber(timeIndexed.MipGap),
                NullableNumber(precedence.MipGap),
                NullableNumber(position.NodeCount),
                NullableNumber(timeIndexed.NodeCount),
                NullableNumber(precedence.NodeCount),
                Integer(position.VariableCount),
                Integer(timeIndexed.VariableCount),
                Integer(precedence.VariableCount),
                Integer(position.ConstraintCount),
                Integer(timeIndexed.ConstraintCount),
                Integer(precedence.ConstraintCount));
            builder.AppendLine();
        }

        File.WriteAllText(path, builder.ToString(), new UTF8Encoding(true));
    }

    private static SolveResult Require(IReadOnlyDictionary<string, SolveResult> group, string modelName) =>
        group.TryGetValue(modelName, out var result)
            ? result
            : throw new InvalidDataException($"Eksik batch sonucu: {modelName}.");

    private static string Number(double value) => value.ToString("G17", CultureInfo.InvariantCulture);
    private static string NullableNumber(double? value) =>
        value.HasValue ? Number(value.Value) : string.Empty;
    private static string Integer(int? value) => value?.ToString(CultureInfo.InvariantCulture) ?? string.Empty;
    private static string Bool(bool value) => value ? "true" : "false";
}
