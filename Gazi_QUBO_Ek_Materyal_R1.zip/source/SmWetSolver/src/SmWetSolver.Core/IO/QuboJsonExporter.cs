using System.Globalization;
using System.Text.Json;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Qubo;

namespace SmWetSolver.Core.IO;

public static class QuboJsonExporter
{
    public static void WriteModel(string path, QuboModel model)
    {
        EnsureParentDirectory(path);
        File.WriteAllText(path, JsonSerializer.Serialize(model, JsonDefaults.Options));
    }

    public static void WriteValidation(string path, QuboValidationReport report)
    {
        EnsureParentDirectory(path);
        File.WriteAllText(path, JsonSerializer.Serialize(report, JsonDefaults.Options));
    }

    public static void WritePenaltySweepJson(string path, IReadOnlyList<QuboPenaltySweepRow> rows)
    {
        EnsureParentDirectory(path);
        File.WriteAllText(path, JsonSerializer.Serialize(rows, JsonDefaults.Options));
    }

    public static void WritePenaltySweepCsv(string path, IReadOnlyList<QuboPenaltySweepRow> rows)
    {
        EnsureParentDirectory(path);
        var lines = new List<string>
        {
            "instance,penalty,upper_bound,guarantee,variables,linear_terms,quadratic_terms,solver,status,energy,scheduling_objective,penalty_energy,feasible,matches_classical,runtime_seconds,mip_gap,node_count,selected_variables"
        };
        lines.AddRange(rows.Select(row => string.Join(",",
            Csv(row.InstanceName),
            Number(row.Penalty),
            Number(row.FeasibleUpperBound),
            row.PenaltyGuaranteeSatisfied.ToString().ToLowerInvariant(),
            row.NumVariables.ToString(CultureInfo.InvariantCulture),
            row.LinearTermCount.ToString(CultureInfo.InvariantCulture),
            row.QuadraticTermCount.ToString(CultureInfo.InvariantCulture),
            Csv(row.Solver),
            Csv(row.Status),
            Number(row.Energy),
            NullableNumber(row.SchedulingObjective),
            NullableNumber(row.PenaltyEnergy),
            row.Feasible.ToString().ToLowerInvariant(),
            row.MatchesClassicalOptimum.ToString().ToLowerInvariant(),
            Number(row.RuntimeSeconds),
            NullableNumber(row.MipGap),
            NullableNumber(row.NodeCount),
            Csv(string.Join("|", row.SelectedVariables)))));
        File.WriteAllLines(path, lines);
    }

    public static void WriteFormulationComparisonJson(
        string path,
        IReadOnlyList<QuboFormulationComparisonRow> rows)
    {
        EnsureParentDirectory(path);
        File.WriteAllText(path, JsonSerializer.Serialize(rows, JsonDefaults.Options));
    }

    public static void WriteFormulationComparisonCsv(
        string path,
        IReadOnlyList<QuboFormulationComparisonRow> rows)
    {
        EnsureParentDirectory(path);
        var lines = new List<string>
        {
            "instance,formulation,variables,linear_terms,quadratic_terms,coupling_density,max_abs_coefficient,penalty,upper_bound,solver,status,energy,scheduling_objective,penalty_energy,feasible,matches_classical,runtime_seconds,mip_gap,node_count,variable_families"
        };
        lines.AddRange(rows.Select(row => string.Join(",",
            Csv(row.InstanceName),
            Csv(row.Formulation),
            row.NumVariables.ToString(CultureInfo.InvariantCulture),
            row.LinearTermCount.ToString(CultureInfo.InvariantCulture),
            row.QuadraticTermCount.ToString(CultureInfo.InvariantCulture),
            Number(row.CouplingDensity),
            Number(row.MaximumAbsoluteCoefficient),
            Number(row.Penalty),
            Number(row.FeasibleUpperBound),
            Csv(row.Solver),
            Csv(row.Status),
            Number(row.Energy),
            NullableNumber(row.SchedulingObjective),
            NullableNumber(row.PenaltyEnergy),
            row.Feasible.ToString().ToLowerInvariant(),
            row.MatchesClassicalOptimum.ToString().ToLowerInvariant(),
            Number(row.RuntimeSeconds),
            NullableNumber(row.MipGap),
            NullableNumber(row.NodeCount),
            Csv(string.Join("|", row.VariableFamilyCounts.OrderBy(item => item.Key)
                .Select(item => $"{item.Key}:{item.Value}"))))));
        File.WriteAllLines(path, lines);
    }

    private static string Number(double value) => value.ToString("G17", CultureInfo.InvariantCulture);

    private static string NullableNumber(double? value) => value.HasValue ? Number(value.Value) : string.Empty;

    private static string Csv(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";

    private static void EnsureParentDirectory(string path)
    {
        var directory = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(directory))
            Directory.CreateDirectory(directory);
    }
}
