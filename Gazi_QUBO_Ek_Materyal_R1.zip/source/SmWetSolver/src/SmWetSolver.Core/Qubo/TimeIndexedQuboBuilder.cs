using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Core.Qubo;

public sealed class TimeIndexedQuboBuilder
{
    public QuboModel Build(SchedulingInstance instance, double? penaltyOverride = null)
    {
        instance.Validate();
        var horizon = instance.EffectiveHorizon;
        var feasibleUpperBound = QuboBuilderSupport.CalculateFeasibleUpperBound(instance);
        var minimumSafePenalty = feasibleUpperBound + 1.0;
        var penalty = QuboBuilderSupport.ValidateAndChoosePenalty(feasibleUpperBound, penaltyOverride);

        var variables = new List<QuboVariable>();
        var variableIndex = new Dictionary<(int JobIndex, int Start), int>();
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            for (var start = 0; start <= horizon - job.ProcessingTime; start++)
            {
                var index = variables.Count;
                variableIndex[(i, start)] = index;
                variables.Add(new QuboVariable
                {
                    Index = index,
                    Name = $"x_{job.Id}_{start}",
                    Kind = "start",
                    JobId = job.Id,
                    StartTime = start
                });
            }
        }

        var qubo = new QuboAccumulator();
        var assignmentPairCount = 0;
        qubo.AddConstant(penalty * instance.Jobs.Count);
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            var indices = Enumerable.Range(0, horizon - job.ProcessingTime + 1)
                .Select(start => variableIndex[(i, start)])
                .ToArray();
            foreach (var index in indices)
                qubo.AddLinear(index, -penalty);
            for (var first = 0; first < indices.Length; first++)
            {
                for (var second = first + 1; second < indices.Length; second++)
                {
                    qubo.AddQuadratic(indices[first], indices[second], 2.0 * penalty);
                    assignmentPairCount++;
                }
            }
        }

        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            for (var start = 0; start <= horizon - job.ProcessingTime; start++)
            {
                var index = variableIndex[(i, start)];
                var cost = CostCalculator.AtCompletion(job, start + job.ProcessingTime);
                qubo.AddLinear(index, cost);
            }
        }

        var overlapPairCount = 0;
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var firstJob = instance.Jobs[i];
            for (var j = i + 1; j < instance.Jobs.Count; j++)
            {
                var secondJob = instance.Jobs[j];
                for (var firstStart = 0; firstStart <= horizon - firstJob.ProcessingTime; firstStart++)
                {
                    for (var secondStart = 0; secondStart <= horizon - secondJob.ProcessingTime; secondStart++)
                    {
                        if (!IntervalsOverlap(
                                firstStart,
                                firstJob.ProcessingTime,
                                secondStart,
                                secondJob.ProcessingTime))
                            continue;
                        qubo.AddQuadratic(
                            variableIndex[(i, firstStart)],
                            variableIndex[(j, secondStart)],
                            penalty);
                        overlapPairCount++;
                    }
                }
            }
        }

        var linear = qubo.LinearTerms();
        var quadratic = qubo.QuadraticTerms();
        return new QuboModel
        {
            SchemaVersion = "1.1",
            Name = $"{instance.Name}_time_indexed_qubo",
            Formulation = "time-indexed",
            NumVariables = variables.Count,
            Constant = qubo.Constant,
            Variables = variables,
            Linear = linear,
            Quadratic = quadratic,
            Metadata = new QuboMetadata
            {
                SourceInstance = instance.Name,
                JobCount = instance.Jobs.Count,
                Horizon = horizon,
                FeasibleUpperBound = feasibleUpperBound,
                MinimumSafePenalty = minimumSafePenalty,
                Penalty = penalty,
                PenaltyGuaranteeSatisfied = penalty > feasibleUpperBound,
                ObjectiveConvention = "constant + sum_i linear[i]*x_i + sum_{i<j} quadratic[i,j]*x_i*x_j",
                IntegerEncoding = "direct time-indexed binary variables",
                VariableFamilyCounts = new Dictionary<string, int>
                {
                    ["start"] = variables.Count
                },
                ConstraintGroupCounts = new Dictionary<string, int>
                {
                    ["assignmentPairs"] = assignmentPairCount,
                    ["overlapPairs"] = overlapPairCount
                }
            }
        };
    }

    private static bool IntervalsOverlap(int firstStart, int firstDuration, int secondStart, int secondDuration) =>
        firstStart < secondStart + secondDuration && secondStart < firstStart + firstDuration;
}
