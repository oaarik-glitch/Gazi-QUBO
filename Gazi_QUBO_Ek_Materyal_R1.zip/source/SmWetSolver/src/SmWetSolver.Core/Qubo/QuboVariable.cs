namespace SmWetSolver.Core.Qubo;

public sealed record QuboVariable
{
    public required int Index { get; init; }
    public required string Name { get; init; }
    public required string Kind { get; init; }
    public int? JobId { get; init; }
    public int? OtherJobId { get; init; }
    public int? StartTime { get; init; }
    public int? Position { get; init; }
    public int? Bit { get; init; }
    public int? Weight { get; init; }
    public string? Direction { get; init; }
}
