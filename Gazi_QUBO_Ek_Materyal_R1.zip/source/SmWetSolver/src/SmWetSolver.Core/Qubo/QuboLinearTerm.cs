namespace SmWetSolver.Core.Qubo;

public sealed record QuboLinearTerm
{
    public required int Index { get; init; }
    public required double Value { get; init; }
}
