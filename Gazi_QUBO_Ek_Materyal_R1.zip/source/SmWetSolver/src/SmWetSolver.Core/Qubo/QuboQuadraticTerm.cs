namespace SmWetSolver.Core.Qubo;

public sealed record QuboQuadraticTerm
{
    public required int I { get; init; }
    public required int J { get; init; }
    public required double Value { get; init; }
}
