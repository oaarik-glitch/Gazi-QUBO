using System.Diagnostics;

namespace SmWetSolver.Core.Qubo;

public sealed class ExhaustiveQuboSolver
{
    public QuboSolveResult Solve(QuboModel model, int maximumVariables = 26)
    {
        if (maximumVariables is < 1 or > 30)
            throw new ArgumentOutOfRangeException(
                nameof(maximumVariables),
                "Exhaustive güvenlik sınırı 1 ile 30 arasında olmalıdır.");
        if (model.NumVariables > maximumVariables)
            throw new ArgumentOutOfRangeException(
                nameof(model),
                $"Exhaustive QUBO sınırı {maximumVariables}, model boyutu {model.NumVariables}.");
        if (model.NumVariables >= 63)
            throw new ArgumentOutOfRangeException(nameof(model), "Bit maskesi en fazla 62 değişken içindir.");

        var stopwatch = Stopwatch.StartNew();
        var stateCount = 1UL << model.NumVariables;
        var bestEnergy = double.PositiveInfinity;
        var bestMask = 0UL;
        for (var mask = 0UL; mask < stateCount; mask++)
        {
            var energy = model.EvaluateMask(mask);
            if (energy + 1e-9 < bestEnergy)
            {
                bestEnergy = energy;
                bestMask = mask;
            }
        }
        stopwatch.Stop();

        var values = Enumerable.Range(0, model.NumVariables)
            .Select(index => ((bestMask >> index) & 1UL) == 0 ? 0 : 1)
            .ToArray();
        return new QuboSolveResult
        {
            Solver = "Exhaustive-QUBO",
            Status = "OPTIMAL",
            Energy = bestEnergy,
            RuntimeSeconds = stopwatch.Elapsed.TotalSeconds,
            MipGap = 0.0,
            EvaluatedStates = stateCount,
            Values = values
        };
    }
}
