namespace SmWetSolver.Core.Qubo;

public sealed record QuboMetadata
{
    public required string SourceInstance { get; init; }
    public required int JobCount { get; init; }
    public required int Horizon { get; init; }
    public required double FeasibleUpperBound { get; init; }
    public required double MinimumSafePenalty { get; init; }
    public required double Penalty { get; init; }
    public required bool PenaltyGuaranteeSatisfied { get; init; }
    public required string ObjectiveConvention { get; init; }
    public required string IntegerEncoding { get; init; }
    public IReadOnlyDictionary<string, int> VariableFamilyCounts { get; init; } =
        new Dictionary<string, int>();
    public IReadOnlyDictionary<string, int> ConstraintGroupCounts { get; init; } =
        new Dictionary<string, int>();
}
