namespace SmWetSolver.Core.Qubo;

public sealed record QuboPenaltySweepRow
{
    public required string InstanceName { get; init; }
    public required double Penalty { get; init; }
    public required double FeasibleUpperBound { get; init; }
    public required bool PenaltyGuaranteeSatisfied { get; init; }
    public required int NumVariables { get; init; }
    public required int LinearTermCount { get; init; }
    public required int QuadraticTermCount { get; init; }
    public required string Solver { get; init; }
    public required string Status { get; init; }
    public required double Energy { get; init; }
    public double? SchedulingObjective { get; init; }
    public double? PenaltyEnergy { get; init; }
    public required bool Feasible { get; init; }
    public required bool MatchesClassicalOptimum { get; init; }
    public required double RuntimeSeconds { get; init; }
    public double? MipGap { get; init; }
    public double? NodeCount { get; init; }
    public required IReadOnlyList<string> SelectedVariables { get; init; }
}
