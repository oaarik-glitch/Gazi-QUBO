using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Qubo;

public sealed class PositionBasedQuboBuilder
{
    public QuboModel Build(SchedulingInstance instance, double? penaltyOverride = null)
    {
        instance.Validate();
        var n = instance.Jobs.Count;
        var horizon = instance.EffectiveHorizon;
        var upperBound = QuboBuilderSupport.CalculateFeasibleUpperBound(instance);
        var penalty = QuboBuilderSupport.ValidateAndChoosePenalty(upperBound, penaltyOverride);
        var variables = new List<QuboVariable>();

        int AddVariable(
            string name,
            string kind,
            int? jobId = null,
            int? position = null,
            int? bit = null,
            int? weight = null)
        {
            var index = variables.Count;
            variables.Add(new QuboVariable
            {
                Index = index,
                Name = name,
                Kind = kind,
                JobId = jobId,
                Position = position,
                Bit = bit,
                Weight = weight
            });
            return index;
        }

        IReadOnlyList<WeightedQuboBit> AddEncoded(
            string prefix,
            string kind,
            int maximum,
            int? jobId = null,
            int? position = null)
        {
            var weights = QuboBuilderSupport.BoundedBinaryWeights(maximum);
            return weights.Select((weight, bit) => new WeightedQuboBit(
                AddVariable($"{prefix}_{bit}", kind, jobId, position, bit, weight),
                weight)).ToArray();
        }

        var assignment = new int[n, n];
        for (var i = 0; i < n; i++)
        {
            for (var k = 0; k < n; k++)
            {
                assignment[i, k] = AddVariable(
                    $"x_{instance.Jobs[i].Id}_{k + 1}",
                    "assignment",
                    instance.Jobs[i].Id,
                    k + 1);
            }
        }

        var completion = new IReadOnlyList<WeightedQuboBit>[n];
        var idle = new IReadOnlyList<WeightedQuboBit>[n];
        for (var k = 0; k < n; k++)
        {
            completion[k] = AddEncoded($"u_{k + 1}", "completion-bit", horizon, position: k + 1);
            idle[k] = AddEncoded($"g_{k + 1}", "idle-bit", horizon, position: k + 1);
        }

        var earliness = new IReadOnlyList<WeightedQuboBit>[n];
        var tardiness = new IReadOnlyList<WeightedQuboBit>[n];
        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            earliness[i] = AddEncoded($"e_{job.Id}", "earliness-bit", job.DueDate, job.Id);
            tardiness[i] = AddEncoded(
                $"t_{job.Id}",
                "tardiness-bit",
                Math.Max(0, horizon - job.DueDate),
                job.Id);
        }

        var product = new int[n, n][];
        for (var i = 0; i < n; i++)
        {
            for (var k = 0; k < n; k++)
            {
                product[i, k] = completion[k]
                    .Select((bit, b) => AddVariable(
                        $"q_{instance.Jobs[i].Id}_{k + 1}_{b}",
                        "product",
                        instance.Jobs[i].Id,
                        k + 1,
                        b,
                        bit.Weight))
                    .ToArray();
            }
        }

        var qubo = new QuboAccumulator();

        // Each job occupies one position and each position contains one job.
        for (var i = 0; i < n; i++)
        {
            var terms = Enumerable.Range(0, n).Select(k => (assignment[i, k], 1.0));
            qubo.AddSquaredLinear(-1.0, terms, penalty);
        }
        for (var k = 0; k < n; k++)
        {
            var terms = Enumerable.Range(0, n).Select(i => (assignment[i, k], 1.0));
            qubo.AddSquaredLinear(-1.0, terms, penalty);
        }

        // U_k-U_{k-1}-G_k-sum_i p_i x_ik=0, with U_0=0.
        for (var k = 0; k < n; k++)
        {
            var terms = new List<(int Index, double Coefficient)>();
            QuboBuilderSupport.AddTerms(terms, completion[k]);
            if (k > 0)
                QuboBuilderSupport.AddTerms(terms, completion[k - 1], -1.0);
            QuboBuilderSupport.AddTerms(terms, idle[k], -1.0);
            for (var i = 0; i < n; i++)
                terms.Add((assignment[i, k], -instance.Jobs[i].ProcessingTime));
            qubo.AddSquaredLinear(0.0, terms, penalty);
        }

        // q_ikb=x_ik*u_kb through Rosenberg's quadratic reduction.
        var productConstraintCount = 0;
        for (var i = 0; i < n; i++)
        {
            for (var k = 0; k < n; k++)
            {
                for (var b = 0; b < completion[k].Count; b++)
                {
                    qubo.AddRosenbergProduct(
                        assignment[i, k],
                        completion[k][b].Index,
                        product[i, k][b],
                        penalty);
                    productConstraintCount++;
                }
            }
        }

        // d_i-C_i-E_i+T_i=0 and the original nonnegative objective.
        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            var terms = new List<(int Index, double Coefficient)>();
            for (var k = 0; k < n; k++)
            {
                for (var b = 0; b < completion[k].Count; b++)
                    terms.Add((product[i, k][b], -completion[k][b].Weight));
            }
            QuboBuilderSupport.AddTerms(terms, earliness[i], -1.0);
            QuboBuilderSupport.AddTerms(terms, tardiness[i]);
            qubo.AddSquaredLinear(job.DueDate, terms, penalty);
            foreach (var bit in earliness[i])
                qubo.AddLinear(bit.Index, job.EarlinessWeight * bit.Weight);
            foreach (var bit in tardiness[i])
                qubo.AddLinear(bit.Index, job.TardinessWeight * bit.Weight);
        }

        var familyCounts = variables
            .GroupBy(variable => variable.Kind)
            .ToDictionary(group => group.Key, group => group.Count());
        return new QuboModel
        {
            SchemaVersion = "1.1",
            Name = $"{instance.Name}_position_qubo",
            Formulation = "position",
            NumVariables = variables.Count,
            Constant = qubo.Constant,
            Variables = variables,
            Linear = qubo.LinearTerms(),
            Quadratic = qubo.QuadraticTerms(),
            Metadata = new QuboMetadata
            {
                SourceInstance = instance.Name,
                JobCount = n,
                Horizon = horizon,
                FeasibleUpperBound = upperBound,
                MinimumSafePenalty = upperBound + 1.0,
                Penalty = penalty,
                PenaltyGuaranteeSatisfied = penalty > upperBound,
                ObjectiveConvention = "constant + sum_i linear[i]*x_i + sum_{i<j} quadratic[i,j]*x_i*x_j",
                IntegerEncoding = "bounded binary weights with exact range 0..maximum",
                VariableFamilyCounts = familyCounts,
                ConstraintGroupCounts = new Dictionary<string, int>
                {
                    ["jobAssignments"] = n,
                    ["positionAssignments"] = n,
                    ["completionRecurrences"] = n,
                    ["productReductions"] = productConstraintCount,
                    ["earlinessTardinessDefinitions"] = n
                }
            }
        };
    }
}
