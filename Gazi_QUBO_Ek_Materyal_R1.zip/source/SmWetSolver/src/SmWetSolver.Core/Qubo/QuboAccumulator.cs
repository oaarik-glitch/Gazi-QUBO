namespace SmWetSolver.Core.Qubo;

internal sealed class QuboAccumulator
{
    private readonly SortedDictionary<int, double> _linear = [];
    private readonly SortedDictionary<(int I, int J), double> _quadratic = [];

    public double Constant { get; private set; }

    public void AddConstant(double value) => Constant += value;

    public void AddLinear(int index, double value)
    {
        _linear[index] = _linear.GetValueOrDefault(index) + value;
    }

    public void AddQuadratic(int i, int j, double value)
    {
        if (i == j)
        {
            AddLinear(i, value);
            return;
        }
        if (i > j)
            (i, j) = (j, i);
        _quadratic[(i, j)] = _quadratic.GetValueOrDefault((i, j)) + value;
    }

    public void AddSquaredLinear(
        double constant,
        IEnumerable<(int Index, double Coefficient)> terms,
        double penalty)
    {
        if (penalty <= 0.0)
            throw new ArgumentOutOfRangeException(nameof(penalty));

        var combined = terms
            .GroupBy(term => term.Index)
            .Select(group => (Index: group.Key, Coefficient: group.Sum(term => term.Coefficient)))
            .Where(term => Math.Abs(term.Coefficient) > 1e-12)
            .OrderBy(term => term.Index)
            .ToArray();

        AddConstant(penalty * constant * constant);
        foreach (var term in combined)
            AddLinear(
                term.Index,
                penalty * (term.Coefficient * term.Coefficient + 2.0 * constant * term.Coefficient));
        for (var first = 0; first < combined.Length; first++)
        {
            for (var second = first + 1; second < combined.Length; second++)
            {
                AddQuadratic(
                    combined[first].Index,
                    combined[second].Index,
                    2.0 * penalty * combined[first].Coefficient * combined[second].Coefficient);
            }
        }
    }

    public void AddRosenbergProduct(int first, int second, int product, double penalty)
    {
        // R(a,b,q)=ab-2aq-2bq+3q is zero exactly when q=ab.
        AddQuadratic(first, second, penalty);
        AddQuadratic(first, product, -2.0 * penalty);
        AddQuadratic(second, product, -2.0 * penalty);
        AddLinear(product, 3.0 * penalty);
    }

    public IReadOnlyList<QuboLinearTerm> LinearTerms() => _linear
        .Where(item => Math.Abs(item.Value) > 1e-12)
        .Select(item => new QuboLinearTerm { Index = item.Key, Value = item.Value })
        .ToArray();

    public IReadOnlyList<QuboQuadraticTerm> QuadraticTerms() => _quadratic
        .Where(item => Math.Abs(item.Value) > 1e-12)
        .Select(item => new QuboQuadraticTerm
        {
            I = item.Key.I,
            J = item.Key.J,
            Value = item.Value
        })
        .ToArray();
}
