using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Qubo;

public static class PositionBasedQuboWarmStart
{
    public static IReadOnlyList<int> Encode(
        SchedulingInstance instance,
        QuboModel model,
        IReadOnlyList<JobSchedule> classicalSchedule,
        double tolerance = 1e-6)
    {
        if (model.Formulation != "position")
            throw new ArgumentException("Warm start yalnızca pozisyon tabanlı QUBO için kullanılabilir.", nameof(model));
        if (classicalSchedule.Count != instance.Jobs.Count)
            throw new ArgumentException("Klasik çizelge tüm işleri içermelidir.", nameof(classicalSchedule));

        var values = new int[model.NumVariables];
        var ordered = classicalSchedule
            .OrderBy(item => item.Start)
            .ThenBy(item => item.Completion)
            .ThenBy(item => item.JobId)
            .ToArray();
        var previousCompletion = 0;
        for (var index = 0; index < ordered.Length; index++)
        {
            var item = ordered[index];
            var position = index + 1;
            SetSingle(model, values, "assignment", item.JobId, position);
            SetEncoded(model, values, "completion-bit", item.Completion, position: position);
            SetEncoded(model, values, "idle-bit", item.Start - previousCompletion, position: position);
            SetEncoded(model, values, "earliness-bit", item.Earliness, jobId: item.JobId);
            SetEncoded(model, values, "tardiness-bit", item.Tardiness, jobId: item.JobId);
            previousCompletion = item.Completion;
        }

        var assignments = model.Variables
            .Where(variable => variable.Kind == "assignment")
            .ToDictionary(variable => (variable.JobId, variable.Position), variable => variable.Index);
        var completionBits = model.Variables
            .Where(variable => variable.Kind == "completion-bit")
            .ToDictionary(variable => (variable.Position, variable.Bit), variable => variable.Index);
        foreach (var product in model.Variables.Where(variable => variable.Kind == "product"))
        {
            var assignmentIndex = assignments[(product.JobId, product.Position)];
            var completionIndex = completionBits[(product.Position, product.Bit)];
            values[product.Index] = values[assignmentIndex] * values[completionIndex];
        }

        var expectedObjective = classicalSchedule.Sum(item => item.Cost);
        var energy = model.Evaluate(values);
        if (Math.Abs(energy - expectedObjective) > tolerance)
        {
            throw new InvalidOperationException(
                $"Pozisyon QUBO warm start enerji doğrulaması başarısız: enerji={energy}, klasik amaç={expectedObjective}.");
        }
        return values;
    }

    private static void SetSingle(
        QuboModel model,
        IList<int> values,
        string kind,
        int jobId,
        int position)
    {
        var variable = model.Variables.Single(item =>
            item.Kind == kind && item.JobId == jobId && item.Position == position);
        values[variable.Index] = 1;
    }

    private static void SetEncoded(
        QuboModel model,
        IList<int> values,
        string kind,
        int target,
        int? jobId = null,
        int? position = null)
    {
        if (target < 0)
            throw new InvalidOperationException($"{kind} için negatif değer kodlanamaz: {target}.");
        var candidates = model.Variables
            .Where(variable => variable.Kind == kind)
            .Where(variable => !jobId.HasValue || variable.JobId == jobId)
            .Where(variable => !position.HasValue || variable.Position == position)
            .OrderBy(variable => variable.Bit)
            .ToArray();
        var reachable = new Dictionary<int, IReadOnlyList<int>> { [0] = [] };
        foreach (var candidate in candidates)
        {
            var weight = candidate.Weight
                ?? throw new InvalidOperationException($"{candidate.Name} için bit ağırlığı eksik.");
            foreach (var state in reachable.ToArray())
            {
                var next = state.Key + weight;
                if (next > target || reachable.ContainsKey(next))
                    continue;
                reachable[next] = state.Value.Append(candidate.Index).ToArray();
            }
        }
        if (!reachable.TryGetValue(target, out var selected))
            throw new InvalidOperationException($"{kind} değeri {target} ikili bitlerle kodlanamadı.");
        foreach (var variableIndex in selected)
            values[variableIndex] = 1;
    }
}
