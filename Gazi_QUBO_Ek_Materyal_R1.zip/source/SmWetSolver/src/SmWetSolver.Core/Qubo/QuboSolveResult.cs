namespace SmWetSolver.Core.Qubo;

public sealed record QuboSolveResult
{
    public required string Solver { get; init; }
    public required string Status { get; init; }
    public required double Energy { get; init; }
    public required double RuntimeSeconds { get; init; }
    public double? MipGap { get; init; }
    public double? NodeCount { get; init; }
    public ulong? EvaluatedStates { get; init; }
    public required IReadOnlyList<int> Values { get; init; }
}
