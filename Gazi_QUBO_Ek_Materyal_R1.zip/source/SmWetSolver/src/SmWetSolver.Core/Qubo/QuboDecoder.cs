using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Core.Qubo;

public static class QuboDecoder
{
    public static QuboDecodedSolution Decode(
        SchedulingInstance instance,
        QuboModel model,
        QuboSolveResult solution,
        double tolerance = 1e-6) => model.Formulation switch
    {
        "time-indexed" => TimeIndexedQuboDecoder.Decode(instance, model, solution, tolerance),
        "position" => DecodePosition(instance, model, solution, tolerance),
        "precedence" => DecodePrecedence(instance, model, solution, tolerance),
        _ => throw new ArgumentException($"Bilinmeyen QUBO formülasyonu: {model.Formulation}.", nameof(model))
    };

    private static QuboDecodedSolution DecodePosition(
        SchedulingInstance instance,
        QuboModel model,
        QuboSolveResult solution,
        double tolerance)
    {
        ValidateVector(model, solution);
        var selected = SelectedVariables(model, solution.Values);
        var errors = new List<string>();
        var schedule = new List<JobSchedule>();
        var usedJobs = new HashSet<int>();
        for (var position = 1; position <= instance.Jobs.Count; position++)
        {
            var assignments = selected
                .Where(variable => variable.Kind == "assignment" && variable.Position == position)
                .ToArray();
            if (assignments.Length != 1 || assignments[0].JobId is not int jobId)
            {
                errors.Add($"Pozisyon {position} için seçilen iş sayısı {assignments.Length}; beklenen 1.");
                continue;
            }

            if (!usedJobs.Add(jobId))
                errors.Add($"İş {jobId} birden fazla pozisyona atanmış.");
            var job = instance.Jobs.Single(item => item.Id == jobId);
            var completion = QuboBuilderSupport.Decode(
                model,
                solution.Values,
                "completion-bit",
                position: position);
            schedule.Add(CostCalculator.CreateSchedule(job, completion - job.ProcessingTime));
        }

        var missing = instance.Jobs.Select(job => job.Id).Except(usedJobs).ToArray();
        if (missing.Length > 0)
            errors.Add($"Atanmayan işler: {string.Join(", ", missing)}.");
        return Finish(instance, model, solution, selected, schedule, errors, tolerance);
    }

    private static QuboDecodedSolution DecodePrecedence(
        SchedulingInstance instance,
        QuboModel model,
        QuboSolveResult solution,
        double tolerance)
    {
        ValidateVector(model, solution);
        var selected = SelectedVariables(model, solution.Values);
        var schedule = instance.Jobs
            .Select(job => CostCalculator.CreateSchedule(
                job,
                QuboBuilderSupport.Decode(model, solution.Values, "start-bit", job.Id)))
            .ToList();
        return Finish(instance, model, solution, selected, schedule, [], tolerance);
    }

    private static QuboDecodedSolution Finish(
        SchedulingInstance instance,
        QuboModel model,
        QuboSolveResult solution,
        IReadOnlyList<QuboVariable> selected,
        IReadOnlyList<JobSchedule> schedule,
        ICollection<string> errors,
        double tolerance)
    {
        double? objective = null;
        if (schedule.Count == instance.Jobs.Count)
        {
            objective = schedule.Sum(item => item.Cost);
            foreach (var error in ScheduleValidator.Validate(instance, schedule, objective.Value, tolerance))
                errors.Add(error);
        }

        var energy = model.Evaluate(solution.Values);
        if (Math.Abs(energy - solution.Energy) > tolerance)
            errors.Add($"Enerji uyuşmazlığı: model={energy}, solver={solution.Energy}.");
        double? penaltyEnergy = objective.HasValue ? energy - objective.Value : null;
        if (penaltyEnergy.HasValue && Math.Abs(penaltyEnergy.Value) > tolerance)
        {
            errors.Add(
                $"QUBO yardımcı değişken/kısıt tutarsızlığı: enerji-çizelge amacı={penaltyEnergy.Value}.");
        }
        return new QuboDecodedSolution
        {
            Feasible = errors.Count == 0,
            SchedulingObjective = objective,
            QuboEnergy = energy,
            PenaltyEnergy = penaltyEnergy,
            SelectedVariables = selected.Select(variable => variable.Name).ToArray(),
            Schedule = schedule.OrderBy(item => item.Start).ThenBy(item => item.JobId).ToArray(),
            Errors = errors.ToArray()
        };
    }

    private static void ValidateVector(QuboModel model, QuboSolveResult solution)
    {
        if (solution.Values.Count != model.NumVariables)
            throw new ArgumentException("QUBO çözüm vektörü model boyutuyla uyuşmuyor.", nameof(solution));
    }

    private static IReadOnlyList<QuboVariable> SelectedVariables(
        QuboModel model,
        IReadOnlyList<int> values) => model.Variables
        .Where(variable => values[variable.Index] == 1)
        .ToArray();
}
