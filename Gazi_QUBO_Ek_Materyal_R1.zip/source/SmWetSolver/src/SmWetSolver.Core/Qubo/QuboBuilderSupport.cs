using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Core.Qubo;

internal sealed record WeightedQuboBit(int Index, int Weight);

internal static class QuboBuilderSupport
{
    public static IReadOnlyList<int> BoundedBinaryWeights(int maximum)
    {
        if (maximum < 0)
            throw new ArgumentOutOfRangeException(nameof(maximum));
        if (maximum == 0)
            return [];

        var weights = new List<int>();
        var representedMaximum = 0;
        var nextPower = 1;
        while (representedMaximum + nextPower < maximum)
        {
            weights.Add(nextPower);
            representedMaximum += nextPower;
            nextPower *= 2;
        }

        var remainder = maximum - representedMaximum;
        if (remainder > 0)
            weights.Add(remainder);
        return weights;
    }

    public static void AddTerms(
        ICollection<(int Index, double Coefficient)> target,
        IEnumerable<WeightedQuboBit> bits,
        double multiplier = 1.0)
    {
        foreach (var bit in bits)
            target.Add((bit.Index, multiplier * bit.Weight));
    }

    public static int Decode(
        QuboModel model,
        IReadOnlyList<int> values,
        string kind,
        int? jobId = null,
        int? position = null,
        int? otherJobId = null,
        string? direction = null) => model.Variables
        .Where(variable => variable.Kind == kind)
        .Where(variable => !jobId.HasValue || variable.JobId == jobId)
        .Where(variable => !position.HasValue || variable.Position == position)
        .Where(variable => !otherJobId.HasValue || variable.OtherJobId == otherJobId)
        .Where(variable => direction is null || variable.Direction == direction)
        .Where(variable => values[variable.Index] == 1)
        .Sum(variable => variable.Weight ?? 1);

    public static double CalculateFeasibleUpperBound(SchedulingInstance instance)
    {
        var totalProcessingTime = instance.Jobs.Sum(job => job.ProcessingTime);
        IReadOnlyList<JobData>[] candidateOrders =
        [
            instance.Jobs.ToArray(),
            instance.Jobs.OrderBy(job => job.DueDate).ThenBy(job => job.Id).ToArray(),
            instance.Jobs.OrderBy(job => job.ProcessingTime).ThenBy(job => job.Id).ToArray()
        ];
        var upperBound = double.PositiveInfinity;
        foreach (var order in candidateOrders)
        {
            for (var blockStart = 0; blockStart <= instance.EffectiveHorizon - totalProcessingTime; blockStart++)
            {
                var completion = blockStart;
                var candidate = 0.0;
                foreach (var job in order)
                {
                    completion += job.ProcessingTime;
                    candidate += CostCalculator.AtCompletion(job, completion);
                }
                upperBound = Math.Min(upperBound, candidate);
            }
        }
        return upperBound;
    }

    public static double ValidateAndChoosePenalty(double feasibleUpperBound, double? penaltyOverride)
    {
        var penalty = penaltyOverride ?? feasibleUpperBound + 1.0;
        if (penalty <= 0.0 || !double.IsFinite(penalty))
            throw new ArgumentOutOfRangeException(nameof(penaltyOverride), "Ceza katsayısı pozitif ve sonlu olmalıdır.");
        return penalty;
    }
}
