using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Qubo;

public sealed record QuboValidationReport
{
    public required string InstanceName { get; init; }
    public required string Formulation { get; init; }
    public required int NumVariables { get; init; }
    public required int LinearTermCount { get; init; }
    public required int QuadraticTermCount { get; init; }
    public required double Penalty { get; init; }
    public required double FeasibleUpperBound { get; init; }
    public required bool PenaltyGuaranteeSatisfied { get; init; }
    public required double ClassicalOptimum { get; init; }
    public required QuboSolveResult QuboSolve { get; init; }
    public required QuboDecodedSolution Decoded { get; init; }
    public required bool MatchesClassicalOptimum { get; init; }
    public required IReadOnlyList<JobSchedule> ClassicalSchedule { get; init; }
}
