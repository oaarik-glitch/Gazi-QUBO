using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Core.Qubo;

public static class TimeIndexedQuboDecoder
{
    public static QuboDecodedSolution Decode(
        SchedulingInstance instance,
        QuboModel model,
        QuboSolveResult solution,
        double tolerance = 1e-6)
    {
        if (solution.Values.Count != model.NumVariables)
            throw new ArgumentException("QUBO çözüm vektörü model boyutuyla uyuşmuyor.", nameof(solution));

        var selected = model.Variables
            .Where(variable => solution.Values[variable.Index] == 1)
            .ToArray();
        var errors = new List<string>();
        var schedule = new List<JobSchedule>();
        foreach (var job in instance.Jobs)
        {
            var selections = selected.Where(variable => variable.JobId == job.Id).ToArray();
            if (selections.Length != 1)
            {
                errors.Add($"İş {job.Id} için seçilen başlangıç sayısı {selections.Length}; beklenen 1.");
                continue;
            }
            if (selections[0].StartTime is not int startTime)
            {
                errors.Add($"İş {job.Id} için başlangıç zamanı meta verisi eksik.");
                continue;
            }
            schedule.Add(CostCalculator.CreateSchedule(job, startTime));
        }

        double? schedulingObjective = null;
        if (schedule.Count == instance.Jobs.Count)
        {
            schedulingObjective = schedule.Sum(item => item.Cost);
            errors.AddRange(ScheduleValidator.Validate(instance, schedule, schedulingObjective.Value, tolerance));
        }

        var evaluatedEnergy = model.Evaluate(solution.Values);
        if (Math.Abs(evaluatedEnergy - solution.Energy) > tolerance)
            errors.Add($"Enerji uyuşmazlığı: model={evaluatedEnergy}, solver={solution.Energy}.");
        double? penaltyEnergy = schedulingObjective.HasValue
            ? evaluatedEnergy - schedulingObjective.Value
            : null;
        if (penaltyEnergy.HasValue && Math.Abs(penaltyEnergy.Value) > tolerance)
        {
            errors.Add(
                $"QUBO yardımcı değişken/kısıt tutarsızlığı: enerji-çizelge amacı={penaltyEnergy.Value}.");
        }

        var feasible = errors.Count == 0;
        return new QuboDecodedSolution
        {
            Feasible = feasible,
            SchedulingObjective = schedulingObjective,
            QuboEnergy = evaluatedEnergy,
            PenaltyEnergy = penaltyEnergy,
            SelectedVariables = selected.Select(variable => variable.Name).ToArray(),
            Schedule = schedule.OrderBy(item => item.Start).ThenBy(item => item.JobId).ToArray(),
            Errors = errors
        };
    }
}
