using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Qubo;

public sealed record QuboDecodedSolution
{
    public required bool Feasible { get; init; }
    public double? SchedulingObjective { get; init; }
    public required double QuboEnergy { get; init; }
    public double? PenaltyEnergy { get; init; }
    public required IReadOnlyList<string> SelectedVariables { get; init; }
    public required IReadOnlyList<JobSchedule> Schedule { get; init; }
    public required IReadOnlyList<string> Errors { get; init; }
}
