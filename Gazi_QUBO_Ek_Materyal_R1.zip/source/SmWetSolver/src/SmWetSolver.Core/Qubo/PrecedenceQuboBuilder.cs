using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Qubo;

public sealed class PrecedenceQuboBuilder
{
    public QuboModel Build(SchedulingInstance instance, double? penaltyOverride = null)
    {
        instance.Validate();
        var n = instance.Jobs.Count;
        var horizon = instance.EffectiveHorizon;
        var upperBound = QuboBuilderSupport.CalculateFeasibleUpperBound(instance);
        var penalty = QuboBuilderSupport.ValidateAndChoosePenalty(upperBound, penaltyOverride);
        var variables = new List<QuboVariable>();

        int AddVariable(
            string name,
            string kind,
            int? jobId = null,
            int? otherJobId = null,
            int? bit = null,
            int? weight = null,
            string? direction = null)
        {
            var index = variables.Count;
            variables.Add(new QuboVariable
            {
                Index = index,
                Name = name,
                Kind = kind,
                JobId = jobId,
                OtherJobId = otherJobId,
                Bit = bit,
                Weight = weight,
                Direction = direction
            });
            return index;
        }

        IReadOnlyList<WeightedQuboBit> AddEncoded(
            string prefix,
            string kind,
            int maximum,
            int? jobId = null,
            int? otherJobId = null,
            string? direction = null)
        {
            var weights = QuboBuilderSupport.BoundedBinaryWeights(maximum);
            return weights.Select((weight, bit) => new WeightedQuboBit(
                AddVariable($"{prefix}_{bit}", kind, jobId, otherJobId, bit, weight, direction),
                weight)).ToArray();
        }

        var start = new IReadOnlyList<WeightedQuboBit>[n];
        var earliness = new IReadOnlyList<WeightedQuboBit>[n];
        var tardiness = new IReadOnlyList<WeightedQuboBit>[n];
        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            start[i] = AddEncoded(
                $"s_{job.Id}",
                "start-bit",
                horizon - job.ProcessingTime,
                job.Id);
            earliness[i] = AddEncoded($"e_{job.Id}", "earliness-bit", job.DueDate, job.Id);
            tardiness[i] = AddEncoded(
                $"t_{job.Id}",
                "tardiness-bit",
                Math.Max(0, horizon - job.DueDate),
                job.Id);
        }

        var order = new Dictionary<(int I, int J), int>();
        var firstSlack = new Dictionary<(int I, int J), IReadOnlyList<WeightedQuboBit>>();
        var secondSlack = new Dictionary<(int I, int J), IReadOnlyList<WeightedQuboBit>>();
        for (var i = 0; i < n; i++)
        {
            for (var j = i + 1; j < n; j++)
            {
                var firstId = instance.Jobs[i].Id;
                var secondId = instance.Jobs[j].Id;
                order[(i, j)] = AddVariable(
                    $"y_{firstId}_{secondId}",
                    "precedence",
                    firstId,
                    secondId);
                firstSlack[(i, j)] = AddEncoded(
                    $"r_{firstId}_{secondId}",
                    "slack-bit",
                    2 * horizon,
                    firstId,
                    secondId,
                    "first-before-second");
                secondSlack[(i, j)] = AddEncoded(
                    $"v_{firstId}_{secondId}",
                    "slack-bit",
                    2 * horizon,
                    firstId,
                    secondId,
                    "second-before-first");
            }
        }

        var qubo = new QuboAccumulator();
        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            var terms = new List<(int Index, double Coefficient)>();
            QuboBuilderSupport.AddTerms(terms, start[i], -1.0);
            QuboBuilderSupport.AddTerms(terms, earliness[i], -1.0);
            QuboBuilderSupport.AddTerms(terms, tardiness[i]);
            qubo.AddSquaredLinear(job.DueDate - job.ProcessingTime, terms, penalty);
            foreach (var bit in earliness[i])
                qubo.AddLinear(bit.Index, job.EarlinessWeight * bit.Weight);
            foreach (var bit in tardiness[i])
                qubo.AddLinear(bit.Index, job.TardinessWeight * bit.Weight);
        }

        var disjunctiveConstraintCount = 0;
        for (var i = 0; i < n; i++)
        {
            for (var j = i + 1; j < n; j++)
            {
                var y = order[(i, j)];
                var first = new List<(int Index, double Coefficient)>();
                QuboBuilderSupport.AddTerms(first, start[j]);
                QuboBuilderSupport.AddTerms(first, start[i], -1.0);
                first.Add((y, -horizon));
                QuboBuilderSupport.AddTerms(first, firstSlack[(i, j)], -1.0);
                qubo.AddSquaredLinear(horizon - instance.Jobs[i].ProcessingTime, first, penalty);

                var second = new List<(int Index, double Coefficient)>();
                QuboBuilderSupport.AddTerms(second, start[i]);
                QuboBuilderSupport.AddTerms(second, start[j], -1.0);
                second.Add((y, horizon));
                QuboBuilderSupport.AddTerms(second, secondSlack[(i, j)], -1.0);
                qubo.AddSquaredLinear(-instance.Jobs[j].ProcessingTime, second, penalty);
                disjunctiveConstraintCount += 2;
            }
        }

        var familyCounts = variables
            .GroupBy(variable => variable.Kind)
            .ToDictionary(group => group.Key, group => group.Count());
        return new QuboModel
        {
            SchemaVersion = "1.1",
            Name = $"{instance.Name}_precedence_qubo",
            Formulation = "precedence",
            NumVariables = variables.Count,
            Constant = qubo.Constant,
            Variables = variables,
            Linear = qubo.LinearTerms(),
            Quadratic = qubo.QuadraticTerms(),
            Metadata = new QuboMetadata
            {
                SourceInstance = instance.Name,
                JobCount = n,
                Horizon = horizon,
                FeasibleUpperBound = upperBound,
                MinimumSafePenalty = upperBound + 1.0,
                Penalty = penalty,
                PenaltyGuaranteeSatisfied = penalty > upperBound,
                ObjectiveConvention = "constant + sum_i linear[i]*x_i + sum_{i<j} quadratic[i,j]*x_i*x_j",
                IntegerEncoding = "bounded binary weights with exact range 0..maximum",
                VariableFamilyCounts = familyCounts,
                ConstraintGroupCounts = new Dictionary<string, int>
                {
                    ["earlinessTardinessDefinitions"] = n,
                    ["disjunctiveEqualities"] = disjunctiveConstraintCount
                }
            }
        };
    }
}
