namespace SmWetSolver.Core.Qubo;

public sealed record QuboModel
{
    public required string SchemaVersion { get; init; }
    public required string Name { get; init; }
    public required string Formulation { get; init; }
    public required int NumVariables { get; init; }
    public required double Constant { get; init; }
    public required IReadOnlyList<QuboVariable> Variables { get; init; }
    public required IReadOnlyList<QuboLinearTerm> Linear { get; init; }
    public required IReadOnlyList<QuboQuadraticTerm> Quadratic { get; init; }
    public required QuboMetadata Metadata { get; init; }

    public double Evaluate(IReadOnlyList<int> values)
    {
        if (values.Count != NumVariables)
            throw new ArgumentException("QUBO çözüm vektörü uzunluğu geçersiz.", nameof(values));
        if (values.Any(value => value is not (0 or 1)))
            throw new ArgumentException("QUBO çözüm vektörü yalnızca 0/1 içermelidir.", nameof(values));

        var energy = Constant;
        foreach (var term in Linear)
            energy += term.Value * values[term.Index];
        foreach (var term in Quadratic)
            energy += term.Value * values[term.I] * values[term.J];
        return energy;
    }

    public double EvaluateMask(ulong mask)
    {
        if (NumVariables > 63)
            throw new InvalidOperationException("Bit maskesi en fazla 63 QUBO değişkenini destekler.");
        var energy = Constant;
        foreach (var term in Linear)
        {
            if (((mask >> term.Index) & 1UL) != 0)
                energy += term.Value;
        }
        foreach (var term in Quadratic)
        {
            if (((mask >> term.I) & 1UL) != 0 && ((mask >> term.J) & 1UL) != 0)
                energy += term.Value;
        }
        return energy;
    }
}
