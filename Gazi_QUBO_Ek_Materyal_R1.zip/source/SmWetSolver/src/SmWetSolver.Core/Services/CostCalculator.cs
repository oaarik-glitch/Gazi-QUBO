using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Services;

public static class CostCalculator
{
    public static JobSchedule CreateSchedule(JobData job, int start)
    {
        var completion = checked(start + job.ProcessingTime);
        var earliness = Math.Max(0, job.DueDate - completion);
        var tardiness = Math.Max(0, completion - job.DueDate);
        var cost = checked(job.EarlinessWeight * earliness + job.TardinessWeight * tardiness);

        return new JobSchedule
        {
            JobId = job.Id,
            Start = start,
            Completion = completion,
            Earliness = earliness,
            Tardiness = tardiness,
            Cost = cost
        };
    }

    public static double AtCompletion(JobData job, int completion)
    {
        var earliness = Math.Max(0, job.DueDate - completion);
        var tardiness = Math.Max(0, completion - job.DueDate);
        return checked(job.EarlinessWeight * earliness + job.TardinessWeight * tardiness);
    }
}
