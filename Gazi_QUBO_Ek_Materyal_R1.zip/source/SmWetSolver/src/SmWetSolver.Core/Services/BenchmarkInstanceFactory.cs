using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Services;

public static class BenchmarkInstanceFactory
{
    public static IReadOnlyList<GeneratedBenchmark> Generate(BenchmarkGenerationOptions options)
    {
        options.Validate();
        var generated = new List<GeneratedBenchmark>();

        foreach (var jobCount in options.JobCounts)
        {
            for (var replicate = 1; replicate <= options.InstancesPerSize; replicate++)
            {
                var seed = checked(options.BaseSeed + (ulong)(jobCount * 1_000 + replicate));
                var random = new SplitMix64Random(seed);
                var processingTimes = Enumerable.Range(0, jobCount)
                    .Select(_ => random.NextIntInclusive(options.MinProcessingTime, options.MaxProcessingTime))
                    .ToArray();
                var totalProcessingTime = processingTimes.Sum();
                var tardinessFactor = options.TardinessFactors[(replicate - 1) % options.TardinessFactors.Count];
                var dueDateRange = options.DueDateRanges[(replicate - 1) % options.DueDateRanges.Count];
                var lowerDueDate = Math.Max(
                    0,
                    (int)Math.Floor(totalProcessingTime * (1.0 - tardinessFactor - dueDateRange / 2.0)));
                var upperDueDate = Math.Max(
                    lowerDueDate,
                    (int)Math.Ceiling(totalProcessingTime * (1.0 - tardinessFactor + dueDateRange / 2.0)));

                var jobs = new List<JobData>(jobCount);
                for (var i = 0; i < jobCount; i++)
                {
                    jobs.Add(new JobData
                    {
                        Id = i + 1,
                        ProcessingTime = processingTimes[i],
                        DueDate = random.NextIntInclusive(lowerDueDate, upperDueDate),
                        EarlinessWeight = random.NextIntInclusive(options.MinWeight, options.MaxWeight),
                        TardinessWeight = random.NextIntInclusive(options.MinWeight, options.MaxWeight)
                    });
                }

                var instance = new SchedulingInstance
                {
                    Name = $"n{jobCount:D2}_r{replicate:D2}_s{seed}",
                    Jobs = jobs,
                    Horizon = jobs.Max(job => job.DueDate) + totalProcessingTime
                };
                instance.Validate();
                generated.Add(new GeneratedBenchmark
                {
                    Instance = instance,
                    Replicate = replicate,
                    Seed = seed,
                    TardinessFactor = tardinessFactor,
                    DueDateRange = dueDateRange
                });
            }
        }

        return generated;
    }
}
