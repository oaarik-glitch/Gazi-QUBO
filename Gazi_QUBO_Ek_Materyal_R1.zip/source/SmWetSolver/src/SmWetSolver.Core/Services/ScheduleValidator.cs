using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Services;

public static class ScheduleValidator
{
    public static IReadOnlyList<string> Validate(
        SchedulingInstance instance,
        IReadOnlyList<JobSchedule> schedule,
        double claimedObjective,
        double tolerance = 1e-6)
    {
        var errors = new List<string>();
        var jobsById = instance.Jobs.ToDictionary(job => job.Id);

        if (schedule.Count != instance.Jobs.Count)
            errors.Add($"İş sayısı uyuşmuyor: beklenen {instance.Jobs.Count}, bulunan {schedule.Count}.");

        var duplicates = schedule.GroupBy(item => item.JobId)
            .Where(group => group.Count() > 1)
            .Select(group => group.Key)
            .ToArray();
        if (duplicates.Length > 0)
            errors.Add($"Birden çok kez çizelgelenen işler: {string.Join(", ", duplicates)}.");

        foreach (var item in schedule)
        {
            if (!jobsById.TryGetValue(item.JobId, out var job))
            {
                errors.Add($"Bilinmeyen iş: {item.JobId}.");
                continue;
            }

            if (item.Start < 0)
                errors.Add($"İş {item.JobId}: negatif başlangıç zamanı.");
            if (item.Completion != item.Start + job.ProcessingTime)
                errors.Add($"İş {item.JobId}: tamamlanma zamanı tutarsız.");
            if (item.Completion > instance.EffectiveHorizon)
                errors.Add($"İş {item.JobId}: zaman ufku aşıldı.");

            var expected = CostCalculator.CreateSchedule(job, item.Start);
            if (item.Earliness != expected.Earliness || item.Tardiness != expected.Tardiness)
                errors.Add($"İş {item.JobId}: erkenlik/geçlik değeri tutarsız.");
            if (Math.Abs(item.Cost - expected.Cost) > tolerance)
                errors.Add($"İş {item.JobId}: maliyet tutarsız.");
        }

        var ordered = schedule.OrderBy(item => item.Start).ThenBy(item => item.JobId).ToArray();
        for (var k = 1; k < ordered.Length; k++)
        {
            if (ordered[k].Start < ordered[k - 1].Completion)
                errors.Add($"Çakışma: iş {ordered[k - 1].JobId} ile iş {ordered[k].JobId}.");
        }

        var missing = instance.Jobs.Select(job => job.Id)
            .Except(schedule.Select(item => item.JobId))
            .ToArray();
        if (missing.Length > 0)
            errors.Add($"Eksik işler: {string.Join(", ", missing)}.");

        var calculatedObjective = schedule.Sum(item => item.Cost);
        if (Math.Abs(calculatedObjective - claimedObjective) > tolerance)
            errors.Add($"Amaç değeri tutarsız: hesaplanan {calculatedObjective}, bildirilen {claimedObjective}.");

        return errors;
    }
}
