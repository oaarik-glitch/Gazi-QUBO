using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Services;

public static class EquivalenceValidator
{
    public static void AssertEquivalent(IEnumerable<SolveResult> results, double tolerance = 1e-6)
    {
        var materialized = results.ToArray();
        if (materialized.Length < 2)
            throw new ArgumentException("Karşılaştırma için en az iki sonuç gereklidir.", nameof(results));

        var invalid = materialized.Where(result => !result.IndependentValidationPassed).ToArray();
        if (invalid.Length > 0)
        {
            var names = string.Join(", ", invalid.Select(result => result.ModelName));
            throw new InvalidOperationException($"Bağımsız doğrulamayı geçemeyen modeller: {names}.");
        }

        var reference = materialized[0];
        foreach (var result in materialized.Skip(1))
        {
            if (Math.Abs(reference.ObjectiveValue - result.ObjectiveValue) > tolerance)
            {
                throw new InvalidOperationException(
                    $"Amaç değerleri eşdeğer değil: {reference.ModelName}={reference.ObjectiveValue}, " +
                    $"{result.ModelName}={result.ObjectiveValue}.");
            }
        }
    }
}
