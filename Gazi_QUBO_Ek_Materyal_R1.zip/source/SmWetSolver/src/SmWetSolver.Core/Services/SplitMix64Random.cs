namespace SmWetSolver.Core.Services;

/// <summary>
/// Platform-independent deterministic generator. The same seed produces the
/// same benchmark values in C#, Python, Windows and Linux.
/// </summary>
public sealed class SplitMix64Random
{
    private ulong _state;

    public SplitMix64Random(ulong seed) => _state = seed;

    public ulong NextUInt64()
    {
        _state += 0x9E3779B97F4A7C15UL;
        var value = _state;
        value = (value ^ (value >> 30)) * 0xBF58476D1CE4E5B9UL;
        value = (value ^ (value >> 27)) * 0x94D049BB133111EBUL;
        return value ^ (value >> 31);
    }

    public int NextIntInclusive(int minimum, int maximum)
    {
        if (maximum < minimum)
            throw new ArgumentOutOfRangeException(nameof(maximum));
        var width = checked((ulong)(maximum - minimum + 1));
        return checked(minimum + (int)(NextUInt64() % width));
    }
}
