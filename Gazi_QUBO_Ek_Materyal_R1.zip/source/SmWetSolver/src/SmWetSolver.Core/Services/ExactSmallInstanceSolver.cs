using System.Diagnostics;
using SmWetSolver.Core.Models;

namespace SmWetSolver.Core.Services;

public sealed class ExactSmallInstanceSolver
{
    private const double Infinity = double.PositiveInfinity;

    public SolveResult Solve(SchedulingInstance instance)
    {
        instance.Validate();
        if (instance.Jobs.Count > 9)
            throw new ArgumentOutOfRangeException(nameof(instance), "Exact doğrulayıcı en fazla 9 iş içindir.");

        var stopwatch = Stopwatch.StartNew();
        var permutation = Enumerable.Range(0, instance.Jobs.Count).ToArray();
        var bestObjective = Infinity;
        int[]? bestOrder = null;
        int[]? bestCompletions = null;

        SearchPermutations(0);
        stopwatch.Stop();

        if (bestOrder is null || bestCompletions is null)
            throw new InvalidOperationException("Exact doğrulayıcı uygulanabilir çizelge bulamadı.");

        var schedule = new List<JobSchedule>(instance.Jobs.Count);
        for (var k = 0; k < bestOrder.Length; k++)
        {
            var job = instance.Jobs[bestOrder[k]];
            schedule.Add(CostCalculator.CreateSchedule(job, bestCompletions[k] - job.ProcessingTime));
        }

        var errors = ScheduleValidator.Validate(instance, schedule, bestObjective);
        return new SolveResult
        {
            InstanceName = instance.Name,
            ModelName = "Exact-Permutation-DP",
            Status = "OPTIMAL",
            ObjectiveValue = bestObjective,
            RuntimeSeconds = stopwatch.Elapsed.TotalSeconds,
            Schedule = schedule,
            IndependentValidationPassed = errors.Count == 0,
            ValidationErrors = errors
        };

        void SearchPermutations(int position)
        {
            if (position == permutation.Length)
            {
                var (objective, completions) = OptimizeTimingForOrder(instance, permutation);
                if (objective + 1e-9 < bestObjective)
                {
                    bestObjective = objective;
                    bestOrder = (int[])permutation.Clone();
                    bestCompletions = completions;
                }
                return;
            }

            for (var candidate = position; candidate < permutation.Length; candidate++)
            {
                (permutation[position], permutation[candidate]) = (permutation[candidate], permutation[position]);
                SearchPermutations(position + 1);
                (permutation[position], permutation[candidate]) = (permutation[candidate], permutation[position]);
            }
        }
    }

    private static (double Objective, int[] Completions) OptimizeTimingForOrder(
        SchedulingInstance instance,
        IReadOnlyList<int> order)
    {
        var n = order.Count;
        var horizon = instance.EffectiveHorizon;
        var dp = new double[n, horizon + 1];
        var predecessor = new int[n, horizon + 1];

        for (var k = 0; k < n; k++)
        {
            for (var completion = 0; completion <= horizon; completion++)
            {
                dp[k, completion] = Infinity;
                predecessor[k, completion] = -1;
            }
        }

        var first = instance.Jobs[order[0]];
        for (var completion = first.ProcessingTime; completion <= horizon; completion++)
            dp[0, completion] = CostCalculator.AtCompletion(first, completion);

        for (var k = 1; k < n; k++)
        {
            var job = instance.Jobs[order[k]];
            var prefixBest = new double[horizon + 1];
            var prefixArg = new int[horizon + 1];
            var runningBest = Infinity;
            var runningArg = -1;

            for (var completion = 0; completion <= horizon; completion++)
            {
                if (dp[k - 1, completion] < runningBest)
                {
                    runningBest = dp[k - 1, completion];
                    runningArg = completion;
                }
                prefixBest[completion] = runningBest;
                prefixArg[completion] = runningArg;
            }

            for (var completion = job.ProcessingTime; completion <= horizon; completion++)
            {
                var latestPreviousCompletion = completion - job.ProcessingTime;
                if (double.IsPositiveInfinity(prefixBest[latestPreviousCompletion]))
                    continue;

                dp[k, completion] = prefixBest[latestPreviousCompletion]
                    + CostCalculator.AtCompletion(job, completion);
                predecessor[k, completion] = prefixArg[latestPreviousCompletion];
            }
        }

        var bestObjective = Infinity;
        var bestFinalCompletion = -1;
        for (var completion = 0; completion <= horizon; completion++)
        {
            if (dp[n - 1, completion] < bestObjective)
            {
                bestObjective = dp[n - 1, completion];
                bestFinalCompletion = completion;
            }
        }

        var completions = new int[n];
        completions[n - 1] = bestFinalCompletion;
        for (var k = n - 1; k > 0; k--)
            completions[k - 1] = predecessor[k, completions[k]];

        return (bestObjective, completions);
    }
}
