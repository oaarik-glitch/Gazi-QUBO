namespace SmWetSolver.Core.Models;

public sealed record GeneratedBenchmark
{
    public required SchedulingInstance Instance { get; init; }
    public required int Replicate { get; init; }
    public required ulong Seed { get; init; }
    public required double TardinessFactor { get; init; }
    public required double DueDateRange { get; init; }
}
