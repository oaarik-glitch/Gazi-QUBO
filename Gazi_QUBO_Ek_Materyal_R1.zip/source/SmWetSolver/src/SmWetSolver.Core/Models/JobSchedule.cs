namespace SmWetSolver.Core.Models;

public sealed record JobSchedule
{
    public required int JobId { get; init; }
    public required int Start { get; init; }
    public required int Completion { get; init; }
    public required int Earliness { get; init; }
    public required int Tardiness { get; init; }
    public required double Cost { get; init; }
}
