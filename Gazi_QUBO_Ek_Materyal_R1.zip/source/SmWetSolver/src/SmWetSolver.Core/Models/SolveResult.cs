namespace SmWetSolver.Core.Models;

public sealed record SolveResult
{
    public required string InstanceName { get; init; }
    public required string ModelName { get; init; }
    public required string Status { get; init; }
    public required double ObjectiveValue { get; init; }
    public required double RuntimeSeconds { get; init; }
    public double? MipGap { get; init; }
    public double? NodeCount { get; init; }
    public int? VariableCount { get; init; }
    public int? ConstraintCount { get; init; }
    public required IReadOnlyList<JobSchedule> Schedule { get; init; }
    public required bool IndependentValidationPassed { get; init; }
    public IReadOnlyList<string> ValidationErrors { get; init; } = [];
}
