namespace SmWetSolver.Core.Models;

public sealed record BenchmarkGenerationOptions
{
    public ulong BaseSeed { get; init; } = 20_260_902;
    public IReadOnlyList<int> JobCounts { get; init; } = [4, 5, 6];
    public int InstancesPerSize { get; init; } = 5;
    public int MinProcessingTime { get; init; } = 1;
    public int MaxProcessingTime { get; init; } = 10;
    public int MinWeight { get; init; } = 1;
    public int MaxWeight { get; init; } = 5;
    public IReadOnlyList<double> TardinessFactors { get; init; } = [0.2, 0.4, 0.6, 0.8, 0.5];
    public IReadOnlyList<double> DueDateRanges { get; init; } = [0.4, 0.6, 0.8, 1.0, 0.2];

    public void Validate()
    {
        if (JobCounts.Count == 0 || JobCounts.Any(count => count <= 0))
            throw new ArgumentException("İş sayıları pozitif olmalıdır.");
        if (InstancesPerSize <= 0)
            throw new ArgumentOutOfRangeException(nameof(InstancesPerSize));
        if (MinProcessingTime <= 0 || MaxProcessingTime < MinProcessingTime)
            throw new ArgumentException("İşlem süresi aralığı geçersiz.");
        if (MinWeight < 0 || MaxWeight < MinWeight)
            throw new ArgumentException("Ağırlık aralığı geçersiz.");
        if (TardinessFactors.Count == 0 || DueDateRanges.Count == 0)
            throw new ArgumentException("T ve R dizileri boş olamaz.");
        if (TardinessFactors.Any(value => value < 0.0 || value > 1.0))
            throw new ArgumentException("Tardiness factor değerleri [0,1] aralığında olmalıdır.");
        if (DueDateRanges.Any(value => value < 0.0 || value > 2.0))
            throw new ArgumentException("Due-date range değerleri [0,2] aralığında olmalıdır.");
    }
}
