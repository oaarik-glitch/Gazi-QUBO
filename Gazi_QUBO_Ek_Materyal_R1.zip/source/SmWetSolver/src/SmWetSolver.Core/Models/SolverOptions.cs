namespace SmWetSolver.Core.Models;

public sealed record SolverOptions
{
    public double TimeLimitSeconds { get; init; } = 300.0;
    public double MipGap { get; init; } = 0.0;
    public int Threads { get; init; } = 0;
    public bool ShowSolverLog { get; init; } = true;
}
