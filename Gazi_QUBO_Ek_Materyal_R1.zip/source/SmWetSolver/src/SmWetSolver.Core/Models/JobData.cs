namespace SmWetSolver.Core.Models;

public sealed record JobData
{
    public required int Id { get; init; }
    public required int ProcessingTime { get; init; }
    public required int DueDate { get; init; }
    public required int EarlinessWeight { get; init; }
    public required int TardinessWeight { get; init; }
}
