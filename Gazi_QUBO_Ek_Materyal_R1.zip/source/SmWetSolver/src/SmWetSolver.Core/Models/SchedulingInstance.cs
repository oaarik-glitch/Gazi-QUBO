using System.Text.Json;
using System.Text.Json.Serialization;

namespace SmWetSolver.Core.Models;

public sealed record SchedulingInstance
{
    public required string Name { get; init; }
    public required IReadOnlyList<JobData> Jobs { get; init; }
    public int? Horizon { get; init; }

    [JsonIgnore]
    public int EffectiveHorizon => Horizon ??
        Jobs.Max(job => job.DueDate) + Jobs.Sum(job => job.ProcessingTime);

    public static SchedulingInstance Load(string path)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        var json = File.ReadAllText(path);
        var instance = JsonSerializer.Deserialize<SchedulingInstance>(json, JsonDefaults.Options)
            ?? throw new InvalidDataException($"Örnek okunamadı: {path}");
        instance.Validate();
        return instance;
    }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Name))
            throw new InvalidDataException("Örnek adı boş olamaz.");
        if (Jobs.Count == 0)
            throw new InvalidDataException("En az bir iş gereklidir.");
        if (Jobs.Select(job => job.Id).Distinct().Count() != Jobs.Count)
            throw new InvalidDataException("İş kimlikleri benzersiz olmalıdır.");

        foreach (var job in Jobs)
        {
            if (job.ProcessingTime <= 0)
                throw new InvalidDataException($"İş {job.Id}: işlem süresi pozitif olmalıdır.");
            if (job.DueDate < 0)
                throw new InvalidDataException($"İş {job.Id}: teslim tarihi negatif olamaz.");
            if (job.EarlinessWeight < 0 || job.TardinessWeight < 0)
                throw new InvalidDataException($"İş {job.Id}: ağırlıklar negatif olamaz.");
        }

        if (EffectiveHorizon < Jobs.Sum(job => job.ProcessingTime))
            throw new InvalidDataException("Zaman ufku toplam işlem süresinden kısa olamaz.");
    }
}
