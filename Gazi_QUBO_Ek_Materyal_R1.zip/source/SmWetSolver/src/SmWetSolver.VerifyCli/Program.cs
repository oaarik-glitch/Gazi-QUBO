using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

if (args.Length != 1)
{
    Console.Error.WriteLine("Kullanım: dotnet run --project src/SmWetSolver.VerifyCli -- <instance.json>");
    return 1;
}

try
{
    var instance = SchedulingInstance.Load(Path.GetFullPath(args[0]));
    var result = new ExactSmallInstanceSolver().Solve(instance);
    Console.WriteLine($"Örnek: {result.InstanceName}");
    Console.WriteLine($"Exact amaç: {result.ObjectiveValue:G17}");
    Console.WriteLine($"Doğrulama: {(result.IndependentValidationPassed ? "BAŞARILI" : "BAŞARISIZ")}");
    Console.WriteLine("Sıra: " + string.Join(" -> ", result.Schedule.OrderBy(item => item.Start).Select(item => $"J{item.JobId}")));
    foreach (var item in result.Schedule.OrderBy(item => item.Start))
        Console.WriteLine($"J{item.JobId}: S={item.Start}, C={item.Completion}, E={item.Earliness}, T={item.Tardiness}, maliyet={item.Cost}");
    return result.IndependentValidationPassed ? 0 : 2;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Hata: {exception.Message}");
    return 1;
}
