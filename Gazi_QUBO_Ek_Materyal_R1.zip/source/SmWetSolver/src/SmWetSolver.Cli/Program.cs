using Gurobi;
using SmWetSolver.Core.IO;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;
using SmWetSolver.Gurobi.Solvers;

if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase))
{
    PrintUsage();
    return 0;
}

try
{
    var instancePath = Path.GetFullPath(args[0]);
    var outputDirectory = Path.GetFullPath(GetOption(args, "--output") ?? "results");
    var instance = SchedulingInstance.Load(instancePath);
    var options = new SolverOptions
    {
        TimeLimitSeconds = GetDoubleOption(args, "--time-limit", 300.0),
        MipGap = GetDoubleOption(args, "--mip-gap", 0.0),
        Threads = GetIntOption(args, "--threads", 0),
        ShowSolverLog = !args.Contains("--quiet", StringComparer.OrdinalIgnoreCase)
    };

    var results = new List<SolveResult>();
    if (instance.Jobs.Count <= 9 && !args.Contains("--skip-exact", StringComparer.OrdinalIgnoreCase))
        results.Add(new ExactSmallInstanceSolver().Solve(instance));

    ISchedulingSolver[] solvers =
    [
        new PositionBasedGurobiSolver(),
        new TimeIndexedGurobiSolver(),
        new PrecedenceBasedGurobiSolver()
    ];

    foreach (var solver in solvers)
    {
        Console.WriteLine($"Çözülüyor: {solver.ModelName}");
        results.Add(solver.Solve(instance, options));
    }

    EquivalenceValidator.AssertEquivalent(results);
    ResultExporter.WriteAll(outputDirectory, results);

    Console.WriteLine();
    Console.WriteLine("Tüm modeller aynı amaç değerini verdi ve bağımsız fizibilite denetimini geçti.");
    foreach (var result in results)
        Console.WriteLine($"{result.ModelName,-24} amaç={result.ObjectiveValue,10:G8} süre={result.RuntimeSeconds,9:F4}s durum={result.Status}");
    Console.WriteLine($"Çıktı dizini: {outputDirectory}");
    return 0;
}
catch (GRBException exception)
{
    Console.Error.WriteLine($"Gurobi hatası ({exception.ErrorCode}): {exception.Message}");
    return 2;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Hata: {exception.Message}");
    return 1;
}

static string? GetOption(string[] commandLine, string name)
{
    var index = Array.FindIndex(commandLine, value => string.Equals(value, name, StringComparison.OrdinalIgnoreCase));
    if (index < 0)
        return null;
    if (index + 1 >= commandLine.Length)
        throw new ArgumentException($"{name} için değer eksik.");
    return commandLine[index + 1];
}

static double GetDoubleOption(string[] commandLine, string name, double defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null
        ? defaultValue
        : double.Parse(text, System.Globalization.CultureInfo.InvariantCulture);
}

static int GetIntOption(string[] commandLine, string name, int defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null
        ? defaultValue
        : int.Parse(text, System.Globalization.CultureInfo.InvariantCulture);
}

static void PrintUsage()
{
    Console.WriteLine("Kullanım:");
    Console.WriteLine("  dotnet run --project src/SmWetSolver.Cli -- <instance.json> [seçenekler]");
    Console.WriteLine();
    Console.WriteLine("Seçenekler:");
    Console.WriteLine("  --output <dizin>       Çıktı dizini (varsayılan: results)");
    Console.WriteLine("  --time-limit <saniye>  Her Gurobi modeli için süre sınırı (varsayılan: 300)");
    Console.WriteLine("  --mip-gap <oran>       Hedef MIP gap (varsayılan: 0)");
    Console.WriteLine("  --threads <adet>       Gurobi iş parçacığı sayısı; 0=otomatik");
    Console.WriteLine("  --skip-exact           Küçük örnek exact kontrolünü atla");
    Console.WriteLine("  --quiet                Gurobi günlüğünü kapat");
}
