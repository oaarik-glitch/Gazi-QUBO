using Gurobi;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Gurobi.Solvers;

public abstract class GurobiSolverBase : ISchedulingSolver
{
    public abstract string ModelName { get; }

    public abstract SolveResult Solve(SchedulingInstance instance, SolverOptions options);

    protected static void Configure(GRBModel model, SolverOptions options)
    {
        model.Parameters.TimeLimit = options.TimeLimitSeconds;
        model.Parameters.MIPGap = options.MipGap;
        model.Parameters.OutputFlag = options.ShowSolverLog ? 1 : 0;
        if (options.Threads > 0)
            model.Parameters.Threads = options.Threads;
    }

    protected SolveResult BuildResult(
        SchedulingInstance instance,
        GRBModel model,
        IReadOnlyList<JobSchedule> schedule)
    {
        if (model.SolCount <= 0)
            throw new InvalidOperationException($"{ModelName}: Gurobi uygulanabilir çözüm üretmedi; durum={StatusName(model.Status)}.");

        var errors = ScheduleValidator.Validate(instance, schedule, model.ObjVal);
        return new SolveResult
        {
            InstanceName = instance.Name,
            ModelName = ModelName,
            Status = StatusName(model.Status),
            ObjectiveValue = model.ObjVal,
            RuntimeSeconds = model.Runtime,
            MipGap = model.MIPGap,
            NodeCount = model.NodeCount,
            VariableCount = model.NumVars,
            ConstraintCount = model.NumConstrs,
            Schedule = schedule,
            IndependentValidationPassed = errors.Count == 0,
            ValidationErrors = errors
        };
    }

    protected static int IntValue(GRBVar variable) => checked((int)Math.Round(variable.X));

    private static string StatusName(int status) => status switch
    {
        GRB.Status.LOADED => "LOADED",
        GRB.Status.OPTIMAL => "OPTIMAL",
        GRB.Status.INFEASIBLE => "INFEASIBLE",
        GRB.Status.INF_OR_UNBD => "INF_OR_UNBD",
        GRB.Status.UNBOUNDED => "UNBOUNDED",
        GRB.Status.CUTOFF => "CUTOFF",
        GRB.Status.ITERATION_LIMIT => "ITERATION_LIMIT",
        GRB.Status.NODE_LIMIT => "NODE_LIMIT",
        GRB.Status.TIME_LIMIT => "TIME_LIMIT",
        GRB.Status.SOLUTION_LIMIT => "SOLUTION_LIMIT",
        GRB.Status.INTERRUPTED => "INTERRUPTED",
        GRB.Status.NUMERIC => "NUMERIC",
        GRB.Status.SUBOPTIMAL => "SUBOPTIMAL",
        GRB.Status.INPROGRESS => "INPROGRESS",
        GRB.Status.USER_OBJ_LIMIT => "USER_OBJ_LIMIT",
        GRB.Status.WORK_LIMIT => "WORK_LIMIT",
        GRB.Status.MEM_LIMIT => "MEM_LIMIT",
        _ => status.ToString()
    };
}
