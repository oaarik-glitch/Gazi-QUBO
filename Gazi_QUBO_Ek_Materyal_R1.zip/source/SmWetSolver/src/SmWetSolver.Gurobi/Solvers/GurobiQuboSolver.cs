using Gurobi;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Qubo;

namespace SmWetSolver.Gurobi.Solvers;

public sealed class GurobiQuboSolver
{
    public QuboSolveResult Solve(
        QuboModel qubo,
        SolverOptions options,
        IReadOnlyList<int>? warmStart = null,
        double? certifiedTargetEnergy = null)
    {
        using var environment = new GRBEnv(true);
        environment.Start();
        using var model = new GRBModel(environment) { ModelName = qubo.Name + "_exact" };
        model.Parameters.TimeLimit = options.TimeLimitSeconds;
        model.Parameters.MIPGap = options.MipGap;
        model.Parameters.OutputFlag = options.ShowSolverLog ? 1 : 0;
        model.Parameters.NonConvex = 2;
        if (options.Threads > 0)
            model.Parameters.Threads = options.Threads;

        var variables = Enumerable.Range(0, qubo.NumVariables)
            .Select(index => model.AddVar(0.0, 1.0, 0.0, GRB.BINARY, qubo.Variables[index].Name))
            .ToArray();
        model.Update();
        if (warmStart is not null)
        {
            if (warmStart.Count != qubo.NumVariables || warmStart.Any(value => value is not (0 or 1)))
                throw new ArgumentException("QUBO warm start vektörü geçersiz.", nameof(warmStart));
            for (var index = 0; index < variables.Length; index++)
                variables[index].Start = warmStart[index];
        }
        var objective = new GRBQuadExpr();
        foreach (var term in qubo.Linear)
            objective.AddTerm(term.Value, variables[term.Index]);
        foreach (var term in qubo.Quadratic)
            objective.AddTerm(term.Value, variables[term.I], variables[term.J]);
        model.SetObjective(objective, GRB.MINIMIZE);
        if (certifiedTargetEnergy.HasValue)
            model.Parameters.BestObjStop = certifiedTargetEnergy.Value - qubo.Constant + 1e-7;
        model.Optimize();

        if (model.SolCount <= 0)
            throw new InvalidOperationException($"Gurobi QUBO çözücüsü çözüm bulamadı; durum={StatusName(model.Status)}.");
        var values = variables.Select(variable => variable.X > 0.5 ? 1 : 0).ToArray();
        var energy = qubo.Evaluate(values);
        var targetReached = certifiedTargetEnergy.HasValue
            && energy <= certifiedTargetEnergy.Value + 1e-6;
        return new QuboSolveResult
        {
            Solver = "Gurobi-QUBO",
            Status = targetReached && model.Status != GRB.Status.OPTIMAL
                ? "CERTIFIED_TARGET_REACHED"
                : StatusName(model.Status),
            Energy = energy,
            RuntimeSeconds = model.Runtime,
            MipGap = model.MIPGap,
            NodeCount = model.NodeCount,
            Values = values
        };
    }

    private static string StatusName(int status) => status switch
    {
        GRB.Status.OPTIMAL => "OPTIMAL",
        GRB.Status.TIME_LIMIT => "TIME_LIMIT",
        GRB.Status.INFEASIBLE => "INFEASIBLE",
        GRB.Status.INF_OR_UNBD => "INF_OR_UNBD",
        GRB.Status.UNBOUNDED => "UNBOUNDED",
        GRB.Status.NODE_LIMIT => "NODE_LIMIT",
        GRB.Status.INTERRUPTED => "INTERRUPTED",
        GRB.Status.NUMERIC => "NUMERIC",
        GRB.Status.SUBOPTIMAL => "SUBOPTIMAL",
        _ => status.ToString()
    };
}
