using Gurobi;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Gurobi.Solvers;

public sealed class TimeIndexedGurobiSolver : GurobiSolverBase
{
    public override string ModelName => "Time-Indexed";

    public override SolveResult Solve(SchedulingInstance instance, SolverOptions options)
    {
        instance.Validate();
        var horizon = instance.EffectiveHorizon;

        using var environment = new GRBEnv(true);
        environment.Start();
        using var model = new GRBModel(environment) { ModelName = $"{instance.Name}_time_indexed" };
        Configure(model, options);

        var starts = new Dictionary<(int Job, int Time), GRBVar>();
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            for (var t = 0; t <= horizon - job.ProcessingTime; t++)
                starts[(i, t)] = model.AddVar(0.0, 1.0, 0.0, GRB.BINARY, $"x_{job.Id}_{t}");
        }

        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var assignment = new GRBLinExpr();
            var job = instance.Jobs[i];
            for (var t = 0; t <= horizon - job.ProcessingTime; t++)
                assignment.AddTerm(1.0, starts[(i, t)]);
            model.AddConstr(assignment, GRB.EQUAL, 1.0, $"assign_{job.Id}");
        }

        for (var tau = 0; tau < horizon; tau++)
        {
            var capacity = new GRBLinExpr();
            for (var i = 0; i < instance.Jobs.Count; i++)
            {
                var job = instance.Jobs[i];
                var firstActiveStart = Math.Max(0, tau - job.ProcessingTime + 1);
                var lastActiveStart = Math.Min(tau, horizon - job.ProcessingTime);
                for (var t = firstActiveStart; t <= lastActiveStart; t++)
                    capacity.AddTerm(1.0, starts[(i, t)]);
            }
            model.AddConstr(capacity, GRB.LESS_EQUAL, 1.0, $"capacity_{tau}");
        }

        var objective = new GRBLinExpr();
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            for (var t = 0; t <= horizon - job.ProcessingTime; t++)
                objective.AddTerm(CostCalculator.AtCompletion(job, t + job.ProcessingTime), starts[(i, t)]);
        }
        model.SetObjective(objective, GRB.MINIMIZE);
        model.Optimize();

        var schedule = new List<JobSchedule>(instance.Jobs.Count);
        for (var i = 0; i < instance.Jobs.Count; i++)
        {
            var job = instance.Jobs[i];
            var selectedStart = Enumerable.Range(0, horizon - job.ProcessingTime + 1)
                .Single(t => starts[(i, t)].X > 0.5);
            schedule.Add(CostCalculator.CreateSchedule(job, selectedStart));
        }

        return BuildResult(instance, model, schedule);
    }
}
