using Gurobi;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Gurobi.Solvers;

public sealed class PrecedenceBasedGurobiSolver : GurobiSolverBase
{
    public override string ModelName => "Precedence-Based";

    public override SolveResult Solve(SchedulingInstance instance, SolverOptions options)
    {
        instance.Validate();
        var n = instance.Jobs.Count;
        var horizon = instance.EffectiveHorizon;

        using var environment = new GRBEnv(true);
        environment.Start();
        using var model = new GRBModel(environment) { ModelName = $"{instance.Name}_precedence_based" };
        Configure(model, options);

        var start = new GRBVar[n];
        var earliness = new GRBVar[n];
        var tardiness = new GRBVar[n];
        var order = new Dictionary<(int First, int Second), GRBVar>();

        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            start[i] = model.AddVar(0.0, horizon - job.ProcessingTime, 0.0, GRB.INTEGER, $"S_{job.Id}");
            earliness[i] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"E_{job.Id}");
            tardiness[i] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"T_{job.Id}");
        }

        for (var i = 0; i < n; i++)
        {
            for (var j = i + 1; j < n; j++)
                order[(i, j)] = model.AddVar(0.0, 1.0, 0.0, GRB.BINARY, $"y_{instance.Jobs[i].Id}_{instance.Jobs[j].Id}");
        }

        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            var earlyDefinition = new GRBLinExpr();
            earlyDefinition.AddTerm(1.0, earliness[i]);
            earlyDefinition.AddTerm(1.0, start[i]);
            model.AddConstr(earlyDefinition, GRB.GREATER_EQUAL, job.DueDate - job.ProcessingTime, $"earliness_{job.Id}");

            var tardyDefinition = new GRBLinExpr();
            tardyDefinition.AddTerm(1.0, tardiness[i]);
            tardyDefinition.AddTerm(-1.0, start[i]);
            model.AddConstr(tardyDefinition, GRB.GREATER_EQUAL, job.ProcessingTime - job.DueDate, $"tardiness_{job.Id}");
        }

        for (var i = 0; i < n; i++)
        {
            for (var j = i + 1; j < n; j++)
            {
                var iBeforeJ = new GRBLinExpr();
                iBeforeJ.AddTerm(1.0, start[i]);
                iBeforeJ.AddTerm(-1.0, start[j]);
                iBeforeJ.AddTerm(horizon, order[(i, j)]);
                model.AddConstr(
                    iBeforeJ,
                    GRB.LESS_EQUAL,
                    horizon - instance.Jobs[i].ProcessingTime,
                    $"nonoverlap_i_before_j_{instance.Jobs[i].Id}_{instance.Jobs[j].Id}");

                var jBeforeI = new GRBLinExpr();
                jBeforeI.AddTerm(1.0, start[j]);
                jBeforeI.AddTerm(-1.0, start[i]);
                jBeforeI.AddTerm(-horizon, order[(i, j)]);
                model.AddConstr(
                    jBeforeI,
                    GRB.LESS_EQUAL,
                    -instance.Jobs[j].ProcessingTime,
                    $"nonoverlap_j_before_i_{instance.Jobs[i].Id}_{instance.Jobs[j].Id}");
            }
        }

        var objective = new GRBLinExpr();
        for (var i = 0; i < n; i++)
        {
            objective.AddTerm(instance.Jobs[i].EarlinessWeight, earliness[i]);
            objective.AddTerm(instance.Jobs[i].TardinessWeight, tardiness[i]);
        }
        model.SetObjective(objective, GRB.MINIMIZE);
        model.Optimize();

        var schedule = new List<JobSchedule>(n);
        for (var i = 0; i < n; i++)
            schedule.Add(CostCalculator.CreateSchedule(instance.Jobs[i], IntValue(start[i])));

        return BuildResult(instance, model, schedule);
    }
}
