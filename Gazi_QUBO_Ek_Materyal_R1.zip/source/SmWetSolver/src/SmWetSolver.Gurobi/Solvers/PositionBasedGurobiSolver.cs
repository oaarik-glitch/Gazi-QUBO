using Gurobi;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

namespace SmWetSolver.Gurobi.Solvers;

public sealed class PositionBasedGurobiSolver : GurobiSolverBase
{
    public override string ModelName => "Position-Based";

    public override SolveResult Solve(SchedulingInstance instance, SolverOptions options)
    {
        instance.Validate();
        var n = instance.Jobs.Count;
        var horizon = instance.EffectiveHorizon;

        using var environment = new GRBEnv(true);
        environment.Start();
        using var model = new GRBModel(environment) { ModelName = $"{instance.Name}_position_based" };
        Configure(model, options);

        var assignment = new GRBVar[n, n];
        var positionCompletion = new GRBVar[n];
        var idleBeforePosition = new GRBVar[n];
        var jobCompletion = new GRBVar[n];
        var earliness = new GRBVar[n];
        var tardiness = new GRBVar[n];

        for (var i = 0; i < n; i++)
        {
            for (var k = 0; k < n; k++)
                assignment[i, k] = model.AddVar(0.0, 1.0, 0.0, GRB.BINARY, $"x_{instance.Jobs[i].Id}_{k + 1}");

            jobCompletion[i] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"C_{instance.Jobs[i].Id}");
            earliness[i] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"E_{instance.Jobs[i].Id}");
            tardiness[i] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"T_{instance.Jobs[i].Id}");
        }

        for (var k = 0; k < n; k++)
        {
            positionCompletion[k] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"Cpos_{k + 1}");
            idleBeforePosition[k] = model.AddVar(0.0, horizon, 0.0, GRB.INTEGER, $"G_{k + 1}");
        }

        for (var i = 0; i < n; i++)
        {
            var eachJobOnce = new GRBLinExpr();
            for (var k = 0; k < n; k++)
                eachJobOnce.AddTerm(1.0, assignment[i, k]);
            model.AddConstr(eachJobOnce, GRB.EQUAL, 1.0, $"job_{instance.Jobs[i].Id}_once");
        }

        for (var k = 0; k < n; k++)
        {
            var fillPosition = new GRBLinExpr();
            for (var i = 0; i < n; i++)
                fillPosition.AddTerm(1.0, assignment[i, k]);
            model.AddConstr(fillPosition, GRB.EQUAL, 1.0, $"position_{k + 1}_filled");
        }

        for (var k = 0; k < n; k++)
        {
            var chain = new GRBLinExpr();
            chain.AddTerm(1.0, positionCompletion[k]);
            if (k > 0)
                chain.AddTerm(-1.0, positionCompletion[k - 1]);
            chain.AddTerm(-1.0, idleBeforePosition[k]);
            for (var i = 0; i < n; i++)
                chain.AddTerm(-instance.Jobs[i].ProcessingTime, assignment[i, k]);
            model.AddConstr(chain, GRB.EQUAL, 0.0, $"completion_chain_{k + 1}");
        }

        for (var i = 0; i < n; i++)
        {
            var job = instance.Jobs[i];
            for (var k = 0; k < n; k++)
            {
                var upperLink = new GRBLinExpr();
                upperLink.AddTerm(1.0, jobCompletion[i]);
                upperLink.AddTerm(-1.0, positionCompletion[k]);
                upperLink.AddTerm(horizon, assignment[i, k]);
                model.AddConstr(upperLink, GRB.LESS_EQUAL, horizon, $"link_upper_{job.Id}_{k + 1}");

                var lowerLink = new GRBLinExpr();
                lowerLink.AddTerm(1.0, positionCompletion[k]);
                lowerLink.AddTerm(-1.0, jobCompletion[i]);
                lowerLink.AddTerm(horizon, assignment[i, k]);
                model.AddConstr(lowerLink, GRB.LESS_EQUAL, horizon, $"link_lower_{job.Id}_{k + 1}");
            }

            var earlyDefinition = new GRBLinExpr();
            earlyDefinition.AddTerm(1.0, earliness[i]);
            earlyDefinition.AddTerm(1.0, jobCompletion[i]);
            model.AddConstr(earlyDefinition, GRB.GREATER_EQUAL, job.DueDate, $"earliness_{job.Id}");

            var tardyDefinition = new GRBLinExpr();
            tardyDefinition.AddTerm(1.0, tardiness[i]);
            tardyDefinition.AddTerm(-1.0, jobCompletion[i]);
            model.AddConstr(tardyDefinition, GRB.GREATER_EQUAL, -job.DueDate, $"tardiness_{job.Id}");
        }

        var objective = new GRBLinExpr();
        for (var i = 0; i < n; i++)
        {
            objective.AddTerm(instance.Jobs[i].EarlinessWeight, earliness[i]);
            objective.AddTerm(instance.Jobs[i].TardinessWeight, tardiness[i]);
        }
        model.SetObjective(objective, GRB.MINIMIZE);
        model.Optimize();

        var schedule = new List<JobSchedule>(n);
        for (var i = 0; i < n; i++)
        {
            var completion = IntValue(jobCompletion[i]);
            schedule.Add(CostCalculator.CreateSchedule(instance.Jobs[i], completion - instance.Jobs[i].ProcessingTime));
        }

        return BuildResult(instance, model, schedule);
    }
}
