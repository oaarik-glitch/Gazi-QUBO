using SmWetSolver.Core.Models;

namespace SmWetSolver.Gurobi.Solvers;

public interface ISchedulingSolver
{
    string ModelName { get; }
    SolveResult Solve(SchedulingInstance instance, SolverOptions options);
}
