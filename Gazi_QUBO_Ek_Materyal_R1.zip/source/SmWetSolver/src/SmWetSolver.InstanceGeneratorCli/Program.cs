using System.Globalization;
using SmWetSolver.Core.IO;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;

if (args.Contains("--help", StringComparer.OrdinalIgnoreCase))
{
    PrintUsage();
    return 0;
}

try
{
    var outputDirectory = Path.GetFullPath(GetOption(args, "--output") ?? "instances/generated");
    var options = new BenchmarkGenerationOptions
    {
        BaseSeed = GetUlongOption(args, "--seed", 20_260_902),
        InstancesPerSize = GetIntOption(args, "--per-size", 5),
        JobCounts = GetSizes(args, "--sizes", [4, 5, 6])
    };
    var benchmarks = BenchmarkInstanceFactory.Generate(options);
    BenchmarkInstanceWriter.Write(outputDirectory, options, benchmarks);

    Console.WriteLine($"{benchmarks.Count} örnek üretildi: {outputDirectory}");
    foreach (var group in benchmarks.GroupBy(item => item.Instance.Jobs.Count).OrderBy(group => group.Key))
        Console.WriteLine($"n={group.Key}: {group.Count()} örnek");
    return 0;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Hata: {exception.Message}");
    return 1;
}

static string? GetOption(string[] commandLine, string name)
{
    var index = Array.FindIndex(commandLine, value => string.Equals(value, name, StringComparison.OrdinalIgnoreCase));
    if (index < 0)
        return null;
    if (index + 1 >= commandLine.Length)
        throw new ArgumentException($"{name} için değer eksik.");
    return commandLine[index + 1];
}

static int GetIntOption(string[] commandLine, string name, int defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : int.Parse(text, CultureInfo.InvariantCulture);
}

static ulong GetUlongOption(string[] commandLine, string name, ulong defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : ulong.Parse(text, CultureInfo.InvariantCulture);
}

static IReadOnlyList<int> GetSizes(string[] commandLine, string name, IReadOnlyList<int> defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null
        ? defaultValue
        : text.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(value => int.Parse(value, CultureInfo.InvariantCulture))
            .ToArray();
}

static void PrintUsage()
{
    Console.WriteLine("Kullanım:");
    Console.WriteLine("  dotnet run --project src/SmWetSolver.InstanceGeneratorCli -- [seçenekler]");
    Console.WriteLine();
    Console.WriteLine("Seçenekler:");
    Console.WriteLine("  --output <dizin>   Örneklerin yazılacağı dizin (varsayılan: instances/generated)");
    Console.WriteLine("  --seed <sayı>      Temel seed (varsayılan: 20260902)");
    Console.WriteLine("  --sizes <liste>    Virgülle ayrılmış iş sayıları (varsayılan: 4,5,6)");
    Console.WriteLine("  --per-size <adet>  Her iş sayısı için örnek adedi (varsayılan: 5)");
}
