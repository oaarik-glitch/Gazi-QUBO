using System.Globalization;
using Gurobi;
using SmWetSolver.Core.IO;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Services;
using SmWetSolver.Gurobi.Solvers;

if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase))
{
    PrintUsage();
    return 0;
}

try
{
    var instanceDirectory = Path.GetFullPath(args[0]);
    var outputDirectory = Path.GetFullPath(GetOption(args, "--output") ?? "batch-results");
    var instancePaths = Directory.GetFiles(instanceDirectory, "*.instance.json")
        .OrderBy(path => path, StringComparer.Ordinal)
        .ToArray();
    if (instancePaths.Length == 0)
        throw new FileNotFoundException($"*.instance.json bulunamadı: {instanceDirectory}");

    var options = new SolverOptions
    {
        TimeLimitSeconds = GetDoubleOption(args, "--time-limit", 300.0),
        MipGap = GetDoubleOption(args, "--mip-gap", 0.0),
        Threads = GetIntOption(args, "--threads", 1),
        ShowSolverLog = args.Contains("--show-log", StringComparer.OrdinalIgnoreCase)
    };
    ISchedulingSolver[] solvers =
    [
        new PositionBasedGurobiSolver(),
        new TimeIndexedGurobiSolver(),
        new PrecedenceBasedGurobiSolver()
    ];

    var allResults = new List<SolveResult>();
    var instances = new Dictionary<string, SchedulingInstance>(StringComparer.Ordinal);
    for (var index = 0; index < instancePaths.Length; index++)
    {
        var instance = SchedulingInstance.Load(instancePaths[index]);
        if (instance.Jobs.Count > 9)
            throw new InvalidDataException($"{instance.Name}: batch eşdeğerlik testi en fazla 9 iş içindir.");
        instances.Add(instance.Name, instance);
        Console.WriteLine($"[{index + 1}/{instancePaths.Length}] {instance.Name} (n={instance.Jobs.Count})");

        var instanceResults = new List<SolveResult>
        {
            new ExactSmallInstanceSolver().Solve(instance)
        };
        foreach (var solver in solvers)
            instanceResults.Add(solver.Solve(instance, options));

        EquivalenceValidator.AssertEquivalent(instanceResults);
        allResults.AddRange(instanceResults);
        Console.WriteLine($"  optimum={instanceResults[0].ObjectiveValue:G8}; eşdeğerlik=BAŞARILI");
    }

    ResultExporter.WriteAll(outputDirectory, allResults);
    BatchSummaryExporter.Write(
        Path.Combine(outputDirectory, "batch-comparison.csv"),
        instances,
        allResults);

    Console.WriteLine();
    Console.WriteLine($"{instances.Count} örneğin tamamı üç Gurobi modelinde exact optimumla eşleşti.");
    Console.WriteLine($"Sonuç dizini: {outputDirectory}");
    return 0;
}
catch (GRBException exception)
{
    Console.Error.WriteLine($"Gurobi hatası ({exception.ErrorCode}): {exception.Message}");
    return 2;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Hata: {exception.Message}");
    return 1;
}

static string? GetOption(string[] commandLine, string name)
{
    var index = Array.FindIndex(commandLine, value => string.Equals(value, name, StringComparison.OrdinalIgnoreCase));
    if (index < 0)
        return null;
    if (index + 1 >= commandLine.Length)
        throw new ArgumentException($"{name} için değer eksik.");
    return commandLine[index + 1];
}

static double GetDoubleOption(string[] commandLine, string name, double defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : double.Parse(text, CultureInfo.InvariantCulture);
}

static int GetIntOption(string[] commandLine, string name, int defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : int.Parse(text, CultureInfo.InvariantCulture);
}

static void PrintUsage()
{
    Console.WriteLine("Kullanım:");
    Console.WriteLine("  dotnet run --project src/SmWetSolver.BatchCli -- <örnek-dizini> [seçenekler]");
    Console.WriteLine();
    Console.WriteLine("Seçenekler:");
    Console.WriteLine("  --output <dizin>       Sonuç dizini (varsayılan: batch-results)");
    Console.WriteLine("  --time-limit <saniye>  Her model/örnek için süre sınırı (varsayılan: 300)");
    Console.WriteLine("  --mip-gap <oran>       Hedef MIP gap (varsayılan: 0)");
    Console.WriteLine("  --threads <adet>       Gurobi thread sayısı (varsayılan: 1)");
    Console.WriteLine("  --show-log             Ayrıntılı Gurobi günlüğünü göster");
}
