using System.Globalization;
using Gurobi;
using SmWetSolver.Core.IO;
using SmWetSolver.Core.Models;
using SmWetSolver.Core.Qubo;
using SmWetSolver.Core.Services;
using SmWetSolver.Gurobi.Solvers;

if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase))
{
    PrintUsage();
    return 0;
}

try
{
    var instance = SchedulingInstance.Load(Path.GetFullPath(args[0]));
    if (instance.Jobs.Count > 9)
        throw new InvalidDataException("Klasik exact karşılaştırma için en fazla 9 iş desteklenir.");
    var outputDirectory = Path.GetFullPath(GetOption(args, "--output") ?? "qubo-results");
    var penalty = GetNullableDoubleOption(args, "--penalty");
    var exactLimit = GetIntOption(args, "--exact-limit", 26);
    var solverChoice = (GetOption(args, "--solver") ?? "auto").ToLowerInvariant();
    var formulationChoice = NormalizeFormulation(GetOption(args, "--formulation") ?? "time-indexed");
    var options = new SolverOptions
    {
        TimeLimitSeconds = GetDoubleOption(args, "--time-limit", 300.0),
        MipGap = 0.0,
        Threads = GetIntOption(args, "--threads", 1),
        ShowSolverLog = args.Contains("--show-log", StringComparer.OrdinalIgnoreCase)
    };
    var classical = new ExactSmallInstanceSolver().Solve(instance);

    if (args.Contains("--penalty-sweep", StringComparer.OrdinalIgnoreCase))
    {
        if (formulationChoice != "time-indexed")
            throw new ArgumentException("--penalty-sweep şu anda yalnızca --formulation time-indexed ile kullanılır.");
        return RunPenaltySweep(instance, outputDirectory, solverChoice, exactLimit, options, classical, args);
    }

    var formulations = formulationChoice == "all"
        ? new[] { "time-indexed", "position", "precedence" }
        : new[] { formulationChoice };
    var comparison = new List<QuboFormulationComparisonRow>();
    foreach (var formulation in formulations)
    {
        var qubo = BuildQubo(formulation, instance, penalty);
        IReadOnlyList<int>? warmStart = null;
        double? certifiedTargetEnergy = null;
        if (formulation == "position")
        {
            warmStart = PositionBasedQuboWarmStart.Encode(instance, qubo, classical.Schedule);
            if (qubo.Metadata.PenaltyGuaranteeSatisfied)
                certifiedTargetEnergy = classical.ObjectiveValue;
            Console.WriteLine(
                $"[position] doğrulanmış başlangıç enerjisi={qubo.Evaluate(warmStart):G8}; " +
                $"güvenli ceza sertifikası={certifiedTargetEnergy.HasValue}");
        }
        QuboJsonExporter.WriteModel(Path.Combine(outputDirectory, $"{formulation}-qubo.json"), qubo);
        Console.WriteLine(
            $"[{formulation}] QUBO: {qubo.NumVariables} değişken, " +
            $"{qubo.Quadratic.Count} ikinci derece terim");
        Console.WriteLine(
            $"[{formulation}] U={qubo.Metadata.FeasibleUpperBound:G8}, " +
            $"A={qubo.Metadata.Penalty:G8}, güvenli={qubo.Metadata.PenaltyGuaranteeSatisfied}");

        var solution = SolveQubo(
            qubo,
            solverChoice,
            exactLimit,
            options,
            warmStart,
            certifiedTargetEnergy);
        var decoded = QuboDecoder.Decode(instance, qubo, solution);
        var matches = MatchesClassical(decoded, classical.ObjectiveValue);
        var report = BuildReport(instance, qubo, solution, decoded, classical, matches);
        QuboJsonExporter.WriteValidation(
            Path.Combine(outputDirectory, $"{formulation}-validation.json"),
            report);

        var possiblePairs = qubo.NumVariables < 2
            ? 0.0
            : qubo.NumVariables * (qubo.NumVariables - 1.0) / 2.0;
        var maxCoefficient = qubo.Linear.Select(term => Math.Abs(term.Value))
            .Concat(qubo.Quadratic.Select(term => Math.Abs(term.Value)))
            .DefaultIfEmpty(0.0)
            .Max();
        comparison.Add(new QuboFormulationComparisonRow
        {
            InstanceName = instance.Name,
            Formulation = formulation,
            NumVariables = qubo.NumVariables,
            LinearTermCount = qubo.Linear.Count,
            QuadraticTermCount = qubo.Quadratic.Count,
            CouplingDensity = possiblePairs == 0.0 ? 0.0 : qubo.Quadratic.Count / possiblePairs,
            MaximumAbsoluteCoefficient = maxCoefficient,
            Penalty = qubo.Metadata.Penalty,
            FeasibleUpperBound = qubo.Metadata.FeasibleUpperBound,
            Solver = solution.Solver,
            Status = solution.Status,
            Energy = solution.Energy,
            SchedulingObjective = decoded.SchedulingObjective,
            PenaltyEnergy = decoded.PenaltyEnergy,
            Feasible = decoded.Feasible,
            MatchesClassicalOptimum = matches,
            RuntimeSeconds = solution.RuntimeSeconds,
            MipGap = solution.MipGap,
            NodeCount = solution.NodeCount,
            VariableFamilyCounts = qubo.Metadata.VariableFamilyCounts
        });

        var objectiveText = decoded.SchedulingObjective?.ToString("G8", CultureInfo.InvariantCulture) ?? "—";
        Console.WriteLine(
            $"[{formulation}] çözücü={solution.Solver}; durum={solution.Status}; " +
            $"enerji={solution.Energy:G8}; gap={solution.MipGap?.ToString("G8", CultureInfo.InvariantCulture) ?? "—"}; " +
            $"amaç={objectiveText}; fizibilite={decoded.Feasible}; eşleşme={matches}");
    }

    QuboJsonExporter.WriteFormulationComparisonCsv(
        Path.Combine(outputDirectory, "qubo-formulation-comparison.csv"),
        comparison);
    QuboJsonExporter.WriteFormulationComparisonJson(
        Path.Combine(outputDirectory, "qubo-formulation-comparison.json"),
        comparison);
    var allPassed = comparison.All(row => row.MatchesClassicalOptimum);
    Console.WriteLine($"Üçlü QUBO doğrulaması: {(allPassed ? "PASS" : "FAIL")}");
    Console.WriteLine($"Çıktı dizini: {outputDirectory}");
    return allPassed ? 0 : 3;
}
catch (GRBException exception)
{
    Console.Error.WriteLine($"Gurobi hatası ({exception.ErrorCode}): {exception.Message}");
    return 2;
}
catch (Exception exception)
{
    Console.Error.WriteLine($"Hata: {exception.Message}");
    return 1;
}

static int RunPenaltySweep(
    SchedulingInstance instance,
    string outputDirectory,
    string solverChoice,
    int exactLimit,
    SolverOptions options,
    SolveResult classical,
    string[] commandLine)
{
    var builder = new TimeIndexedQuboBuilder();
    var reference = builder.Build(instance);
    var penalties = ParsePenalties(GetOption(commandLine, "--penalties"), reference.Metadata.FeasibleUpperBound);
    var rows = new List<QuboPenaltySweepRow>();
    foreach (var candidatePenalty in penalties)
    {
        var candidate = builder.Build(instance, candidatePenalty);
        var solution = SolveQubo(candidate, solverChoice, exactLimit, options);
        var decoded = QuboDecoder.Decode(instance, candidate, solution);
        var matches = MatchesClassical(decoded, classical.ObjectiveValue);
        rows.Add(new QuboPenaltySweepRow
        {
            InstanceName = instance.Name,
            Penalty = candidatePenalty,
            FeasibleUpperBound = candidate.Metadata.FeasibleUpperBound,
            PenaltyGuaranteeSatisfied = candidate.Metadata.PenaltyGuaranteeSatisfied,
            NumVariables = candidate.NumVariables,
            LinearTermCount = candidate.Linear.Count,
            QuadraticTermCount = candidate.Quadratic.Count,
            Solver = solution.Solver,
            Status = solution.Status,
            Energy = solution.Energy,
            SchedulingObjective = decoded.SchedulingObjective,
            PenaltyEnergy = decoded.PenaltyEnergy,
            Feasible = decoded.Feasible,
            MatchesClassicalOptimum = matches,
            RuntimeSeconds = solution.RuntimeSeconds,
            MipGap = solution.MipGap,
            NodeCount = solution.NodeCount,
            SelectedVariables = decoded.SelectedVariables
        });
        Console.WriteLine(
            $"A={candidatePenalty:G8}; güvenli={candidate.Metadata.PenaltyGuaranteeSatisfied}; " +
            $"enerji={solution.Energy:G8}; fizibilite={decoded.Feasible}; eşleşme={matches}");
    }

    QuboJsonExporter.WritePenaltySweepCsv(Path.Combine(outputDirectory, "penalty-sensitivity.csv"), rows);
    QuboJsonExporter.WritePenaltySweepJson(Path.Combine(outputDirectory, "penalty-sensitivity.json"), rows);
    var safeRows = rows.Where(row => row.PenaltyGuaranteeSatisfied).ToArray();
    var passed = safeRows.Length > 0 && safeRows.All(row => row.MatchesClassicalOptimum);
    Console.WriteLine($"Güvenli ceza satırları doğrulandı: {passed}");
    Console.WriteLine($"Çıktı dizini: {outputDirectory}");
    return passed ? 0 : 3;
}

static QuboModel BuildQubo(string formulation, SchedulingInstance instance, double? penalty) =>
    formulation switch
    {
        "time-indexed" => new TimeIndexedQuboBuilder().Build(instance, penalty),
        "position" => new PositionBasedQuboBuilder().Build(instance, penalty),
        "precedence" => new PrecedenceQuboBuilder().Build(instance, penalty),
        _ => throw new ArgumentException($"Bilinmeyen QUBO formülasyonu: {formulation}.")
    };

static string NormalizeFormulation(string formulation) => formulation.ToLowerInvariant() switch
{
    "time" or "time-indexed" => "time-indexed",
    "position" or "position-based" => "position",
    "precedence" or "precedence-based" => "precedence",
    "all" => "all",
    _ => throw new ArgumentException("--formulation değeri time-indexed, position, precedence veya all olmalıdır.")
};

static QuboSolveResult SolveQubo(
    QuboModel qubo,
    string solverChoice,
    int exactLimit,
    SolverOptions options,
    IReadOnlyList<int>? warmStart = null,
    double? certifiedTargetEnergy = null) => solverChoice switch
{
    "exhaustive" => new ExhaustiveQuboSolver().Solve(qubo, exactLimit),
    "gurobi" => new GurobiQuboSolver().Solve(qubo, options, warmStart, certifiedTargetEnergy),
    "auto" when qubo.NumVariables <= exactLimit => new ExhaustiveQuboSolver().Solve(qubo, exactLimit),
    "auto" => new GurobiQuboSolver().Solve(qubo, options, warmStart, certifiedTargetEnergy),
    _ => throw new ArgumentException("--solver değeri auto, exhaustive veya gurobi olmalıdır.")
};

static bool MatchesClassical(QuboDecodedSolution decoded, double classicalObjective) =>
    decoded.Feasible
    && decoded.SchedulingObjective.HasValue
    && Math.Abs(decoded.SchedulingObjective.Value - classicalObjective) <= 1e-6
    && Math.Abs(decoded.PenaltyEnergy ?? double.PositiveInfinity) <= 1e-6;

static QuboValidationReport BuildReport(
    SchedulingInstance instance,
    QuboModel qubo,
    QuboSolveResult solution,
    QuboDecodedSolution decoded,
    SolveResult classical,
    bool matchesClassical) => new()
{
    InstanceName = instance.Name,
    Formulation = qubo.Formulation,
    NumVariables = qubo.NumVariables,
    LinearTermCount = qubo.Linear.Count,
    QuadraticTermCount = qubo.Quadratic.Count,
    Penalty = qubo.Metadata.Penalty,
    FeasibleUpperBound = qubo.Metadata.FeasibleUpperBound,
    PenaltyGuaranteeSatisfied = qubo.Metadata.PenaltyGuaranteeSatisfied,
    ClassicalOptimum = classical.ObjectiveValue,
    QuboSolve = solution,
    Decoded = decoded,
    MatchesClassicalOptimum = matchesClassical,
    ClassicalSchedule = classical.Schedule
};

static IReadOnlyList<double> ParsePenalties(string? text, double upperBound)
{
    IEnumerable<double> values = string.IsNullOrWhiteSpace(text)
        ? upperBound > 0.0
            ? [0.25 * upperBound, 0.5 * upperBound, upperBound, upperBound + 1.0, 2.0 * upperBound, 5.0 * upperBound, 10.0 * upperBound]
            : [0.25, 0.5, 1.0, 2.0, 5.0, 10.0]
        : text.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(value => double.Parse(value, CultureInfo.InvariantCulture));
    var result = values.Where(value => value > 0.0 && double.IsFinite(value))
        .Distinct().OrderBy(value => value).ToArray();
    if (result.Length == 0)
        throw new ArgumentException("Ceza taraması için en az bir pozitif ve sonlu değer gereklidir.");
    return result;
}

static string? GetOption(string[] commandLine, string name)
{
    var index = Array.FindIndex(commandLine, value => string.Equals(value, name, StringComparison.OrdinalIgnoreCase));
    if (index < 0)
        return null;
    if (index + 1 >= commandLine.Length)
        throw new ArgumentException($"{name} için değer eksik.");
    return commandLine[index + 1];
}

static double? GetNullableDoubleOption(string[] commandLine, string name)
{
    var text = GetOption(commandLine, name);
    return text is null ? null : double.Parse(text, CultureInfo.InvariantCulture);
}

static double GetDoubleOption(string[] commandLine, string name, double defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : double.Parse(text, CultureInfo.InvariantCulture);
}

static int GetIntOption(string[] commandLine, string name, int defaultValue)
{
    var text = GetOption(commandLine, name);
    return text is null ? defaultValue : int.Parse(text, CultureInfo.InvariantCulture);
}

static void PrintUsage()
{
    Console.WriteLine("Kullanım:");
    Console.WriteLine("  dotnet run --project src/SmWetSolver.QuboCli -- <instance.json> [seçenekler]");
    Console.WriteLine();
    Console.WriteLine("Seçenekler:");
    Console.WriteLine("  --formulation <tür>    time-indexed, position, precedence veya all");
    Console.WriteLine("  --output <dizin>       QUBO ve doğrulama çıktı dizini");
    Console.WriteLine("  --penalty <A>          Otomatik A=U+1 yerine özel ceza katsayısı");
    Console.WriteLine("  --solver <tür>         auto, exhaustive veya gurobi (varsayılan: auto)");
    Console.WriteLine("  --exact-limit <adet>   Exhaustive değişken sınırı (varsayılan: 26)");
    Console.WriteLine("  --time-limit <saniye>  Gurobi QUBO süre sınırı (varsayılan: 300)");
    Console.WriteLine("  --threads <adet>       Gurobi thread sayısı (varsayılan: 1)");
    Console.WriteLine("  --show-log             Ayrıntılı Gurobi günlüğünü göster");
    Console.WriteLine("  --penalty-sweep        Time-indexed ceza katsayısı ızgarasını çöz");
    Console.WriteLine("  --penalties <liste>    Virgülle ayrılmış özel ceza katsayıları");
}
